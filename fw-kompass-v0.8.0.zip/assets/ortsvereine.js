/* Öffentliches Ortsverzeichnis – Stand 08.11.2026. Nicht automatisch synchronisiert. */
export default {
  "updated": "2026-11-08",
  "sources": {
    "kreis": "https://www.fw-landkreis-erding.de/kontakt",
    "land": "https://www.fw-bayern.de/landesverband-vereinigung/freie-waehler-vor-ort"
  },
  "groups": [
    {
      "name": "Berglern",
      "url": "https://www.fwg-berglern.de",
      "source": "kreis"
    },
    {
      "name": "Dorfen",
      "url": "https://fw-dorfen.de",
      "source": "kreis"
    },
    {
      "name": "Erding (Stadt)",
      "url": "https://www.fw-erding.de",
      "source": "kreis"
    },
    {
      "name": "Isen",
      "url": "https://www.freiewaehler-isen.de",
      "source": "kreis"
    },
    {
      "name": "Langenpreising",
      "url": "https://www.fwg-langenpreising.de/",
      "source": "land"
    },
    {
      "name": "Lengdorf",
      "url": "https://www.freie-waehler-lengdorf.de",
      "source": "kreis"
    },
    {
      "name": "Moosinning",
      "url": "https://www.buergerblock-moosinning.de",
      "source": "kreis"
    },
    {
      "name": "Ottenhofen",
      "url": "https://www.fw-ottenhofen.de",
      "source": "kreis"
    },
    {
      "name": "Sankt Wolfgang",
      "url": null,
      "source": "land"
    },
    {
      "name": "Taufkirchen (Vils)",
      "url": "https://www.fw-taufkirchen.de",
      "source": "kreis"
    },
    {
      "name": "Walpertskirchen",
      "url": "https://www.fw-walpertskirchen.de",
      "source": "kreis"
    },
    {
      "name": "Wartenberg",
      "url": "https://www.fw-wartenberg.de",
      "source": "kreis"
    }
  ],
  "county": [
    {
      "name": "Kreisvereinigung FREIE WÄHLER (Partei)",
      "description": "Anlaufstelle für die politische Partei auf Kreisebene; Mitgliedschaft und formale Parteiorganisation.",
      "url": "https://www.fw-landkreis-erding.de/kontakt"
    },
    {
      "name": "Freie Wählerschaft Landkreis Erding",
      "description": "Kommunalpolitische Wählerschaft; eigenständig von der Parteikreisvereinigung zu unterscheiden.",
      "url": "https://www.fw-landkreis-erding.de/kontakt"
    }
  ]
};
