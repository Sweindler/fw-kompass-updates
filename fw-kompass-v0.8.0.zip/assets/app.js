import WHO from './who.js?v=0.8.0';
import GREMIEN from './gremien.js?v=0.8.0';
import ORTE from './ortsvereine.js?v=0.8.0';
/** FW Kompass Pilot: Vanilla JS, no third-party analytics, no external libraries. */
const APP_VERSION='0.8.0';
const RELEASE_DATE='08.11.2026';
const ROUTES = [
  {id:'start',label:'Start',icon:'⌂',sub:'Dein Überblick'},
  {id:'wegweiser',label:'Wegweiser',icon:'◇',sub:'Wohin mit meiner Frage?'},
  {id:'news',label:'Aktuelles',icon:'▤',sub:'Bund, Bayern, Erding'},
  {id:'kontakte',label:'Ansprechpartner',icon:'♧',sub:'Finde die richtige Stelle'},
  {id:'vorort',label:'FW vor Ort',icon:'⌖',sub:'Ortsgruppen im Landkreis Erding'},
  {id:'personen',label:'Who is Who',icon:'♙',sub:'Abgeordnete & Vorstände'},
  {id:'gremien',label:'Bundesgremien',icon:'♧',sub:'BFA & BAG kennenlernen'},
  {id:'termine',label:'Termine',icon:'▦',sub:'Veranstaltungen & Kalender'},
  {id:'wissen',label:'Wissen',icon:'▣',sub:'Organisation & Links'},
  {id:'einstieg',label:'Mein Einstieg',icon:'✓',sub:'Checkliste für Mitglieder'},
  {id:'info',label:'Über den Piloten',icon:'ⓘ',sub:'Hinweise & Quellen'},
  {id:'rechtliches',label:'Rechtliches',icon:'ⓘ',sub:'Impressum & Datenschutz'},
  {id:'statistik',label:'Statistik',icon:'▥',sub:'Geschützter Admin-Bereich'}
];
const ICON_SVG={
  start:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
  wegweiser:'<circle cx="12" cy="12" r="9"/><path d="m15.9 8.1-2.4 5.4-5.4 2.4 2.4-5.4z"/>',
  news:'<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M8 7h8M8 11h8M8 15h5M8 18h8"/>',
  kontakte:'<circle cx="12" cy="8" r="3"/><path d="M5 21v-2c0-3 3-5 7-5s7 2 7 5v2M4 8h3M17 8h3"/>',
  vorort:'<path d="M3 20h18M5 20V8l7-4 7 4v12M9 12h2v2H9zM13 12h2v2h-2zM10 20v-4h4v4"/>',
  gremien:'<path d="M3 5h7v6H3zM14 5h7v6h-7zM8 15h8v6H8zM6.5 11v2h11v-2M12 13v2"/>',
  personen:'<circle cx="12" cy="8" r="3"/><path d="M5 21v-2c0-3 3-5 7-5s7 2 7 5v2"/><path d="M18 3h3M19.5 1.5v3"/>',
  termine:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18M8 15h3"/>',
  wissen:'<path d="M12 6c-3-2-6-2-9-1v15c3-1 6-1 9 1 3-2 6-2 9-1V5c-3-1-6-1-9 1zM12 6v15"/>',
  einstieg:'<circle cx="12" cy="12" r="9"/><path d="m7 12 3 3 7-7"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
  statistik:'<rect x="4" y="10" width="4" height="11"/><rect x="10" y="5" width="4" height="16"/><rect x="16" y="2" width="4" height="19"/>',
  rechtliches:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
  updates:'<path d="M20 8v-4h-4M20 4a9 9 0 0 0-15 4M4 16v4h4M4 20a9 9 0 0 0 15-4"/>'
};
const iconFor=id=>`<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON_SVG[id]||ICON_SVG.info}</svg>`;
const SOURCE_LINKS=[
  {label:'Bundesvereinigung',url:'https://www.freiewaehler.eu/bund/pressemitteilungen/'},
  {label:'Bayern',url:'https://www.fw-bayern.de/aktuelles/mitteilungen'},
  {label:'Landkreis Erding',url:'https://www.fw-landkreis-erding.de/aktuelles'}
];
const INTRO_STEPS = [
  ['Aufbau kennenlernen','Bundesvereinigung, Landesvereinigung und Kreisstrukturen unterscheiden.'],
  ['Meine lokale Anlaufstelle finden','Ortsgruppe oder Kreisvereinigung über FW vor Ort suchen.'],
  ['Mitgliedschaft klären','Partei und kommunale Wählergemeinschaft nicht verwechseln.'],
  ['Aktuelle Informationsquellen öffnen','Regionale, bayerische und bundesweite Meldungen finden.'],
  ['Passenden Arbeitsbereich entdecken','BFA und BAG kennenlernen und einen passenden thematischen Arbeitsbereich auswählen.'],
  ['Ersten Kontakt aufnehmen','Die zuständige Geschäftsstelle oder Ansprechperson kontaktieren.']
];
const PURPOSES={
  mitgliedschaft:{title:'Mitgliedschaft und Aufnahme',text:'Ob Du Mitglied der politischen Partei oder einer kommunalen Wählergemeinschaft werden möchtest, entscheidet, welche Organisation zuständig ist. Beginne im Landkreis bei der Kreisvereinigung beziehungsweise dem jeweiligen Ortsverein.',topics:['mitgliedschaft'],level:'erding'},
  ortsverband:{title:'Politik in meiner Gemeinde',text:'Die öffentlichen Websites der örtlichen Gruppen sind ein guter Einstieg. Nicht jede Ortsgruppe ist identisch mit einer Parteigliederung – bitte die Mitgliedsform erfragen.',topics:['ortsverband'],level:'erding'},
  gremien:{title:'In Fachgremien mitarbeiten',text:'Auf Bundesebene gibt es Bundesfachausschüsse (BFA) und Bundesarbeitsgemeinschaften (BAG). Die Mitwirkung in einem BFA richtet sich nach den Vorgaben des Bundesvorstandes; die BAGs bieten thematische Beteiligung. Der neue Bereich Bundesgremien hilft bei der Suche.',topics:['gremien'],level:'bund'},
  presse:{title:'Presse und Öffentlichkeitsarbeit',text:'Für veröffentlichungsreife politische Statements ist die zuständige Presse-/Geschäftsstelle auf der entsprechenden Organisationsebene der richtige Startpunkt.',topics:['presse'],level:'bayern'},
  veranstaltung:{title:'Veranstaltung oder Sitzung organisieren',text:'Für lokale Veranstaltungen zuerst die Kreisgeschäftsstelle ansprechen. Überregionale Termine mit der betreffenden Landes- oder Bundesgeschäftsstelle abstimmen.',topics:['veranstaltung','termin'],level:'erding'},
  verwaltung:{title:'Satzungen und Verwaltung',text:'Formulare, Satzungen und Zuständigkeiten solltest Du immer über die aktuelle offizielle Geschäftsstelle oder die dort verlinkten Downloads prüfen.',topics:['verwaltung'],level:'erding'}
};
const LEVELS={all:'Alle Ebenen',erding:'Landkreis Erding',bayern:'Bayern',bund:'Bund'};
const LOCAL_KEY='fw-kompass-pilot-steps-v1';
const state={gremienGroup:'bag',gremienQuery:'',peopleGroup:'landtag',peopleQuery:'',newsRefreshing:false,route:'start',localQuery:'',localFilter:'all',newsLevel:'all',contactLevel:'all',contactQuery:'',guideTopic:'mitgliedschaft',guideLevel:'erding',guideTown:'',resourceQuery:'',newsQuery:'',data:{news:{metadata:{},articles:[]},contacts:[],regions:{towns:[]},resources:[]},loadError:false};
const $=s=>document.querySelector(s);
const esc=(value)=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const safeUrl=(url)=>{try{const value=new URL(String(url));return value.protocol==='https:'?value.href:'#';}catch{return '#';}};
const date=(d)=>{const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(d||'');return m?`${m[3]}.${m[2]}.${m[1]}`:esc(d||'');};
const external=(url,label,cl='text-link')=>`<a class="${cl}" href="${esc(safeUrl(url))}" target="_blank" rel="noopener noreferrer">${esc(label)} <span aria-hidden="true">↗</span></a>`;
const head=(kicker,title,subtitle)=>`<section class="section-intro"><div class="eyebrow">${esc(kicker)}</div><h1>${esc(title)}</h1><p>${esc(subtitle)}</p></section>`;
const sectionLine=(title,meta='')=>`<div class="section-line"><h2>${esc(title)}</h2>${meta?`<small>${esc(meta)}</small>`:''}</div>`;
const newArticle=a=>{if(!a.date)return false;const published=new Date(`${a.date}T12:00:00`);const age=Date.now()-published.getTime();return Number.isFinite(age)&&age>=0&&age<7*24*3600*1000;};
const newsCard=(a)=>`<article class="news-card"><div class="card-head"><span class="badgel ${esc(a.level)}">${esc(LEVELS[a.level]||a.level)}</span><div class="news-date">${newArticle(a)?'<span class="new-marker">NEU</span>':''}<time datetime="${esc(a.date)}" class="date">${date(a.date)}</time></div></div><h3>${esc(a.title)}</h3><p>${esc(a.excerpt||'')}</p>${external(a.url,'Zur offiziellen Quelle')}</article>`;
const contactCard=(c)=>`<article class="contact-card"><span class="badgel ${esc(c.level)}">${esc(LEVELS[c.level]||c.level)}</span><h3>${esc(c.name)}</h3><div class="contact-role">${esc(c.role)}</div><p style="margin-top:9px">${esc(c.organization)}</p><div class="actions">${external(c.url,'Kontaktseite','btn small')}${c.email?`<a href="mailto:${esc(c.email)}" class="btn small quiet">✉ E-Mail</a>`:''}</div>${c.note?`<div class="meta-line"><span>${esc(c.note)}</span></div>`:''}</article>`;
function introStatus(){let saved={};try{saved=JSON.parse(localStorage.getItem(LOCAL_KEY)||'{}')}catch{};return saved;}
function introCount(){return INTRO_STEPS.filter((_,i)=>introStatus()[i]).length;}
function nav(){
 const desktop=$('#side-nav'),mobile=$('#bottom-nav');
 desktop.innerHTML=ROUTES.filter(r=>r.id!=='statistik').map(r=>`<a class="nav-item ${state.route===r.id?'active':''}" href="#${r.id}" ${state.route===r.id?'aria-current="page"':''}><span class="nav-icon" aria-hidden="true">${iconFor(r.id)}</span><span>${r.label}</span></a>`).join('');
 mobile.innerHTML=ROUTES.filter(r=>['start','wegweiser','news','kontakte','personen'].includes(r.id)).map(r=>`<a class="nav-item ${state.route===r.id?'active':''}" href="#${r.id}" ${state.route===r.id?'aria-current="page"':''}><span class="nav-icon" aria-hidden="true">${iconFor(r.id)}</span><span>${r.label}</span></a>`).join('');
 $('#crumb').textContent=ROUTES.find(r=>r.id===state.route)?.label||'Übersicht';
}
function start(){
 const articles=[...state.data.news.articles].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,2);
 const count=introCount();
 const tiles=ROUTES.filter(r=>['wegweiser','vorort','news','kontakte','personen','gremien','termine','wissen','einstieg'].includes(r.id));
 return `<section class="hero"><div class="hero-kicker"><span>FW KOMPASS</span><span>LANDKREIS ERDING</span></div><div class="hero-inner"><div class="eyebrow">ORIENTIERUNG FÜR NEUE UND AKTIVE MITGLIEDER</div><h1>Gut informiert.<br><span class="hero-accent">Gemeinsam aktiv.</span></h1><p>Der direkte Weg zu Ansprechpartnern, aktuellen Meldungen und Möglichkeiten zur Mitarbeit bei den FREIEN WÄHLERN.</p><div class="hero-actions"><a class="btn primary" href="#wegweiser">Wegweiser starten <span aria-hidden="true">→</span></a><a class="btn" href="#vorort">FW vor Ort <span aria-hidden="true">↗</span></a></div></div><div class="hero-footer">PILOTPROJEKT <span aria-hidden="true">/</span> LANDKREIS ERDING</div></section>
 <div class="release-line"><span class="release-pill">FW Kompass · Version ${APP_VERSION}</span><span>Stand ${RELEASE_DATE} · Pilot Landkreis Erding</span></div>
 <div class="privacy-quick"><span><strong>Datensparsam:</strong> Die freiwillige Reichweitenstatistik ist zunächst ausgeschaltet.</span><a href="#rechtliches">Datenschutz &amp; Statistik-Einstellungen ↗</a></div>
 ${sectionLine('Finde deinen Weg','9 Bereiche')}
 <div class="tiles">${tiles.map(t=>`<a class="tile" href="#${t.id}"><span class="tile-icon">${iconFor(t.id)}</span><strong>${esc(t.label)}</strong><small>${esc(t.sub)}</small></a>`).join('')}</div>
 ${sectionLine('Dein FW Kompass auf einen Blick')}
 <div class="split"><div class="panel"><div class="spread"><h2>Dein Einstieg</h2><span class="tag">${count} von ${INTRO_STEPS.length} Schritten</span></div><p>Mit unserer Checkliste behältst Du alles im Blick. Dein Fortschritt bleibt nur auf diesem Gerät gespeichert.</p><div class="progress-line"><div class="progress-fill" style="width:${count/INTRO_STEPS.length*100}%"></div></div><a href="#einstieg" class="text-link">Checkliste öffnen →</a></div>
 <div class="panel"><h2>Offizielle Nachrichtenquellen</h2><p>Aktuelles aus dem Landkreis, der Landes- und der Bundesvereinigung an einer Stelle finden.</p><div class="source-strip">${SOURCE_LINKS.map(s=>external(s.url,s.label,'btn small')).join('')}</div></div></div>
 ${sectionLine('Ausgewählte Meldungen',state.data.news.metadata?.mode==='rss-plus-curated'?'RSS und Redaktion':'Redaktioneller Demo-Bestand')}
 <div class="cards">${articles.map(newsCard).join('')||'<div class="empty">Noch keine Meldungen hinterlegt.</div>'}</div><div style="margin-top:14px"><a href="#news" class="text-link">Alle ausgewählten Meldungen ansehen →</a></div>
 ${sectionLine('App & Aktualisierungen')}
<div class="pwa-actions"><div class="pwa-card"><div class="pwa-card-title"><span class="pwa-emoji" aria-hidden="true">${iconFor('einstieg')}</span><div><h2>FW Kompass als App</h2><p>Auf dem Smartphone installieren und direkt vom Startbildschirm öffnen.</p></div></div><button class="btn primary full" type="button" id="install-app-btn">App installieren</button><p id="install-app-state" class="tiny" aria-live="polite">Installation über Chrome oder den Browser möglich.</p><div id="install-app-help" class="install-help" hidden><strong>So klappt die Installation:</strong><p><b>Android:</b> Öffne diese Seite direkt in Google Chrome (nicht im ChatGPT-internen Browser), tippe oben rechts auf ⋮ und wähle „App installieren“ oder „Zum Startbildschirm hinzufügen“.</p><p><b>iPhone:</b> In Safari auf Teilen und danach „Zum Home-Bildschirm“ tippen.</p><p>Wenn die Schaltfläche fehlt, prüfe die HTTPS-Adresse und versuche es direkt in Chrome. Je nach Gerät ist nur eine Startbildschirm-Verknüpfung möglich.</p></div></div>
 <div class="pwa-card"><div class="pwa-card-title"><span class="pwa-emoji" aria-hidden="true">${iconFor('updates')}</span><div><h2>Update-Service</h2><p>Prüft, ob auf dem Server eine neue Version bereitsteht.</p></div></div><div class="update-version">Installierte Webversion: <strong>v${APP_VERSION}</strong></div><p id="update-check-state" class="tiny" role="status">Update-Prüfung wird vorbereitet …</p><button class="btn full" type="button" id="check-app-updates">Jetzt nach Updates suchen</button><button class="btn full dark" type="button" id="apply-app-update" hidden>Neue Version installieren</button><p class="tiny">Browser-Updates werden automatisch erkannt. Neue Server-Versionen können im geschützten Verwaltungsbereich installiert werden.</p></div></div>
 <p class="admin-hint"><a href="./admin/updater.php" target="_blank" rel="noopener noreferrer">⚙ Verwaltung und Server-Updates (nur Betreiber) ↗</a></p>`;
}
function localGroups(){
 const groups=ORTE.groups;
 return `${head('DEIN LANDKREIS · DEINE ANSPRECHPARTNER','FREIE WÄHLER vor Ort','Wähle eine Gemeinde und finde die veröffentlichte Website der örtlichen Gruppierung oder die zuständige Kreisorganisation.')}
 <div class="local-disclaimer"><strong>Wichtig:</strong> Ortsgruppe, kommunale Wählergemeinschaft und Parteigliederung sind nicht immer dasselbe. Ein Eintrag bedeutet nicht automatisch eine Mitgliedschaft in der Bundespartei. Die hier aufgeführten örtlichen Gruppen stammen aus den öffentlichen Verzeichnissen von Kreis und Land. Angaben werden nicht automatisch synchronisiert.</div>
 ${sectionLine('Kreisorganisationen')}
 <div class="local-county-grid">${ORTE.county.map(c=>`<article class="local-county"><h3>${esc(c.name)}</h3><p>${esc(c.description)}</p>${external(c.url,'Offizielle Kontaktseite','btn small')}</article>`).join('')}</div>
 ${sectionLine('Ortsgruppen und Wählergemeinschaften',groups.length+' Einträge')}
 <div class="local-controls"><div><label for="local-search">Gemeinde suchen</label><input id="local-search" class="people-search" type="search" placeholder="z. B. Dorfen, Isen, Sankt Wolfgang …" value="${esc(state.localQuery)}" /></div><div><label for="local-filter">Herkunft der Einträge</label><select id="local-filter"><option value="all" ${state.localFilter==='all'?'selected':''}>Alle veröffentlichten Einträge</option><option value="kreis" ${state.localFilter==='kreis'?'selected':''}>Kreiswebsite</option><option value="land" ${state.localFilter==='land'?'selected':''}>Landesverzeichnis ergänzend</option></select></div></div>
 <div class="people-bar"><span id="local-count"></span><span>Geprüft: ${date(ORTE.updated)}</span></div><div class="local-grid" id="local-list"></div>
 <div class="local-disclaimer"><strong>Ort nicht gefunden?</strong> Das bedeutet nicht zwangsläufig, dass es keine örtliche Wählergruppe gibt. Die Listen bilden nur die derzeit in den offiziellen Quellen nachgewiesenen Einträge ab. ${external(ORTE.sources.kreis,'Kontakt Kreisvereinigung')} · ${external(ORTE.sources.land,'Ortsverzeichnis Bayern')}</div>`;
}
function localCard(p){
 const named=p.name;
 const source=p.source==='kreis'?'Verlinkt auf Kreiswebsite':'Zusätzlich im Landesverzeichnis';
 return `<article class="local-card"><div class="local-card-head"><span class="local-pin" aria-hidden="true">${iconFor('vorort')}</span><span class="local-source">${esc(source)}</span></div><h3>${esc(named)}</h3><p>Örtliche Gruppierung im Landkreis Erding</p><div class="local-actions">${p.url?external(p.url,'Zur Website','btn small primary'):external(ORTE.sources.land,'Eintrag im Landesverzeichnis','btn small')}<a class="btn small quiet" href="#kontakte">Kreiskontakt</a></div></article>`;
}
function refreshLocal(){
 const target=$('#local-list');if(!target)return;
 const q=state.localQuery.trim().toLocaleLowerCase('de-DE');
 const result=ORTE.groups.filter(p=>(state.localFilter==='all'||p.source===state.localFilter)&&p.name.toLocaleLowerCase('de-DE').includes(q));
 target.innerHTML=result.length?result.map(localCard).join(''):'<div class="empty">Kein Eintrag gefunden. Bitte über die Kreisorganisation nachfragen.</div>';
 $('#local-count').textContent=`${result.length} von ${ORTE.groups.length} örtlichen Einträgen`;
}
function whoIsWho(){
 const tabs=[['landtag','MdL in Bayern'],['bund','Bundesvorstand'],['land','Landesvorstand Bayern']];
 return `${head('Menschen & Verantwortung','Who is Who','Wer gestaltet Politik und Organisation? Personen, Funktionen und direkte Links zu den offiziellen Profilen.')}
 <div class="who-intro-alert"><strong>Stand: ${date(WHO.updated)} · Führungswechsel</strong><p>Nach dem Tod von Hubert Aiwanger am 4. November 2026 ist der Bundes- und Landesvorsitz neu zu besetzen. Laut BR24 führt Manfred Petry die Bundespartei vorläufig. Die Fraktionsliste der Website wurde noch nicht entsprechend bereinigt. Dieser Wegweiser führt Hubert Aiwanger deshalb nicht als amtierende Person.</p><p>Quelle: ${external('https://www.br.de/nachrichten/bayern/freie-waehler-wie-geht-es-nach-aiwangers-tod-weiter%2CVa5uNYW','BR24, 05.11.2026','text-link')}</p></div>
 <div class="people-tabbar" role="group" aria-label="Personengruppen">${tabs.map(([key,label])=>`<button type="button" class="chip ${state.peopleGroup===key?'active':''}" data-people-tab="${key}" aria-pressed="${state.peopleGroup===key}">${label} <span class="count-inline">${WHO[key].length}</span></button>`).join('')}</div>
 <label class="people-search-label" for="people-search">Namen und Funktionen durchsuchen</label><input class="people-search" type="search" id="people-search" placeholder="z. B. Gesundheit, Mehring, Vorstand …" value="${esc(state.peopleQuery)}" />
 <div class="people-bar"><span id="people-count"></span><span>Porträts: offizielle öffentliche Quellen, sonst neutraler Platzhalter</span></div>
 <div class="people-grid" id="people-grid"></div>
 <div class="who-disclaimer"><strong>Hinweis zu Fotos:</strong> Die Porträts werden direkt von ihren externen Ursprungsseiten angezeigt. Manche fehlen derzeit und sind durch einen neutralen Platzhalter ersetzt. Für eine offizielle Veröffentlichung sollten die Nutzungsrechte der jeweiligen Fotos geklärt werden. Die Angaben werden nicht automatisch synchronisiert; neue Vorstandsentscheidungen sind zeitnah zu prüfen. ${external(WHO.sources[state.peopleGroup],'Offizielles Verzeichnis','text-link')}</div>`;
}
function personPhoto(p){
 const initials=p.name.replace(/\b(?:Dr|Prof)\.?\s*/gi,'').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase();
 const fallback=`<span class="portrait-fallback" aria-label="Kein geprüftes Porträt hinterlegt"><span>${esc(initials)}</span><small>Foto folgt</small></span>`;
 if(!p.image)return fallback;
 return `<span class="portrait-wrap portrait-pending">${fallback}<button type="button" class="portrait-load" data-portrait-url="${esc(safeUrl(p.image))}" data-portrait-name="${esc(p.name)}" title="Porträt laden: Verbindung zur offiziellen Bildquelle">Foto laden ↗</button></span>`;
}
function whoCard(p){return `<article class="person-card"><div class="person-photo">${personPhoto(p)}</div><div class="person-info"><h3>${esc(p.name)}</h3><p class="person-role">${esc(p.role)}</p><div class="person-bottom">${external(p.url,'Offizielles Profil','text-link')}${p.imageSource?`<span class="person-photo-credit">Foto: ${esc(p.imageSource)}</span>`:''}</div></div></article>`;}
function refreshPeople(){
 const results=WHO[state.peopleGroup].filter(p=>`${p.name} ${p.role}`.toLocaleLowerCase('de-DE').includes(state.peopleQuery.trim().toLocaleLowerCase('de-DE')));
 const list=$('#people-grid');if(list)list.innerHTML=results.length?results.map(whoCard).join(''):'<div class="empty">Keine Person gefunden.</div>';
 document.querySelectorAll('[data-portrait-url]').forEach(btn=>btn.addEventListener('click',()=>{
  const wrap=btn.closest('.portrait-wrap');const img=document.createElement('img');
  img.loading='lazy';img.decoding='async';img.referrerPolicy='no-referrer';img.alt=`Porträt von ${btn.dataset.portraitName}`;
  img.addEventListener('load',()=>wrap.classList.add('portrait-loaded'));
  img.addEventListener('error',()=>{img.remove();btn.textContent='Foto nicht verfügbar';btn.disabled=true;});
  img.src=btn.dataset.portraitUrl;wrap.appendChild(img);btn.remove();
 }));
 const c=$('#people-count');if(c)c.textContent=`${results.length} von ${WHO[state.peopleGroup].length} Personen`;
}

function federalBodies(){
 const tabs=[['bag','Bundesarbeitsgemeinschaften (BAG)'],['bfa','Bundesfachausschüsse (BFA)']];
 const arr=GREMIEN[state.gremienGroup];
 return `${head('Mitmachen auf Bundesebene','Bundesgremien – BFA & BAG','Entdecke die thematische Arbeit der FREIEN WÄHLER, finde Vorsitzende und offizielle Kontaktwege.')}
 <div class="gremien-explainer"><article class="gremien-explain-card"><span class="gremien-kicker">BAG</span><h2>Bundesarbeitsgemeinschaften</h2><p>Themenbezogene Netzwerke für Austausch, Vernetzung und Mitwirkung von Mitgliedern. Die jeweiligen BAGs informieren über die Möglichkeiten zur Teilnahme.</p></article>
 <article class="gremien-explain-card"><span class="gremien-kicker">BFA</span><h2>Bundesfachausschüsse</h2><p>Fachgremien zur inhaltlichen Unterstützung des Bundesvorstands. Themen, Berufungen und Vorsitz richten sich nach Satzung und Beschlüssen des Bundesvorstands.</p></article></div>
 <div class="gremien-tabbar" role="group" aria-label="Gremientyp auswählen">${tabs.map(([k,l])=>`<button type="button" class="chip ${state.gremienGroup===k?'active':''}" data-gremien-tab="${k}" aria-pressed="${state.gremienGroup===k}">${l} <span class="count-inline">${GREMIEN[k].length}</span></button>`).join('')}</div>
 <label class="people-search-label" for="gremien-search">Gremium, Thema oder Vorsitz durchsuchen</label><input class="people-search" id="gremien-search" type="search" placeholder="z. B. Pflege, Wirtschaft, Frauen …" value="${esc(state.gremienQuery)}"/>
 <div class="people-bar"><span id="gremien-count"></span><span>Stand: ${date(GREMIEN.updated)}</span></div>
 <div class="gremien-grid" id="gremien-list"></div>
 <section class="gremien-join"><div><span class="gremien-kicker">MITMACHEN</span><h2>Du möchtest Dich engagieren?</h2><p>Wende Dich bei einer BAG direkt an die veröffentlichte Kontaktadresse. Für die Mitarbeit in einem BFA klärst Du die Voraussetzungen über die Bundesgeschäftsstelle.</p></div><div class="gremien-join-links">${external('https://www.freiewaehler.eu/mitmachen/bag/','Offizielle BAG-Übersicht','btn primary')}${external('https://www.freiewaehler.eu/services/kontakt/','Bundesgeschäftsstelle','btn')}</div></section>
 <p class="who-disclaimer"><strong>Hinweis zur Vollständigkeit:</strong> Die vier BAGs sind auf der offiziellen Bundeswebsite veröffentlicht. Bei den BFAs liegt keine öffentlich bestätigte vollständige aktuelle Gesamtliste vor. Hier sind nur einzeln nachgewiesene Fachausschüsse aufgenommen; unbestätigte Vorsitzende werden bewusst nicht genannt. Der Stand muss bei der Bundesgeschäftsstelle regelmäßig überprüft werden.</p>`;
}
function gremienCard(g){
 const chair=g.chair?`<p class="gremien-contact"><span>Vorsitz</span><strong>${esc(g.chair)}</strong></p>`:`<p class="gremien-contact"><span>Vorsitz</span><strong>Bitte offiziell erfragen</strong></p>`;
 const mail=g.email?`<a class="btn small primary" href="mailto:${esc(g.email)}">E-Mail senden</a>`:'';
 return `<article class="gremium-card"><span class="gremien-badge">${state.gremienGroup.toUpperCase()}</span><h3>${esc(g.name)}</h3><p class="gremien-desc">${esc(g.description)}</p>${chair}<div class="gremien-card-footer">${mail}${external(g.url,g.linkLabel||'Offizielle Quelle','btn small')}</div></article>`;
}
function refreshGremien(){
 const a=GREMIEN[state.gremienGroup];const q=state.gremienQuery.trim().toLocaleLowerCase('de-DE');
 const filtered=a.filter(g=>`${g.name} ${g.description} ${g.chair||''}`.toLocaleLowerCase('de-DE').includes(q));
 $('#gremien-list').innerHTML=filtered.length?filtered.map(gremienCard).join(''):'<div class="empty">Kein Gremium zu diesem Suchbegriff gefunden.</div>';
 $('#gremien-count').textContent=`${filtered.length} von ${a.length} erfassten Gremien`;
}
function guide(){
 const towns=state.data.regions.towns||[];
 return `${head('Dein Ansprechpartner-Finder','Wohin mit Deiner Frage?','Wähle Dein Anliegen und die zuständige Ebene. Der Kompass zeigt Dir den nächsten sinnvollen Schritt und offizielle Kontaktwege.')}
 <section class="panel"><div class="form-grid"><div class="field"><label for="guide-topic">Was möchtest Du tun?</label><select id="guide-topic">${Object.entries(PURPOSES).map(([key,v])=>`<option value="${key}" ${state.guideTopic===key?'selected':''}>${esc(v.title)}</option>`).join('')}</select></div><div class="field"><label for="guide-level">Auf welcher Ebene?</label><select id="guide-level">${Object.entries(LEVELS).filter(([key])=>key!=='all').map(([key,v])=>`<option value="${key}" ${state.guideLevel===key?'selected':''}>${esc(v)}</option>`).join('')}</select></div><div class="field"><label for="guide-town">Mein Ort (optional)</label><select id="guide-town"><option value="">Keine Ortsauswahl</option>${towns.map(t=>`<option value="${esc(t.name)}" ${state.guideTown===t.name?'selected':''}>${esc(t.name)}</option>`).join('')}</select></div></div><p class="tiny">Hinweis: Vorschläge dienen der Orientierung und ersetzen keine bestätigte Zuständigkeitsauskunft der Organisation.</p></section>
 <div id="guide-result">${guideResult()}</div>`;
}
function guideResult(){
 const p=PURPOSES[state.guideTopic]||PURPOSES.mitgliedschaft;
 const level=state.guideLevel;
 const contacts=state.data.contacts.filter(c=>c.level===level&&(c.topics||[]).some(x=>p.topics.includes(x)));
 const fallback=state.data.contacts.filter(c=>c.level===level).slice(0,2);
 const matches=contacts.length?contacts:fallback;
 const town=state.data.regions.towns.find(x=>x.name===state.guideTown);
 let townLine='';
 if(town){townLine=town.website?`<p><strong>Dein Ort:</strong> ${esc(town.name)} – ${external(town.website,'örtliche Website öffnen')}.</p>`:`<p><strong>Dein Ort:</strong> ${esc(town.name)} – im Demo-Datenbestand ist noch keine bestätigte Ortswebsite eingetragen. Bitte direkt beim Kreisverband nachfragen.</p>`;}
 return `<section class="result"><div class="eyebrow">DEINE ORIENTIERUNG</div><h2>${esc(p.title)}</h2><p>${esc(p.text)}</p>${townLine}<div class="meta-line"><span>Gewählte Ebene: ${esc(LEVELS[level])}</span><span>Zuletzt geprüfte Links: November 2026</span></div></section>
 ${state.guideTopic==='gremien'?'<p class="gremien-guide-link"><a class="btn primary" href="#gremien">Bundesfachausschüsse & Bundesarbeitsgemeinschaften ansehen →</a></p>':''}
 ${state.guideTopic==='ortsverband'||state.guideTopic==='mitgliedschaft'?'<p class="gremien-guide-link"><a class="btn primary" href="#vorort">Ortsgruppen im Landkreis Erding finden →</a></p>':''}
 ${sectionLine('Passende Anlaufstellen')}
 <div class="cards">${matches.length?matches.map(contactCard).join(''):'<div class="empty">Für dieses Anliegen ist noch kein einzelner Ansprechpartner bestätigt. Nutze bitte die zentrale Geschäftsstelle der gewählten Ebene.</div>'}</div>
 ${sectionLine('Noch nicht sicher?')}<div class="padded-note">Für eine rein kommunale Wählergemeinschaft ist nicht automatisch die Parteikreisvereinigung zuständig. Kläre zuerst, welcher Organisation Deine Mitgliedschaft oder Dein Vorhaben zugeordnet ist.</div>`;
}
function sortedNews(){return [...(state.data.news.articles||[])].filter(a=>(state.newsLevel==='all'||a.level===state.newsLevel)&&(`${a.title||''} ${a.excerpt||''} ${a.source||''}`.toLocaleLowerCase('de-DE').includes(state.newsQuery.trim().toLocaleLowerCase('de-DE')))).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||(a.title||'').localeCompare(b.title||''));}
function newsStatus(){
 const meta=state.data.news.metadata||{};
 const mode=meta.mode||'curated-demo';
 const live=(mode==='rss-plus-curated'||mode==='rss-active');
 const count=meta.feedCount||0;
 if(live)return `<div class="alert news-status" role="status"><strong><span class="status-dot" style="background:#338d64"></span>${count} geprüfte Nachrichtenquelle${count===1?'':'n'} automatisch eingebunden</strong><p>Letzter erfolgreicher Abruf: ${esc(meta.lastSuccessfulAt||'nicht bekannt')} · Zusätzlich können redaktionelle Meldungen enthalten sein. ${meta.failedFeeds?'Einige Quellen konnten nicht aktualisiert werden.':''}</p></div>`;
 return `<div class="alert orange news-status" role="status"><strong><span class="status-dot"></span>Redaktionell gepflegte Demo · Stand ${date(meta.updatedAt)}</strong><p>Keine automatische Synchronisation aktiv. Aktuelle Meldungen bitte über die offiziellen Quellen öffnen.</p></div>`;
}
function news(){
 const articles=sortedNews();
 return `${head('Informiert bleiben','Aktuelles aus drei Ebenen','Bundesweite, bayerische und regionale Nachrichten – mit direktem Link zum Original.')}
 ${newsStatus()}
 <div class="news-tools"><div class="filters" id="news-filters" role="group" aria-label="Nachrichtenebene">${Object.entries(LEVELS).map(([key,v])=>`<button type="button" data-news-level="${key}" class="chip ${state.newsLevel===key?'active':''}" aria-pressed="${state.newsLevel===key}">${esc(v)}</button>`).join('')}</div>
 <label class="news-search-label" for="news-search">Meldungen durchsuchen</label><div class="news-search-row"><div class="news-search-wrap"><span aria-hidden="true">⌕</span><input id="news-search" aria-label="Nachrichten durchsuchen" type="search" placeholder="Suchbegriff eingeben …" value="${esc(state.newsQuery)}" autocomplete="off"></div><button type="button" class="btn news-refresh" id="news-reload" ${state.newsRefreshing?'disabled':''}>↻ ${state.newsRefreshing?'Lädt …':'Aktualisieren'}</button></div></div>
 <div class="news-list-meta" id="news-result-count" role="status">${articles.length} ${articles.length===1?'Meldung':'Meldungen'} · Neueste zuerst</div>
 <div class="cards" id="news-list">${articles.length?articles.map(newsCard).join(''):'<div class="empty">Keine Meldungen gefunden. Filter oder Suchbegriff ändern.</div>'}</div>
 ${sectionLine('Aktuelle Veröffentlichungen direkt lesen')}
 <p class="tiny source-help">Diese Links führen zu den offiziellen Websites. Dort findest Du immer die aktuell veröffentlichten Meldungen – unabhängig vom Demo-Bestand im FW Kompass.</p>
 <div class="source-strip news-sources">${SOURCE_LINKS.map(s=>external(s.url,s.label,'btn')).join('')}</div>`;
}
function contacts(){
 const filtered=state.data.contacts.filter(c=>(state.contactLevel==='all'||c.level===state.contactLevel)&&(`${c.name} ${c.role} ${c.organization}`.toLowerCase().includes(state.contactQuery.toLowerCase())));
 return `${head('Menschen & Stellen','Ansprechpartner finden','Hier stehen nur öffentlich belegte Kontakte beziehungsweise offizielle Geschäftsstellen. Bitte Änderungen vor der Veröffentlichung mit den jeweiligen Organisationen abgleichen.')}
 <div class="spread" style="margin-bottom:17px"><div class="filters" id="contact-filters">${Object.entries(LEVELS).map(([key,v])=>`<button type="button" data-contact-level="${key}" class="chip ${state.contactLevel===key?'active':''}" aria-pressed="${state.contactLevel===key}">${esc(v)}</button>`).join('')}</div><div class="searchbox"><input type="search" id="contact-search" placeholder="Name oder Funktion suchen …" aria-label="Kontakte durchsuchen" value="${esc(state.contactQuery)}"></div></div>
 <div class="cards" id="contact-list">${filtered.length?filtered.map(contactCard).join(''):'<div class="empty">Keine Kontakte gefunden.</div>'}</div>`;
}
function events(){
 return `${head('Termine & Begegnungen','Dabei sein und mitmachen','Für lokale Termine verlinken wir die offizielle Kreisübersicht. In der ersten Pilotversion veröffentlichen wir keine unbestätigten Veranstaltungen.')}
 <div class="panel"><div class="eyebrow">TERMINKALENDER</div><h2 style="font-size:21px;margin-top:10px">Veranstaltungen aus offiziellen Quellen</h2><p>Auf den unten verlinkten Kalenderseiten kannst Du die jeweils aktuellen Termine prüfen. Später können hier freigegebene Kalender automatisch zusammengestellt werden.</p><div class="source-strip">${external('https://www.fw-landkreis-erding.de/veranstaltungen','Landkreis Erding','btn')}${external('https://www.fw-bayern.de','Bayern','btn')}${external('https://www.freiewaehler.eu/','Bundesvereinigung','btn')}</div></div>
 ${sectionLine('So soll die Terminverwaltung später funktionieren')}
 <div class="steps"><div class="step"><b>1</b><span>Lokale Veranstaltung durch die Kreisredaktion eintragen oder freigegebenen Veranstaltungskalender anbinden.</span></div><div class="step"><b>2</b><span>Termine erhalten Region, Veranstalter, Datum, Zeit, Ort und Teilnahmehinweise.</span></div><div class="step"><b>3</b><span>Im Kompass erscheinen sie passend zum gewählten Landkreis und auf Wunsch im persönlichen Kalender.</span></div></div>`;
}
function knowledge(){
 const r=state.data.resources.filter(x=>`${x.title} ${x.description} ${x.category}`.toLowerCase().includes(state.resourceQuery.toLowerCase()));
 return `${head('Die Organisation verstehen','Wissen & wichtige Links','Die wichtigsten Fragen zum Start, dazu geprüfte Einstiegspunkte zu offiziellen Dokumenten und Arbeitsbereichen.')}
 <div class="stack">
 <details class="accordion" open><summary>Was ist der Unterschied zwischen Partei und kommunaler Wählergemeinschaft?</summary><div><p>Die <strong>FREIEN WÄHLER als Partei</strong> sind in einer politischen Organisation von der Bundes- bis zur lokalen Ebene strukturiert. <strong>Kommunale Wählergemeinschaften und Vereine</strong> treten besonders in Gemeinden und Landkreisen auf; sie können organisatorisch eigenständig sein. Ein Vereinsbeitritt ist daher nicht automatisch ein Parteibeitritt. Im Landkreis Erding führt die Website Kreisvereinigung und Freie Wählerschaft ausdrücklich getrennt.</p></div></details>
 <details class="accordion"><summary>Wie ist der Weg von meinem Ort bis zur Bundesebene?</summary><div><p>Die Orientierung läuft über örtliche Gruppierungen oder Parteigliederungen, Kreisorganisation, Bezirks- und Landesebene bis zur Bundesvereinigung. Zuständigkeiten und Mitgliedsrechte richten sich nach der konkreten Organisation und ihren aktuellen Satzungen.</p></div></details>
 <details class="accordion"><summary>Wie kann ich mich in einem Fachgremium engagieren?</summary><div><p>Suche zunächst Deinen Themenbereich, zum Beispiel Soziales, Gesundheit, Wirtschaft oder Bildung. Nimm über die zuständige Landes- beziehungsweise Bundesgeschäftsstelle Kontakt auf und frage nach der aktuellen Struktur und Teilnahmevoraussetzungen.</p></div></details>
 <details class="accordion"><summary>Wer pflegt Inhalte und Kontakte im Kompass?</summary><div><p>Im Pilot werden Inhalte über JSON-Dateien redaktionell gepflegt. Für einen offiziellen Ausbau empfehlen sich Rollen für Kreis-, Landes- und Bundesredaktion mit Freigabeprozess und Änderungsprotokoll.</p></div></details>
 </div>
 ${sectionLine('Offizielle Dokumente & Websites')}
 <div class="searchbox" style="max-width:100%;margin-bottom:16px"><input id="resource-search" aria-label="Wissensbereich durchsuchen" placeholder="Links und Themen suchen …" type="search" value="${esc(state.resourceQuery)}"></div>
 <div class="cards" id="resource-list">${r.length?r.map(x=>`<article class="resource-card"><span class="badgel">${esc(x.category)}</span><h3>${esc(x.title)}</h3><p>${esc(x.description)}</p>${external(x.url,'Offizielle Website öffnen')}</article>`).join(''):'<div class="empty">Keine Links gefunden.</div>'}</div>
 ${sectionLine('Lokale Gruppierungen im Landkreis Erding')}
 <p class="muted" style="font-size:13px">Öffentlich gelistete Websites; nicht jede Gruppierung muss ein Parteiorgan sein.</p>
 <div class="source-strip">${state.data.regions.towns.map(t=>t.website?external(t.website,t.name,'btn small'):`<span class="btn small quiet" title="Keine verifizierte Ortswebsite hinterlegt">${esc(t.name)} · Kreis kontaktieren</span>`).join('')}</div>`;
}
function onboarding(){
 const saved=introStatus(),count=introCount();
 return `${head('Für neue Mitglieder','Deine ersten Schritte','Hake ab, was Du bereits erledigt hast. Die Angaben bleiben ausschließlich in Deinem Browser auf diesem Gerät.')}
 <div class="panel" style="margin-bottom:15px"><div class="spread"><div><h2>Dein persönlicher Start</h2><span class="tiny">${count} von ${INTRO_STEPS.length} erledigt</span></div><span class="tag">${Math.round(count/INTRO_STEPS.length*100)} %</span></div><div class="progress-line"><div class="progress-fill" style="width:${count/INTRO_STEPS.length*100}%"></div></div></div>
 <div class="checklist">${INTRO_STEPS.map(([title,desc],i)=>`<label class="check-item"><input type="checkbox" data-step="${i}" ${saved[i]?'checked':''}><span><strong>${esc(title)}</strong><small>${esc(desc)}</small></span></label>`).join('')}</div>
 <div class="actions" style="margin-top:16px"><button id="clear-steps" class="btn quiet" type="button">Checkliste zurücksetzen</button><a href="#wegweiser" class="btn primary">Passenden Kontakt suchen →</a></div>`;
}
function info(){
 return `${head('Transparenz','Über den FW Kompass','Die erste umsetzbare Projektversion für den Landkreis Erding. Technisch bundesweit erweiterbar, derzeit eine nicht offizielle Demo.')}
 <div class="stack"><div class="panel"><h2>Was funktioniert bereits?</h2><ul class="bullets"><li>Responsives Design mit Navigation für Smartphone, Tablet und PC</li><li>Interaktiver Anliegen-Wegweiser mit Ebenen- und Ortsauswahl</li><li>Filterbare Kontaktübersicht, mit Links und E-Mail-Aktionen</li><li>Who-is-Who-Verzeichnis für Landtag, Bundes- und Landesvorstand</li><li>Bundesgremien-Wegweiser mit verifizierten BAGs und ausgewählten BFAs</li><li>Nachrichten mit Bundes-, Landes- und Landkreisfilter sowie Volltextsuche über den Demo-Bestand</li><li>Wissensbereich, öffentliche Ortslinks und lokale Einführung-Checkliste</li><li>Installationshilfe für Android und iPhone, Versionsanzeige und Update-Prüfung über den eigenen Server</li><li>Offline-Grundfunktionen nach erfolgter Installation und erstem Laden über HTTPS</li></ul></div>
 <div class="panel"><h2>Was ist noch nicht aktiv?</h2><p><strong>Automatischer News-Import:</strong> Noch keine bestätigte und freigegebene RSS-/API-Schnittstelle. Aktuell stehen ausgewählte, auf offiziellen Websites nachgelesene Meldungen in <code>data/news.json</code>. Der Server-Endpunkt <code>api/news.php</code> kann nach Konfiguration und Freigabe einen RSS-Feed einlesen. Termine werden derzeit nur verlinkt, nicht automatisiert.</p><p><strong>Mitglieder-Login:</strong> Bewusst nicht Bestandteil der Demo. Keine Mitgliederlisten oder Besucherprofile. Die optionale, ausschließlich aggregierte Reichweitenstatistik benötigt eine aktive Zustimmung.</p></div>
 <div class="panel"><h2>Offizielle Ausgangsquellen</h2><div class="source-strip">${SOURCE_LINKS.map(s=>external(s.url,s.label,'btn')).join('')}${external('https://www.fw-landkreis-erding.de/kontakt','Kontakt Erding','btn')}${external('https://www.freiewaehler.eu/services/kontakt/','Kontakt Bund','btn')}</div></div>
 <div class="padded-note">Für den späteren Einsatz durch die Organisation: offizielle Freigabe der Bezeichnung und Markenverwendung, Redaktion und Verantwortung klären, Verantwortliche Betreiberangaben im rechtlichen Bereich vervollständigen, Kontaktangaben regelmäßig prüfen und Übernahmen externer Inhalte rechtlich sowie technisch abstimmen.</div></div>`;
}

// Freiwillige, ausschließlich aggregierte Statistik. Ohne Opt-in: keine Ereignisse.
const STATS_PREF='fw-kompass-analytics-consent-v1';
let statsConsent=false;try{statsConsent=localStorage.getItem(STATS_PREF)==='yes'}catch{}
let visitRecorded=false,lastRouteRecorded='';
function track(type,category=''){
 if(!statsConsent || location.protocol!=='https:')return;
 const body=new URLSearchParams({type,category});
 fetch('./api/version.php?mode=stats&action=event',{method:'POST',body,credentials:'omit',cache:'no-store',keepalive:true}).catch(()=>{});
}
function maybeTrackRoute(id){
 if(!statsConsent)return;
 if(!visitRecorded){track('visit');visitRecorded=true;}
 if(id!==lastRouteRecorded&&id!=='statistik'){track('section',id);lastRouteRecorded=id;}
}
function setStatsChoice(allowed){
 statsConsent=allowed;
 try{localStorage.setItem(STATS_PREF,allowed?'yes':'no')}catch{}
 if(allowed){visitRecorded=false;lastRouteRecorded='';maybeTrackRoute(state.route);}
 draw();
}
document.addEventListener('click',event=>{
 if(!statsConsent)return;
 const a=event.target.closest('a[href]');if(!a)return;
 let u;try{u=new URL(a.href,location.href)}catch{return;}
 if(!['https:','http:'].includes(u.protocol)||u.origin===location.origin)return;
 const host=u.hostname;
 let category='sonstige';
 if(host.endsWith('freiewaehler.eu'))category='bund';
 else if(host.endsWith('fw-bayern.de'))category='bayern';
 else if(host.endsWith('fw-landkreis-erding.de'))category='erding';
 const download=a.hasAttribute('download')||/\.(?:pdf|zip|docx?|xlsx?|pptx?)(?:$|[?#])/i.test(u.pathname);
 track(download?'download':'external',category);
},true);

let legalConfig={configured:false};
const legalFields=['operator_name','street','postal','city','email','phone','editor_name','editor_address','hosting_logs'];
const publicValue=(key,fallback='Noch einzutragen')=>esc(legalConfig[key]||fallback);
async function loadLegal(){try{const r=await fetch('./api/version.php?mode=legal',{cache:'no-store'});if(r.ok){legalConfig=await r.json();if(state.route==='rechtliches')draw();}}catch{}}
function legalPage(){
 const ready=legalConfig.configured;
 const address=`${publicValue('street')}<br>${publicValue('postal')} ${publicValue('city')}`;
 const mail=legalConfig.email?`<a href="mailto:${esc(legalConfig.email)}">${esc(legalConfig.email)}</a>`:'<strong>E-Mail noch einzutragen</strong>';
 return `${head('Transparenz & rechtliche Angaben','Impressum & Datenschutz','Informationen zum FW Kompass, zum Betreiber und zur freiwilligen Nutzung der Statistik.')}
 ${ready?'':'<div class="alert orange"><strong>Betreiberangaben noch unvollständig.</strong> Der Betreiber muss sie vor einer offiziellen Veröffentlichung in der geschützten Statistikverwaltung ergänzen. Dieser Text ersetzt kein fertiges Impressum.</div>'}
 <section class="panel legal-document"><h2>Impressum</h2><p>Angaben nach § 5 Digitale-Dienste-Gesetz (DDG) und § 18 Medienstaatsvertrag (MStV), soweit jeweils anwendbar.</p>
 <h3>Anbieter / Verantwortlicher</h3><p><strong>${publicValue('operator_name')}</strong><br>${address}<br>E-Mail: ${mail}${legalConfig.phone?`<br>Telefon: ${esc(legalConfig.phone)}`:''}</p>
 <h3>Verantwortlich für journalistisch-redaktionelle Inhalte</h3><p>${publicValue('editor_name','Noch festzulegen (sofern § 18 Abs. 2 MStV einschlägig)')}<br>${publicValue('editor_address','Anschrift der verantwortlichen Person ergänzen, soweit erforderlich')}</p>
 <h3>Projektstatus</h3><p>FW Kompass ist ein eigenständig entwickeltes Pilotprojekt für den Landkreis Erding. Eine offizielle Herausgeberschaft oder Beauftragung durch die FREIEN WÄHLER wird nicht behauptet.</p>
 <h3>Externe Links und Inhalte</h3><p>Auf Drittseiten und deren Datenschutzbestimmungen haben wir keinen Einfluss. Offizielle Verbandsseiten werden als Quellen verlinkt.</p></section>
 <section class="panel legal-document"><h2>Datenschutzhinweise gemäß Art. 13 DSGVO</h2>
 <h3>1. Verantwortliche Stelle</h3><p>${publicValue('operator_name')} · ${address}. Kontakt: ${mail}.</p>
 <h3>2. Hosting und technische Zugriffe</h3><p>Die App wird über den deutschen Hostingdienst goneo bereitgestellt. Beim Abruf kann der Hoster technisch notwendige Verbindungsdaten (einschließlich IP-Adresse, Zeitpunkt und angeforderter Datei) verarbeiten. Zwecke: Bereitstellung und Sicherheit des Angebots; als mögliche Rechtsgrundlage kommt Art. 6 Abs. 1 lit. f DSGVO in Betracht. Die konkreten Speicherfristen und der Auftragsverarbeitungsvertrag müssen mit dem Anbieter abgeglichen werden.</p>
 <p><strong>Speicherfrist der Hosting-Logs:</strong> ${publicValue('hosting_logs','Noch mit goneo zu klären und nachzutragen')}.</p>
 <h3>3. Freiwillige Reichweitenstatistik</h3><p>Die FW-Kompass-Statistik ist standardmäßig ausgeschaltet. Erst nach deiner aktiven Zustimmung senden wir Ereignisse wie App-Aufruf, geöffneten Bereich, Klick auf einen externen Link oder Download-Link an unseren Server. Wir speichern nur <strong>summierte Tageszahlen</strong> und die grobe Zielkategorie (Bund, Bayern, Erding, sonstige). Keine Besucherkennung, IP-Adresse, Geräte-ID, Cookies oder personenbezogenen Nutzungsprofile in der Statistikdatei. Ein Personen- oder Mitgliederbezug wird nicht hergestellt. Die Auswertung ist auf 120 Tage ausgelegt; ältere Tageswerte werden bei der nächsten Statistik-Erfassung bereinigt.</p>
 <p>Du kannst die Zustimmung jederzeit unten zurücknehmen. Die Einstellung wird lokal auf deinem Gerät gespeichert. Ein Rückschluss auf bereits aggregierte Zahlen ist nicht möglich. Externe Anbieter wie Google Analytics oder Meta Pixel werden nicht eingesetzt.</p>
 <h3>4. Speicherung auf dem Gerät</h3><p>Als installierbare Web-App (PWA) verwendet der FW Kompass einen Service Worker und einen lokalen Cache für offline nutzbare Programmdateien. Die freiwillige Einsteiger-Checkliste wird nur gespeichert, wenn du die betreffenden Schritte auswählst. Die Statistik-Einstellung wird lokal gespeichert, sobald du dich entscheidest. Es werden keine Werbe-Cookies gesetzt. § 25 TDDDG ist bei Zugriffen auf das Endgerät zu beachten.</p>
 <h3>5. Externe Porträts und Verweise</h3><p>Porträtbilder im „Who is Who“ kommen teilweise von fremden Websites. Sie werden deshalb <strong>erst nach Tippen auf „Foto laden“</strong> angefordert. Dabei kann die Bildquelle technische Daten wie deine IP-Adresse erhalten. Beim Öffnen externer Links gelten die Hinweise der Zielseite.</p>
 <h3>6. Kontaktaufnahme</h3><p>Bei Kontaktaufnahme per E-Mail werden die übermittelten Angaben zur Bearbeitung deines Anliegens verwendet. Je nach Anlass kommen Art. 6 Abs. 1 lit. b oder f DSGVO in Betracht. Der Betreiber muss konkrete Löschfristen seiner Korrespondenz festlegen.</p>
 <h3>7. Deine Rechte</h3><p>Du hast – soweit die Voraussetzungen vorliegen – Rechte auf Auskunft, Berichtigung, Löschung, Einschränkung, Widerspruch, Datenübertragbarkeit und Widerruf erteilter Einwilligungen. Außerdem kannst du dich bei der zuständigen Datenschutzaufsichtsbehörde beschweren. Eine ausschließlich aggregierte Statistik kann nicht einzelnen Personen zugeordnet werden.</p>
 <h3>8. Automatisierte Entscheidungen und Datenübermittlungen</h3><p>Der FW Kompass trifft keine Entscheidungen mit rechtlicher Wirkung über Personen. Die optionalen externen Bildquellen und verlinkten Websites sind gesondert auf Datenübermittlungen außerhalb der EU zu prüfen.</p></section>
 <section class="panel" id="tracking-setting"><h2>Deine Statistik-Einstellung</h2><p>Nur mit deiner Zustimmung zählen wir anonyme Ereignisse für die Nutzungsauswertung. Ohne Zustimmung sendet die App keine Statistikereignisse.</p>
 <div class="privacy-actions"><button type="button" class="btn ${statsConsent?'quiet':'primary'}" id="allow-stats">Statistik erlauben</button><button type="button" class="btn ${!statsConsent?'quiet':'primary'}" id="deny-stats">Nicht erfassen</button></div>
 <p class="tiny" role="status" id="stats-choice">Aktueller Status: <strong>${statsConsent?'Erlaubt':'Ausgeschaltet'}</strong></p></section>
 <p class="legal-below">Stand: November 2026. Diese Datenschutzhinweise sind ein anpassbarer Entwurf; Betreiberidentität, Hosting-Logs, externe Dienste und redaktionelle Verantwortung müssen vor dem öffentlichen Regelbetrieb rechtlich geprüft werden.</p>
 <a href="#statistik" class="btn quiet">Geschützte Betreiberangaben & Statistik ↗</a>`;
}

const apiStats=(action,body=null)=>fetch(`./api/version.php?mode=stats&action=${action}`,{method:body?'POST':'GET',body:body?new URLSearchParams(body):undefined,credentials:'same-origin',cache:'no-store'}).then(async r=>{const data=await r.json();if(!r.ok)throw new Error(data.error||`HTTP ${r.status}`);return data;});
const statLabels={start:'Startseite',wegweiser:'Wegweiser',vorort:'FW vor Ort',news:'Aktuelles',kontakte:'Ansprechpartner',personen:'Who is Who',gremien:'Bundesgremien',termine:'Termine',wissen:'Wissen',einstieg:'Mein Einstieg',info:'Über das Projekt',rechtliches:'Rechtliches'};
let statSession={authenticated:false,csrf:''},statReport=null;
function statsPage(){
 const top=head('Administration','Statistik & Betreiberangaben','Geschützter Bereich. Anmeldung mit deinem bisherigen FW-Kompass-Administratorpasswort.');
 if(!statSession.authenticated)return `${top}<section class="panel"><h2>Anmelden</h2><form id="stats-login" class="stat-form"><label for="stats-password">Administratorpasswort</label><input id="stats-password" name="password" type="password" autocomplete="current-password" required minlength="12"/><button class="btn primary" type="submit">Statistik öffnen</button></form><p class="tiny">Der Statistikbereich hat aus technischen Gründen eine separate Sitzung. Dein bestehendes Passwort aus der Updateverwaltung gilt auch hier.</p><p id="stats-feedback" class="tiny" role="status"></p></section>`;
 if(!statReport)return `${top}<section class="panel"><p>Die Statistik wird geladen …</p><p id="stats-feedback" role="status"></p></section>`;
 const days=Object.entries(statReport.days||{}).sort((a,b)=>a[0].localeCompare(b[0]));
 const totals={visit:0,section:{},external:{},download:{},install:0};
 days.forEach(([,d])=>{totals.visit+=d.visit||0;totals.install+=d.install||0;for(const k of ['section','external','download'])Object.entries(d[k]||{}).forEach(([label,val])=>{totals[k][label]=(totals[k][label]||0)+val;});});
 const sum=x=>Object.values(x).reduce((a,b)=>a+b,0);
 const last=days.slice(-14);const max=Math.max(1,...last.map(([,v])=>v.visit||0));
 const chart=last.map(([day,v])=>`<div class="stat-bar-col"><div class="stat-bar" style="height:${Math.max(3,(v.visit||0)/max*120)}px" title="${esc(day)}: ${v.visit||0} Aufrufe"></div><small>${esc(day.slice(5))}</small></div>`).join('');
 const sections=Object.entries(totals.section).sort((a,b)=>b[1]-a[1]);
 const breakdown=sections.length?sections.map(([name,n])=>`<li><span>${esc(statLabels[name]||name)}</span><strong>${n}</strong></li>`).join(''):'<li>Noch keine Daten</li>';
 const legal=statReport.legal||{};
 const field=(key,label,required=false)=>`<label>${esc(label)}${required?' *':''}<input type="${key==='email'?'email':'text'}" name="${key}" maxlength="500" value="${esc(legal[key]||'')}" ${required?'required':''}/></label>`;
 return `${top}<div class="stat-mini-actions"><span class="tag">Summierte Daten · ${days.length} Tage</span><button class="btn small quiet" id="stats-refresh">Aktualisieren</button><button class="btn small quiet" id="stats-logout">Abmelden</button></div>
 <div class="stat-cards"><div><small>App-Aufrufe*</small><strong>${totals.visit}</strong></div><div><small>Bereichsaufrufe</small><strong>${sum(totals.section)}</strong></div><div><small>Externe Klicks</small><strong>${sum(totals.external)}</strong></div><div><small>Download-Klicks</small><strong>${sum(totals.download)}</strong></div><div><small>Installationsereignisse*</small><strong>${totals.install}</strong></div></div>
 <section class="panel"><h2>App-Aufrufe der letzten 14 Tage</h2><div class="stat-bars">${chart||'<p>Noch keine Daten.</p>'}</div><p class="tiny">* Aufrufe mit Zustimmung; keine eindeutigen Besucher. Installationen sind technisch nicht auf jedem Gerät messbar. Download-Klicks sind keine bestätigten Downloads. Statistiken sind nicht rückwirkend verfügbar.</p></section>
 <div class="split"><section class="panel"><h2>Bereiche</h2><ul class="stat-list">${breakdown}</ul></section><section class="panel"><h2>Externe Zielkategorien</h2><ul class="stat-list">${Object.entries(totals.external).map(([k,n])=>`<li><span>${esc(k)}</span><strong>${n}</strong></li>`).join('')||'<li>Keine Klicks</li>'}</ul><h2>Download-Klicks</h2><ul class="stat-list">${Object.entries(totals.download).map(([k,n])=>`<li><span>${esc(k)}</span><strong>${n}</strong></li>`).join('')||'<li>Keine Klicks</li>'}</ul></section></div>
 <section class="panel"><h2>Impressum und Verantwortliche pflegen</h2><p>Diese Angaben erscheinen nach dem Speichern öffentlich im Rechtliches-Bereich der App. Bitte trage den <strong>tatsächlich verantwortlichen Betreiber</strong> und eine ladungsfähige Anschrift ein – keine erfundenen oder privaten Mitgliederdaten.</p>
 <form id="legal-form" class="stat-form"><div class="legal-fields">${field('operator_name','Betreiber / Name oder Organisation',true)}${field('street','Straße und Hausnummer',true)}${field('postal','PLZ',true)}${field('city','Ort',true)}${field('email','Kontakt-E-Mail',true)}${field('phone','Telefon / unmittelbarer Kontaktweg')}${field('editor_name','Redaktionell verantwortlich (falls zutreffend)')}${field('editor_address','Anschrift des redaktionell Verantwortlichen')}${field('hosting_logs','Speicherfrist goneo-Serverlogs (noch zu prüfen)')}</div><button class="btn primary" type="submit">Rechtliche Angaben speichern</button></form><p id="stats-feedback" role="status" class="tiny"></p></section>
 <p class="tiny">Statistikdatei: ausschließlich aufsummierte Tageswerte, automatische Löschung nach 120 Tagen bei der nächsten Erfassung. Die Daten werden in einem gegen Webzugriffe geschützten Verzeichnis der Serverinstallation gespeichert.</p>`;
}
async function loadStatSession(){try{statSession=await apiStats('status');if(statSession.authenticated){statReport=await apiStats('read',{csrf:statSession.csrf});}if(state.route==='statistik')draw();}catch(e){if(state.route==='statistik'){const el=$('#stats-feedback');if(el)el.textContent='Statistik derzeit nicht erreichbar: '+e.message;}}}
function wireLegal(){
 $('#allow-stats')?.addEventListener('click',()=>setStatsChoice(true));
 $('#deny-stats')?.addEventListener('click',()=>setStatsChoice(false));
}
function wireStats(){
 $('#stats-login')?.addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget;const feedback=$('#stats-feedback');feedback.textContent='Anmeldung läuft …';try{await apiStats('login',{csrf:statSession.csrf,password:f.elements.password.value});await loadStatSession();}catch(err){feedback.textContent=err.message;}});
 $('#stats-refresh')?.addEventListener('click',()=>loadStatSession());
 $('#stats-logout')?.addEventListener('click',async()=>{await apiStats('logout',{csrf:statSession.csrf});statSession.authenticated=false;statReport=null;draw();});
 $('#legal-form')?.addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget;const data={csrf:statSession.csrf};for(const name of legalFields)data[name]=f.elements[name].value;const fb=$('#stats-feedback');fb.textContent='Speichert …';try{await apiStats('save_legal',data);await loadLegal();fb.textContent='Betreiberangaben gespeichert.';}catch(err){fb.textContent='Fehler: '+err.message;}});
}

function draw(){
 const hash=location.hash.slice(1).toLowerCase();state.route=ROUTES.some(r=>r.id===hash)?hash:'start';nav();
 const views={start,wegweiser:guide,vorort:localGroups,news,kontakte:contacts,personen:whoIsWho,gremien:federalBodies,termine:events,wissen:knowledge,einstieg:onboarding,info,rechtliches:legalPage,statistik:statsPage};
 $('#view').innerHTML=(state.loadError?'<div class="alert orange">Einige lokale Datendateien konnten nicht geladen werden. Bitte die App über HTTPS oder einen lokalen Webserver öffnen – nicht direkt mit file://.</div>':'')+views[state.route]();
 wire();
 maybeTrackRoute(state.route);
}

function wire(){
 if(state.route==='rechtliches')wireLegal();
 if(state.route==='statistik')wireStats();
 if(state.route==='start'){
  const install=$('#install-app-btn'); if(install)install.addEventListener('click',installApp);
  $('#check-app-updates')?.addEventListener('click',()=>checkForUpdate(true));
  $('#apply-app-update')?.addEventListener('click',applyUpdate);
  updateUi();
 }
 if(state.route==='news'){
  document.querySelectorAll('[data-news-level]').forEach(btn=>btn.addEventListener('click',()=>{state.newsLevel=btn.dataset.newsLevel;draw();}));
  $('#news-search').addEventListener('input',event=>{state.newsQuery=event.target.value;updateNewsList();});
  $('#news-reload').addEventListener('click',async()=>{
   if(state.newsRefreshing)return;state.newsRefreshing=true;$('#news-reload').disabled=true;$('#news-reload').textContent='↻ Lädt …';
   try{const response=await fetch('./api/news.php?client_reload='+Date.now(),{cache:'no-store'});if(!response.ok)throw new Error('HTTP '+response.status);const fresh=await response.json();if(!fresh||!Array.isArray(fresh.articles))throw new Error('Keine gültigen Nachrichten');state.data.news=fresh;}
   catch(e){try{const response=await fetch('./data/news.json?client_reload='+Date.now(),{cache:'no-store'});if(!response.ok)throw new Error('HTTP '+response.status);const fallback=await response.json();if(!fallback||!Array.isArray(fallback.articles))throw new Error();state.data.news=fallback;}catch(err){console.warn('Keine neue Nachrichtenliste verfügbar',e,err);}}
   finally{state.newsRefreshing=false;draw();}
  });
 }
 if(state.route==='vorort'){
  $('#local-search').addEventListener('input',event=>{state.localQuery=event.target.value;refreshLocal();});
  $('#local-filter').addEventListener('change',event=>{state.localFilter=event.target.value;refreshLocal();});
  refreshLocal();
 }
 if(state.route==='gremien'){
  document.querySelectorAll('[data-gremien-tab]').forEach(btn=>btn.addEventListener('click',()=>{state.gremienGroup=btn.dataset.gremienTab;draw();}));
  $('#gremien-search').addEventListener('input',e=>{state.gremienQuery=e.target.value;refreshGremien();});refreshGremien();
 }
 if(state.route==='personen'){
  document.querySelectorAll('[data-people-tab]').forEach(btn=>btn.addEventListener('click',()=>{state.peopleGroup=btn.dataset.peopleTab;draw();}));
  $('#people-search').addEventListener('input',event=>{state.peopleQuery=event.target.value;refreshPeople();});refreshPeople();
 }
 if(state.route==='kontakte'){
  document.querySelectorAll('[data-contact-level]').forEach(btn=>btn.addEventListener('click',()=>{state.contactLevel=btn.dataset.contactLevel;draw();}));
  $('#contact-search').addEventListener('input',event=>{state.contactQuery=event.target.value;updateContactList();});
 }
 if(state.route==='wissen'){$('#resource-search').addEventListener('input',event=>{state.resourceQuery=event.target.value;updateResourceList();});}
 if(state.route==='wegweiser'){
  ['topic','level','town'].forEach(key=>$('#guide-'+key).addEventListener('change',e=>{state['guide'+key[0].toUpperCase()+key.slice(1)]=e.target.value;$('#guide-result').innerHTML=guideResult();}));
 }
 if(state.route==='einstieg'){
  document.querySelectorAll('[data-step]').forEach(input=>input.addEventListener('change',e=>{const values=introStatus();values[e.target.dataset.step]=e.target.checked;try{localStorage.setItem(LOCAL_KEY,JSON.stringify(values));}catch{}draw();}));
  $('#clear-steps').addEventListener('click',()=>{if(confirm('Deine Checkliste wirklich zurücksetzen?')){try{localStorage.removeItem(LOCAL_KEY);}catch{}draw();}});
 }
}
function updateNewsList(){const articles=sortedNews();$('#news-list').innerHTML=articles.length?articles.map(newsCard).join(''):'<div class="empty">Keine Meldungen gefunden.</div>';$('#news-result-count').textContent=`${articles.length} ${articles.length===1?'Meldung':'Meldungen'} · Neueste zuerst`; }
function updateContactList(){const contacts=state.data.contacts.filter(c=>(state.contactLevel==='all'||c.level===state.contactLevel)&&(`${c.name} ${c.role} ${c.organization}`.toLowerCase().includes(state.contactQuery.toLowerCase())));$('#contact-list').innerHTML=contacts.length?contacts.map(contactCard).join(''):'<div class="empty">Keine Kontakte gefunden.</div>';}
function updateResourceList(){const r=state.data.resources.filter(x=>`${x.title} ${x.description} ${x.category}`.toLowerCase().includes(state.resourceQuery.toLowerCase()));$('#resource-list').innerHTML=r.length?r.map(x=>`<article class="resource-card"><span class="badgel">${esc(x.category)}</span><h3>${esc(x.title)}</h3><p>${esc(x.description)}</p>${external(x.url,'Offizielle Website öffnen')}</article>`).join(''):'<div class="empty">Keine Links gefunden.</div>';}
async function dataFetch(path,fallBack){try{const res=await fetch(path,{cache:'no-cache'});if(!res.ok)throw new Error(`HTTP ${res.status}`);return await res.json()}catch(e){state.loadError=true;console.warn('FW Kompass Daten konnten nicht geladen werden',path,e);return fallBack;}}
// --- PWA-Installation und selbst gehosteter Update-Service v0.3 ---
// Es gibt keine Mitglieder-Accounts und keine Push-Überwachung. Die Prüfung erfolgt nur,
// wenn die App läuft (beim Start, Wiederöffnen, Onlinegehen und alle 15 Minuten).
let installPrompt=null;
let installedMode=window.matchMedia('(display-mode: standalone)').matches || navigator.standalone===true;
let registration=null;
let availableUpdate=null;
let checking=false;
let lastChecked='Noch nicht geprüft';
let updateMessage='';
let dismissForVersion=null;
const UPDATE_PERIOD_MS=15*60*1000;
const sameVersion=(a,b)=>String(a||'').trim()===String(b||'').trim();
function newerVersion(latest,current){
 const parse=s=>/^\d+\.\d+\.\d+$/.test(s)?s.split('.').map(Number):null;
 const a=parse(latest),b=parse(current);if(!a||!b)return false;
 for(let i=0;i<3;i++){if(a[i]>b[i])return true;if(a[i]<b[i])return false;}return false;
}
function updateUi(){
 const installButton=$('#install-app-btn');
 if(installButton){installButton.disabled=installedMode;installButton.textContent=installedMode?'Bereits installiert':'App installieren';}
 const install=$('#install-app-state');
 if(install)install.textContent=installedMode?'Die App läuft bereits im installierten Modus.':installPrompt?'Dein Browser bietet die direkte Installation an.':'Keine direkte Installationsabfrage verfügbar? Der Knopf zeigt Dir die manuellen Schritte.';
 const checker=$('#update-check-state');
 if(checker)checker.textContent=checking?'Suche nach Updates …':availableUpdate?(availableUpdate.version==='neu'?'Ein Browser-Update ist verfügbar.':`Version v${availableUpdate.version} ist verfügbar. ${availableUpdate.notes||''}`):updateMessage||`Installierte Webversion v${APP_VERSION} · ${lastChecked}`;
 const apply=$('#apply-app-update');
 if(apply)apply.hidden=!availableUpdate;
 const banner=$('#update-banner');
 if(banner){
  banner.hidden=!availableUpdate||dismissForVersion===availableUpdate.version;
  if(!banner.hidden)$('#update-banner-text').textContent=availableUpdate.version==='neu'?'Eine neue Browser-Version der App ist bereit.':`Version v${availableUpdate.version} ist bereit. Du kannst jetzt aktualisieren.`;
 }
}
function showInstallHelp(){
 const help=$('#install-app-help');
 if(help){help.hidden=false;help.scrollIntoView({block:'nearest',behavior:'smooth'});}
}
async function installApp(){
 if(installedMode){showInstallHelp();return;}
 if(!installPrompt){showInstallHelp();return;}
 const prompt=installPrompt;installPrompt=null;
 try{await prompt.prompt();await prompt.userChoice;}catch(e){console.warn('Installationsdialog nicht verfügbar',e);showInstallHelp();}
 updateUi();
}
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installPrompt=event;updateUi();});
window.addEventListener('appinstalled',()=>{track('install');installedMode=true;installPrompt=null;updateUi();});
function watchRegistration(reg){
 registration=reg;
 const inspect=()=>{
  if(reg.waiting && navigator.serviceWorker.controller){
   if(!availableUpdate)availableUpdate={version:'neu',notes:'Eine App-Aktualisierung wurde vom Browser geladen.'};
   updateUi();
  }
 };
 inspect();
 reg.addEventListener('updatefound',()=>{
  const worker=reg.installing;if(!worker)return;
  worker.addEventListener('statechange',()=>{if(worker.state==='installed')inspect();});
 });
}
let waitingForControlledUpdate=false;
if('serviceWorker' in navigator){
 navigator.serviceWorker.addEventListener('controllerchange',()=>{
  if(waitingForControlledUpdate){waitingForControlledUpdate=false;window.location.reload();}
 });
}
async function retrieveRelease(){
 for(const source of ['./api/version.php','./release.json']){
  try{
   const url=source+'?t='+Date.now();
   const response=await fetch(url,{cache:'no-store',headers:{'Accept':'application/json'}});
   if(!response.ok)continue;
   const obj=await response.json();
   if(/^\d+\.\d+\.\d+$/.test(String(obj.version||'')))return obj;
  }catch(e){/* PHP may be unavailable; static JSON still works. */}
 }
 throw new Error('Versionsdatei nicht erreichbar');
}
async function checkForUpdate(manual=false){
 if(checking)return;
 checking=true;if(manual)updateMessage='';updateUi();
 try{
  const release=await retrieveRelease();
  lastChecked=`Zuletzt geprüft: ${new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})}`;
  if(newerVersion(release.version,APP_VERSION)){
   availableUpdate={version:release.version,notes:typeof release.notes==='string'?release.notes.slice(0,180):''};
   updateMessage='Neue Version bereit';
   if(registration)await registration.update().catch(()=>{});
  } else {
   if(!availableUpdate||availableUpdate.version!=='neu')availableUpdate=null;
   updateMessage=`Du nutzt Version v${APP_VERSION}. Alles aktuell. ${lastChecked}`;
  }
 }catch(e){updateMessage=`Update-Prüfung nicht möglich (offline oder Versionsdatei nicht erreichbar). ${lastChecked}`;}
 finally{checking=false;updateUi();}
}
async function applyUpdate(){
 if(!availableUpdate)return;
 updateMessage='Update wird vorbereitet …';updateUi();
 try{
  if(registration){
   await registration.update();
   if(registration.waiting){
    waitingForControlledUpdate=true;
    registration.waiting.postMessage({type:'SKIP_WAITING'});
    // controllerchange triggers reload; avoid forced refresh before the worker is active.
    return;
   }
  }
  // Without a waiting worker the browser may need another start after the upload.
  // This reload uses a cache-busted URL so HTML is retrieved afresh.
  window.location.href='./index.html?updated='+Date.now()+window.location.hash;
 }catch(e){updateMessage='Aktualisierung fehlgeschlagen. Bitte erneut prüfen oder die Seite in Chrome neu laden.';updateUi();}
}
$('#update-banner-go')?.addEventListener('click',applyUpdate);
$('#update-banner-later')?.addEventListener('click',()=>{dismissForVersion=availableUpdate?.version||null;updateUi();});
function setupPwa(){
 if('serviceWorker' in navigator && location.protocol==='https:'){
  navigator.serviceWorker.register('./sw.js',{scope:'./',updateViaCache:'none'})
   .then(watchRegistration).catch(error=>console.warn('Service Worker konnte nicht registriert werden',error));
 }
 checkForUpdate();
 setInterval(()=>{if(!document.hidden)checkForUpdate();},UPDATE_PERIOD_MS);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)checkForUpdate();});
 window.addEventListener('online',()=>checkForUpdate());
}

async function init(){
 if(window.__FW_DATA__){state.data=window.__FW_DATA__;window.addEventListener('hashchange',()=>{draw();window.scrollTo(0,0);});draw();setupPwa();return;}
 const [news,contacts,regions,resources]=await Promise.all([
  dataFetch('./api/news.php',{metadata:{},articles:[]}),
  dataFetch('./data/contacts.json',[]),dataFetch('./data/regions.json',{towns:[]}),dataFetch('./data/resources.json',[])
 ]);
 // Static hosts without PHP should use news.json. A PHP host returns JSON from api/news.php.
 let result=news;
 if(state.loadError||!Array.isArray(news.articles)){state.loadError=false;result=await dataFetch('./data/news.json',{metadata:{},articles:[]});}
 state.data={news:result,contacts,regions,resources};
 window.addEventListener('hashchange',()=>{draw();if(state.route==='statistik')loadStatSession();window.scrollTo({top:0,behavior:'instant'});});
 draw();
 setupPwa();
 loadLegal();
 if(location.hash==='#statistik')loadStatSession();
}
init();

/* FW Kompass v0.4 – zeigt das unveränderte Original-Logo nur, wenn es unter assets/fw-logo-offiziell.png abgelegt ist. */
for(const logo of document.querySelectorAll('.fw-official-logo')){
 const show=()=>logo.parentElement?.classList.add('logo-ready');
 const hide=()=>logo.parentElement?.classList.remove('logo-ready');
 logo.addEventListener('load',show);logo.addEventListener('error',hide);
 if(logo.complete && logo.naturalWidth>0)show();
}
