// Stand 07.11.2026 · öffentlich nachgeprüfte Bundesgremien. Keine automatische Synchronisation.
const GREMIEN = {
  "updated": "2026-11-07",
  "bag": [
    {
      "name": "BAG Menschen mit Behinderungen",
      "description": "Inklusion, Barrierefreiheit, selbstbestimmte Teilhabe und gleichberechtigte politische Mitwirkung.",
      "chair": "Stephan Weindler",
      "email": "bag-mmb@freiewaehler.eu",
      "url": "https://www.freiewaehler.eu/bag/schwerpunkte/bundesarbeitsgemeinschaft-menschen-mit-behinderungen/"
    },
    {
      "name": "BAG Frauen",
      "description": "Gleichstellung, Chancengleichheit und Beteiligung von Frauen in Politik und Gesellschaft.",
      "chair": "Silvia Zschocke",
      "email": "frauen@freiewaehler.eu",
      "url": "https://www.freiewaehler.eu/bag/schwerpunkte/bundesarbeitsgemeinschaft-frauen/"
    },
    {
      "name": "BAG Senioren",
      "description": "Interessen älterer Menschen, gesellschaftliche Teilhabe, Rente, Gesundheit und Generationengerechtigkeit.",
      "chair": "Walter Bertl",
      "email": "senioren@freiewaehler.eu",
      "url": "https://www.freiewaehler.eu/bag/schwerpunkte/bundesarbeitsgemeinschaft-senioren/"
    },
    {
      "name": "BAG Queer",
      "description": "Gleichberechtigte Teilhabe, Vielfalt und Rechte von LSBTIQ*-Menschen.",
      "chair": "Daniel Meincke",
      "email": "queer@freiewaehler.eu",
      "url": "https://www.freiewaehler.eu/mitmachen/bag/"
    }
  ],
  "bfa": [
    {
      "name": "BFA Soziales, Gesundheit und Pflege",
      "description": "Sozial-, Gesundheits- und Pflegepolitik, Versorgung, Teilhabe sowie inhaltliche Positionsarbeit.",
      "chair": "Stephan Weindler",
      "url": "https://www.freiewaehler.eu/aktuelles/bundesparteitag-nuernberg-freie-waehler-ehren-karina-luginger/",
      "linkLabel": "Zum BFA-Hintergrund"
    },
    {
      "name": "BFA Wirtschaft",
      "description": "Wirtschafts- und Mittelstandspolitik, Wettbewerbsfähigkeit und wirtschaftspolitische Positionsarbeit.",
      "chair": "Holger Riedelbauch",
      "url": "https://www.freiewaehler.eu/aktuelles/respekt-vor-dem-steuerzahler/",
      "linkLabel": "Zum Positionsbeitrag"
    },
    {
      "name": "BFA Land-, Forstwirtschaft und Umwelt",
      "description": "Landwirtschaft, Forstwirtschaft, Natur, Umwelt und ländlicher Raum.",
      "chair": "Birgit Weinsteiger",
      "url": "https://www.freie-waehler-frauen-bayern.de/aktuelles/aktuelles-details/neue-vorsitzende-fuer-den-bundesfachausschuss-land-forstwirtschaft-und-umwelt",
      "linkLabel": "Meldung zur Besetzung"
    },
    {
      "name": "BFA Sicherheit",
      "description": "Sicherheitspolitische Themen und digitale Resilienz. Ein aktueller Vorsitz ist öffentlich nicht eindeutig bestätigt.",
      "chair": null,
      "url": "https://www.freiewaehler.eu/services/dokumente/",
      "linkLabel": "Offizielle Dokumente"
    }
  ]
};
export default GREMIEN;
