import {pushPanel,pushAdminPanel,wirePush,subscribeFromWelcome} from './push.js?v=1.3.13';
import WHO from './who.js?v=1.3.13';
import GREMIEN from './gremien.js?v=1.3.13';
import ORTE from './ortsvereine.js?v=1.3.13';
/** FW Kompass: öffentlich gestartetes Pilotprojekt; keine Drittanbieter-Analytics-Bibliothek. */
const APP_VERSION='1.3.13';
const RELEASE_DATE='08.11.2026';
const ROUTES = [
  {id:'start',label:'Start',icon:'⌂',sub:'Dein Überblick'},
  {id:'wegweiser',label:'Wegweiser',icon:'◇',sub:'Wohin mit meiner Frage?'},
  {id:'mitglied',label:'Mitglied werden',icon:'+',sub:'Partei oder örtliche Wählergemeinschaft'},
  {id:'news',label:'Aktuelles',icon:'▤',sub:'Bund, Bayern, Erding'},
  {id:'gedenken',label:'In stillem Gedenken',icon:'♡',sub:'Nachruf auf Hubert Aiwanger'},
  {id:'mdl',label:'MdL Aktuell',icon:'◎',sub:'Instagram und offizielle Veröffentlichungen'},
  {id:'mitteilungen',label:'Mitteilungen',icon:'♧',sub:'App-Neuigkeiten & Updates'},
  {id:'kontakte',label:'Ansprechpartner',icon:'♧',sub:'Finde die richtige Stelle'},
  {id:'vorort',label:'FW vor Ort',icon:'⌖',sub:'Ortsgruppen im Landkreis Erding'},
  {id:'struktur',label:'Partei oder Verband?',icon:'▥',sub:'Landesvereinigung und Landesverband'},
  {id:'personen',label:'Who is Who',icon:'♙',sub:'Abgeordnete & Vorstände'},
  {id:'gremien',label:'Bundesgremien',icon:'♧',sub:'BFA & BAG kennenlernen'},
  {id:'termine',label:'Termine',icon:'▦',sub:'Veranstaltungen & Kalender'},
  {id:'wissen',label:'Wissen',icon:'▣',sub:'Organisation & Links'},
  {id:'einstieg',label:'Mein Einstieg',icon:'✓',sub:'Checkliste für Mitglieder'},
  {id:'info',label:'Über das Projekt',icon:'ⓘ',sub:'Hinweise & Quellen'},
  {id:'rechtliches',label:'Rechtliches',icon:'ⓘ',sub:'Impressum & Datenschutz'},
  {id:'statistik',label:'Statistik',icon:'▥',sub:'Geschützter Admin-Bereich'},
  {id:'redaktion',label:'Redaktion',icon:'▤',sub:'Geschützter Beitragseditor'}
];
const ICON_SVG={
  start:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
  mitglied:'<circle cx="9" cy="8" r="3"/><path d="M3 20v-2c0-3 2.5-5 6-5 2.2 0 4 .8 5 2M18 7v8M14 11h8"/>',
  wegweiser:'<circle cx="12" cy="12" r="9"/><path d="m15.9 8.1-2.4 5.4-5.4 2.4 2.4-5.4z"/>',
  news:'<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M8 7h8M8 11h8M8 15h5M8 18h8"/>',
  gedenken:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
  mdl:'<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="0.75"/>',
  mitteilungen:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
  kontakte:'<circle cx="12" cy="8" r="3"/><path d="M5 21v-2c0-3 3-5 7-5s7 2 7 5v2M4 8h3M17 8h3"/>',
  struktur:'<rect x="3" y="4" width="7" height="7" rx="1"/><rect x="14" y="4" width="7" height="7" rx="1"/><path d="M6.5 11v4H17.5v-4M12 15v5m-4 0h8"/>',
  vorort:'<path d="M3 20h18M5 20V8l7-4 7 4v12M9 12h2v2H9zM13 12h2v2h-2zM10 20v-4h4v4"/>',
  gremien:'<path d="M3 5h7v6H3zM14 5h7v6h-7zM8 15h8v6H8zM6.5 11v2h11v-2M12 13v2"/>',
  personen:'<circle cx="12" cy="8" r="3"/><path d="M5 21v-2c0-3 3-5 7-5s7 2 7 5v2"/><path d="M18 3h3M19.5 1.5v3"/>',
  termine:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18M8 15h3"/>',
  wissen:'<path d="M12 6c-3-2-6-2-9-1v15c3-1 6-1 9 1 3-2 6-2 9-1V5c-3-1-6-1-9 1zM12 6v15"/>',
  einstieg:'<circle cx="12" cy="12" r="9"/><path d="m7 12 3 3 7-7"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
  statistik:'<rect x="4" y="10" width="4" height="11"/><rect x="10" y="5" width="4" height="16"/><rect x="16" y="2" width="4" height="19"/>',
  rechtliches:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
  updates:'<path d="M20 8v-4h-4M20 4a9 9 0 0 0-15 4M4 16v4h4M4 20a9 9 0 0 0 15-4"/>'
};
const iconFor=id=>`<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON_SVG[id]||ICON_SVG.info}</svg>`;
const SOURCE_LINKS=[
  {label:'Bundesvereinigung',url:'https://www.freiewaehler.eu/bund/pressemitteilungen/'},
  {label:'Bayern',url:'https://www.fw-bayern.de/aktuelles/mitteilungen'},
  {label:'Landkreis Erding',url:'https://www.fw-landkreis-erding.de/aktuelles'}
];
const INTRO_STEPS = [
  ['Aufbau kennenlernen','Bundesvereinigung, Landesvereinigung und Kreisstrukturen unterscheiden.'],
  ['Meine lokale Anlaufstelle finden','Ortsgruppe oder Kreisvereinigung über FW vor Ort suchen.'],
  ['Mitgliedschaft klären','Partei und kommunale Wählergemeinschaft nicht verwechseln.'],
  ['Aktuelle Informationsquellen öffnen','Regionale, bayerische und bundesweite Meldungen finden.'],
  ['Passenden Arbeitsbereich entdecken','BFA und BAG kennenlernen und einen passenden thematischen Arbeitsbereich auswählen.'],
  ['Ersten Kontakt aufnehmen','Die zuständige Geschäftsstelle oder Ansprechperson kontaktieren.']
];
const PURPOSES={
  mitgliedschaft:{title:'Mitgliedschaft und Aufnahme',text:'Ob Du Mitglied der politischen Partei oder einer kommunalen Wählergemeinschaft werden möchtest, entscheidet, welche Organisation zuständig ist. Beginne im Landkreis bei der Kreisvereinigung beziehungsweise dem jeweiligen Ortsverein.',topics:['mitgliedschaft'],level:'erding'},
  ortsverband:{title:'Politik in meiner Gemeinde',text:'Die öffentlichen Websites der örtlichen Gruppen sind ein guter Einstieg. Nicht jede Ortsgruppe ist identisch mit einer Parteigliederung – bitte die Mitgliedsform erfragen.',topics:['ortsverband'],level:'erding'},
  gremien:{title:'In Fachgremien mitarbeiten',text:'Auf Bundesebene gibt es Bundesfachausschüsse (BFA) und Bundesarbeitsgemeinschaften (BAG). Die Mitwirkung in einem BFA richtet sich nach den Vorgaben des Bundesvorstandes; die BAGs bieten thematische Beteiligung. Der neue Bereich Bundesgremien hilft bei der Suche.',topics:['gremien'],level:'bund'},
  presse:{title:'Presse und Öffentlichkeitsarbeit',text:'Für veröffentlichungsreife politische Statements ist die zuständige Presse-/Geschäftsstelle auf der entsprechenden Organisationsebene der richtige Startpunkt.',topics:['presse'],level:'bayern'},
  veranstaltung:{title:'Veranstaltung oder Sitzung organisieren',text:'Für lokale Veranstaltungen zuerst die Kreisgeschäftsstelle ansprechen. Überregionale Termine mit der betreffenden Landes- oder Bundesgeschäftsstelle abstimmen.',topics:['veranstaltung','termin'],level:'erding'},
  verwaltung:{title:'Satzungen und Verwaltung',text:'Formulare, Satzungen und Zuständigkeiten solltest Du immer über die aktuelle offizielle Geschäftsstelle oder die dort verlinkten Downloads prüfen.',topics:['verwaltung'],level:'erding'}
};
const LEVELS={all:'Alle Ebenen',erding:'Landkreis Erding',bayern:'Bayern',bund:'Bund'};
const LOCAL_KEY='fw-kompass-pilot-steps-v1';
const state={gremienGroup:'bag',gremienQuery:'',peopleGroup:'landtag',peopleQuery:'',newsRefreshing:false,newsFetchError:'',route:'start',localQuery:'',localFilter:'all',newsLevel:'all',contactLevel:'all',contactQuery:'',guideTopic:'mitgliedschaft',guideLevel:'erding',guideTown:'',resourceQuery:'',newsQuery:'',data:{news:{metadata:{},articles:[]},contacts:[],regions:{towns:[]},resources:[]},loadError:false};
const $=s=>document.querySelector(s);
const esc=(value)=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const safeUrl=(url)=>{try{const value=new URL(String(url));return value.protocol==='https:'?value.href:'#';}catch{return '#';}};
const date=(d)=>{const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(d||'');return m?`${m[3]}.${m[2]}.${m[1]}`:esc(d||'');};
const external=(url,label,cl='text-link')=>`<a class="${cl}" href="${esc(safeUrl(url))}" target="_blank" rel="noopener noreferrer">${esc(label)} <span aria-hidden="true">↗</span></a>`;
const head=(kicker,title,subtitle)=>`<section class="section-intro"><div class="eyebrow">${esc(kicker)}</div><h1>${esc(title)}</h1><p>${esc(subtitle)}</p></section>`;
const sectionLine=(title,meta='')=>`<div class="section-line"><h2>${esc(title)}</h2>${meta?`<small>${esc(meta)}</small>`:''}</div>`;
const publicNewsArticles=()=>{const news=state.data.news||{};const articles=Array.isArray(news.articles)?news.articles:[];return articles.filter(a=>a&&a.demo!==true);};
const newArticle=a=>{if(!a.date)return false;const published=new Date(`${a.date}T12:00:00`);const age=Date.now()-published.getTime();return Number.isFinite(age)&&age>=0&&age<7*24*3600*1000;};
const newsCard=(a)=>`<article class="news-card" data-stat-kind="news" data-stat-id="${esc(a.id||'')}" data-stat-title="${esc(a.title)}"><div class="card-head"><span class="badgel ${esc(a.level)}">${esc(LEVELS[a.level]||a.level)}</span><div class="news-date">${newArticle(a)?'<span class="new-marker">NEU</span>':''}<time datetime="${esc(a.date)}" class="date">${date(a.date)}</time></div></div><h3>${esc(a.title)}</h3><p>${esc(a.excerpt||'')}</p>${external(a.url,'Zur offiziellen Quelle')}</article>`;
const contactCard=(c)=>`<article class="contact-card"><span class="badgel ${esc(c.level)}">${esc(LEVELS[c.level]||c.level)}</span><h3>${esc(c.name)}</h3><div class="contact-role">${esc(c.role)}</div><p style="margin-top:9px">${esc(c.organization)}</p><div class="actions">${external(c.url,'Kontaktseite','btn small')}${c.email?`<a href="mailto:${esc(c.email)}" class="btn small quiet">✉ E-Mail</a>`:''}</div>${c.note?`<div class="meta-line"><span>${esc(c.note)}</span></div>`:''}</article>`;
function introStatus(){let saved={};try{saved=JSON.parse(localStorage.getItem(LOCAL_KEY)||'{}')}catch{};return saved;}
function introCount(){return INTRO_STEPS.filter((_,i)=>introStatus()[i]).length;}
function nav(){
 const desktop=$('#side-nav'),mobile=$('#bottom-nav');
 desktop.innerHTML=ROUTES.filter(r=>!['statistik','redaktion','gedenken'].includes(r.id)).map(r=>`<a class="nav-item ${state.route===r.id?'active':''}" href="#${r.id}" ${state.route===r.id?'aria-current="page"':''}><span class="nav-icon" aria-hidden="true">${iconFor(r.id)}</span><span>${r.label}</span></a>`).join('');
 mobile.innerHTML=ROUTES.filter(r=>['start','wegweiser','news','kontakte','personen'].includes(r.id)).map(r=>`<a class="nav-item ${state.route===r.id?'active':''}" href="#${r.id}" ${state.route===r.id?'aria-current="page"':''}><span class="nav-icon" aria-hidden="true">${iconFor(r.id)}</span><span>${r.label}</span></a>`).join('');
 $('#crumb').textContent=ROUTES.find(r=>r.id===state.route)?.label||'Übersicht';
}
function start(){
 const articles=[...publicNewsArticles()].sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))).slice(0,2);
 const count=introCount();
 const tiles=ROUTES.filter(r=>['mitglied','wegweiser','vorort','struktur','news','mitteilungen','kontakte','personen','mdl','gremien','termine','wissen','einstieg'].includes(r.id));
 return `<section class="hero"><div class="hero-kicker"><span>FW KOMPASS</span><span>LANDKREIS ERDING</span></div><div class="hero-inner"><div class="eyebrow">ORIENTIERUNG FÜR NEUE UND AKTIVE MITGLIEDER</div><h1>Gut informiert.<br><span class="hero-accent">Gemeinsam aktiv.</span></h1><p>Der direkte Weg zu Ansprechpartnern, aktuellen Meldungen und Möglichkeiten zur Mitarbeit bei den FREIEN WÄHLERN.</p><div class="hero-actions"><a class="btn primary" href="#mitglied">Mitglied werden <span aria-hidden="true">→</span></a><a class="btn" href="#wegweiser">Wegweiser starten <span aria-hidden="true">→</span></a><a class="btn" href="#vorort">FW vor Ort <span aria-hidden="true">↗</span></a></div></div><div class="hero-footer">PILOTPROJEKT <span aria-hidden="true">/</span> LANDKREIS ERDING</div></section>
 <div class="release-line"><span class="release-pill">FW Kompass · Version ${APP_VERSION}</span><span>Öffentlich gestartet · Pilotprojekt Landkreis Erding</span></div>
 <div class="privacy-quick"><span><strong>Datensparsam:</strong> Die freiwillige Reichweitenstatistik ist zunächst ausgeschaltet.</span><a href="#rechtliches">Datenschutz &amp; Statistik-Einstellungen ↗</a></div>
 ${noticeHomeTeaser()}
 ${memorialHomeTeaser()}
 <a class="structure-home-teaser" href="#struktur"><span class="structure-home-icon">${iconFor('struktur')}</span><span><strong>Landesverband oder Landesvereinigung?</strong><small>Was ist eine kommunale Wählergemeinschaft – und was die Partei? Hier findest Du die Unterschiede laut Satzungen.</small></span><span aria-hidden="true" class="structure-home-arrow">→</span></a>
 ${sectionLine('Finde deinen Weg',tiles.length+' Bereiche')}
 <div class="tiles">${tiles.map(t=>`<a class="tile" href="#${t.id}"><span class="tile-icon">${iconFor(t.id)}</span><strong>${esc(t.label)}</strong><small>${esc(t.sub)}</small></a>`).join('')}</div>
 ${sectionLine('Dein FW Kompass auf einen Blick')}
 <div class="split"><div class="panel"><div class="spread"><h2>Dein Einstieg</h2><span class="tag">${count} von ${INTRO_STEPS.length} Schritten</span></div><p>Mit unserer Checkliste behältst Du alles im Blick. Dein Fortschritt bleibt nur auf diesem Gerät gespeichert.</p><div class="progress-line"><div class="progress-fill" style="width:${count/INTRO_STEPS.length*100}%"></div></div><a href="#einstieg" class="text-link">Checkliste öffnen →</a></div>
 <div class="panel"><h2>Offizielle Nachrichtenquellen</h2><p>Aktuelles aus dem Landkreis, der Landes- und der Bundesvereinigung an einer Stelle finden.</p><div class="source-strip">${SOURCE_LINKS.map(s=>external(s.url,s.label,'btn small')).join('')}</div></div></div>
 ${sectionLine('Ausgewählte Meldungen','Aus offiziellen Quellen')}
 <div class="cards">${articles.map(newsCard).join('')||'<div class="empty">Noch keine Meldungen hinterlegt.</div>'}</div><div style="margin-top:14px"><a href="#news" class="text-link">Alle ausgewählten Meldungen ansehen →</a></div>
 ${sectionLine('App & Aktualisierungen')}
<div class="pwa-actions"><div class="pwa-card"><div class="pwa-card-title"><span class="pwa-emoji" aria-hidden="true">${iconFor('einstieg')}</span><div><h2>FW Kompass als App</h2><p>Auf dem Smartphone installieren und direkt vom Startbildschirm öffnen.</p></div></div><button class="btn primary full" type="button" id="install-app-btn">App installieren</button><p id="install-app-state" class="tiny" aria-live="polite">Installation über Chrome oder den Browser möglich.</p><div id="install-app-help" class="install-help" hidden><strong>So klappt die Installation:</strong><p><b>Android:</b> Öffne diese Seite direkt in Google Chrome (nicht im ChatGPT-internen Browser), tippe oben rechts auf ⋮ und wähle „App installieren“ oder „Zum Startbildschirm hinzufügen“.</p><p><b>iPhone:</b> In Safari auf Teilen und danach „Zum Home-Bildschirm“ tippen.</p><p>Wenn die Schaltfläche fehlt, prüfe die HTTPS-Adresse und versuche es direkt in Chrome. Je nach Gerät ist nur eine Startbildschirm-Verknüpfung möglich.</p></div></div>
 <div class="pwa-card"><div class="pwa-card-title"><span class="pwa-emoji" aria-hidden="true">${iconFor('updates')}</span><div><h2>Update-Service</h2><p>Prüft, ob auf dem Server eine neue Version bereitsteht.</p></div></div><div class="update-version">Installierte Webversion: <strong>v${APP_VERSION}</strong></div><p id="update-check-state" class="tiny" role="status">Update-Prüfung wird vorbereitet …</p><button class="btn full" type="button" id="check-app-updates">Jetzt nach Updates suchen</button><button class="btn full dark" type="button" id="apply-app-update" hidden>Neue Version installieren</button><p class="tiny">Browser-Updates werden automatisch erkannt. Neue Server-Versionen können im geschützten Verwaltungsbereich installiert werden.</p></div></div>
 <p class="admin-hint"><a href="./admin/updater.php" target="_blank" rel="noopener noreferrer">⚙ Verwaltung und Server-Updates (nur Betreiber) ↗</a></p>`;
}

// MdL Aktuell: drei durch den Betreiber bestätigte Instagram-Profile.
// Keine automatische Instagram-Synchronisierung oder Meta-Embeds.
const MDL_PROFILES=[
 {id:'zierer',name:'Benno Zierer',handle:'benno.zierer',instagram:'https://www.instagram.com/benno.zierer/',website:'https://www.benno-zierer.de/',landtag:'https://fw-landtag.de/fraktion/mdl/benno-zierer'},
 {id:'lausch',name:'Josef „Sepp“ Lausch',handle:'lauschjosef',instagram:'https://www.instagram.com/lauschjosef/',website:'https://www.josef-lausch.de/',landtag:'https://fw-landtag.de/fraktion/mdl/josef-lausch'},
 {id:'saller',name:'Markus Saller',handle:'markus.saller',instagram:'https://www.instagram.com/markus.saller/',website:'https://www.markus-saller.de/',landtag:'https://fw-landtag.de/fraktion/mdl/markus-saller'}
];
let mdlPosts=[],mdlStatus='',mdlAdminMessage='',mdlFilter='all';
async function mdlApi(action='',body=null){
 const q=new URLSearchParams({mode:'mdl'});if(action)q.set('action',action);
 const r=await fetch('./api/version.php?'+q.toString(),{method:body?'POST':'GET',body:body?new URLSearchParams(body):undefined,credentials:'same-origin',cache:'no-store'});
 const data=await r.json();if(!r.ok)throw new Error(data.error||('HTTP '+r.status));return data;
}
// Bilder werden erst nach ausdrücklicher Freigabe direkt von der offiziellen Bildquelle geladen.
// A single opt-in controls loading portraits from external official sources.
// No images or connections to outside image servers before a deliberate click.
const MDL_PHOTO_KEY='fw-kompass-mdl-portraits-consent';
const WHO_PHOTO_KEY='fw-kompass-portraits-consent';
let mdlPhotoConsent=false;
try{mdlPhotoConsent=localStorage.getItem(WHO_PHOTO_KEY)==='yes'||localStorage.getItem(MDL_PHOTO_KEY)==='yes';}catch{}
function setPortraitConsent(value){
 mdlPhotoConsent=!!value;
 try{for(const key of [MDL_PHOTO_KEY,WHO_PHOTO_KEY]){
  if(mdlPhotoConsent)localStorage.setItem(key,'yes');else localStorage.removeItem(key);
 }}catch{}
}
function mdlPortrait(p){
 const name=p.id==='lausch'?'Josef Lausch':p.name;
 const original=(WHO.landtag||[]).find(x=>x.name===name);
 const initials=p.id==='zierer'?'BZ':p.id==='lausch'?'JL':'MS';
 const image=original?.image;
 return `<div class="mdl-profile-image" aria-label="Porträtplatz für ${esc(p.name)}"><span class="mdl-initials" aria-hidden="true">${initials}</span>${mdlPhotoConsent&&image?`<img loading="lazy" decoding="async" referrerpolicy="no-referrer" src="${esc(safeUrl(image))}" alt="Porträt von ${esc(p.name)}">`:''}</div>`;
}
function mdlCardPost(p,editor=false){
 const person=MDL_PROFILES.find(x=>x.id===p.person);
 if(!person)return '';
 const source=String(p.url||'').includes('instagram.com/')?'Instagram':'Website';
 return `<article class="mdl-post" ${editor?'':`data-stat-kind="mdl" data-stat-id="${esc(p.id||'')}" data-stat-title="${esc(p.title)}"`}><div class="mdl-post-meta"><span>${esc(person.name)}</span><span>${esc(source)}</span><time datetime="${esc(p.date)}">${date(p.date)}</time></div>
 <h3>${esc(p.title)}</h3>${p.summary?`<p>${esc(p.summary)}</p>`:''}<div class="mdl-actions">${external(p.url,source==='Instagram'?'Originalbeitrag auf Instagram':'Originalmeldung öffnen','btn small primary')}
 ${editor?`<button class="btn small quiet" type="button" data-mdl-remove="${esc(p.id)}">Löschen</button>`:''}</div></article>`;
}
function mdlAktuell(){
 const posts=[...mdlPosts].filter(p=>mdlFilter==='all'||p.person===mdlFilter).sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
 const profiles=MDL_PROFILES.map(p=>`<article class="mdl-profile">${mdlPortrait(p)}<div class="mdl-profile-detail"><h3>${esc(p.name)}</h3><p>@${esc(p.handle)} · Bayerischer Landtag</p><div class="mdl-actions">${external(p.instagram,'Instagram','mdl-profile-link')}${external(p.website,'Website','mdl-profile-link')}${external(p.landtag,'Landtag','mdl-profile-link')}</div></div></article>`).join('');
 return `${head('SOZIALE MEDIEN & ABGEORDNETE','MdL Aktuell','Veröffentlichungen von Benno Zierer, Josef Lausch und Markus Saller – mit Links zu den Originalquellen.')}
 <div class="mdl-disclaimer"><strong>Hinweis:</strong> Instagram-Beiträge werden derzeit nicht automatisch übernommen. Hier erscheinen ausschließlich redaktionell eingetragene Beitragslinks; aktuelle Posts findest du direkt auf Instagram.</div>
 ${sectionLine('Direkt zu den Abgeordneten','3 Profile')}
 <div class="mdl-picture-consent"><p>${mdlPhotoConsent?'Porträts von der offiziellen FW-Landtagsfraktion.':'Porträts können von der offiziellen FW-Landtagsfraktion geladen werden. Beim Laden wird eine Verbindung zu deren Server aufgebaut.'}</p><button class="btn small quiet" type="button" id="mdl-photo-toggle">${mdlPhotoConsent?'Externe Fotos nicht mehr laden':'Offizielle Porträts anzeigen'}</button></div>
 <div class="mdl-profile-grid">${profiles}</div>
 ${sectionLine('Veröffentlichte Beiträge',posts.length+' Einträge')}
 <div class="mdl-filter" role="group" aria-label="Nach Abgeordneten filtern"><button type="button" class="chip ${mdlFilter==='all'?'active':''}" data-mdl-person="all">Alle</button>${MDL_PROFILES.map(p=>`<button type="button" class="chip ${mdlFilter===p.id?'active':''}" data-mdl-person="${p.id}">${esc(p.name)}</button>`).join('')}</div>
 <div class="mdl-post-grid">${posts.length?posts.map(p=>mdlCardPost(p)).join(''):`<div class="panel"><h3>Noch keine Einzelbeiträge veröffentlicht</h3><p>Über die drei Profil-Links findest du die aktuellen Instagram-Posts. Redaktionell eingetragene Einzelbeiträge erscheinen hier automatisch.</p></div>`}</div>
 <div class="mdl-bottom"><button id="mdl-reload" class="btn quiet" type="button">Beiträge aktualisieren</button><span id="mdl-reload-status" class="tiny" role="status">${esc(mdlStatus)}</span></div>
 <p class="mdl-manage-note">Du betreust den Inhalt? <a href="#redaktion">Geschützte Redaktion öffnen →</a></p>`;
}
function mdlEditorPage(){
 const top=head('ADMINISTRATION · GESCHÜTZT','Redaktion – MdL Aktuell','Verwalte veröffentlichte Beitragslinks, ohne ein App-Update zu erstellen.');
 if(!statSession.authenticated)return `${top}<section class="panel mdl-editor-login"><h2>Redaktionszugang</h2><p>Bitte mit deinem bisherigen Administratorpasswort anmelden. Ohne Anmeldung können hier keine Beiträge veröffentlicht oder entfernt werden.</p>
 <form class="stat-form" id="mdl-admin-login"><label>Administratorpasswort<input type="password" name="password" required minlength="12" autocomplete="current-password"></label><button class="btn primary" type="submit">Anmelden</button></form><p class="tiny" id="mdl-login-status" role="status"></p></section><p><a href="#mdl" class="text-link">← Zurück zu MdL Aktuell</a></p>`;
 const posts=[...mdlPosts].sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
 return `${top}<div class="mdl-editor-nav"><span class="tag">Angemeldet · ${posts.length} Beiträge</span><button class="btn small quiet" id="mdl-admin-logout" type="button">Abmelden</button><a class="btn small" href="#mdl">Öffentlichen Bereich ansehen</a></div>
 <section class="panel mdl-editor"><h2>Neue Veröffentlichung aufnehmen</h2><p>Nur Links zu Originalposts, Reels oder offiziellen Websites eintragen. Keine fremden Fotos oder Videos kopieren.</p>
 <form id="mdl-add-form" class="stat-form"><label>Abgeordneter<select name="person" required>${MDL_PROFILES.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></label>
 <label>Überschrift<input name="title" required maxlength="130" placeholder="Worum geht es in dem Beitrag?"></label>
 <label>Original-Link (Instagram-Post, Reel oder offizielle Website)<input name="url" type="url" required maxlength="800" placeholder="https://www.instagram.com/p/..."></label>
 <label>Veröffentlichungsdatum<input name="date" type="date" required value="${new Date().toISOString().slice(0,10)}"></label>
 <label>Kurzbeschreibung (optional)<textarea name="summary" rows="3" maxlength="400" placeholder="Ein kurzer, neutraler Hinweis."></textarea></label>
 <button class="btn primary" type="submit">Beitrag veröffentlichen</button></form><p id="mdl-admin-status" class="tiny" role="status">${esc(mdlAdminMessage)}</p></section>
 ${sectionLine('Beiträge verwalten',posts.length+' Einträge')}
 <div class="mdl-post-grid">${posts.length?posts.map(p=>mdlCardPost(p,true)).join(''):'<div class="panel">Bisher wurden keine Einzelbeiträge aufgenommen.</div>'}</div>`;
}
async function loadMdlPosts(){
 try{const d=await mdlApi();mdlPosts=Array.isArray(d.posts)?d.posts:[];mdlStatus='Stand: '+new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});}
 catch(e){mdlStatus='Beiträge können derzeit nicht geladen werden; die Profil-Links funktionieren weiter.';}
 if(state.route==='mdl'||state.route==='redaktion')draw();
}
function wireMdl(){
 document.querySelectorAll('[data-mdl-person]').forEach(btn=>btn.addEventListener('click',()=>{mdlFilter=btn.dataset.mdlPerson;draw();}));
 $('#mdl-reload')?.addEventListener('click',loadMdlPosts);
 $('#mdl-photo-toggle')?.addEventListener('click',()=>{setPortraitConsent(!mdlPhotoConsent);draw();});
 document.querySelectorAll('.mdl-profile-image img').forEach(img=>{const wrap=img.closest('.mdl-profile-image');img.addEventListener('load',()=>wrap.classList.add('photo-loaded'));img.addEventListener('error',()=>{wrap.classList.add('photo-error');img.remove();});if(img.complete&&img.naturalWidth>0)wrap.classList.add('photo-loaded');});
}
function wireMdlEditor(){
 $('#mdl-admin-login')?.addEventListener('submit',async e=>{
  e.preventDefault();const f=e.currentTarget;const el=$('#mdl-login-status');if(el)el.textContent='Anmeldung läuft …';
  try{if(!statSession.csrf)statSession=await apiStats('status');await apiStats('login',{csrf:statSession.csrf,password:f.elements.password.value});await loadStatSession();}catch(err){if(el)el.textContent='Anmeldung fehlgeschlagen: '+err.message;}
 });
 $('#mdl-admin-logout')?.addEventListener('click',async()=>{try{await apiStats('logout',{csrf:statSession.csrf});statSession.authenticated=false;statSession.csrf='';statReport=null;draw();}catch(err){mdlAdminMessage='Abmeldung nicht möglich: '+err.message;draw();}});
 $('#mdl-add-form')?.addEventListener('submit',async e=>{
  e.preventDefault();const f=e.currentTarget;const values={csrf:statSession.csrf};for(const field of ['person','title','url','date','summary'])values[field]=f.elements[field].value;
  mdlAdminMessage='Beitrag wird geprüft …';const message=$('#mdl-admin-status');if(message)message.textContent=mdlAdminMessage;
  try{await mdlApi('add',values);mdlAdminMessage='Beitrag veröffentlicht.';await loadMdlPosts();}
  catch(err){mdlAdminMessage='Fehler: '+err.message;const target=$('#mdl-admin-status');if(target)target.textContent=mdlAdminMessage;}
 });
 document.querySelectorAll('[data-mdl-remove]').forEach(btn=>btn.addEventListener('click',async()=>{
  if(!confirm('Den verlinkten Beitrag wirklich entfernen?'))return;
  try{await mdlApi('remove',{csrf:statSession.csrf,id:btn.dataset.mdlRemove});mdlAdminMessage='Beitrag entfernt.';await loadMdlPosts();}
  catch(err){mdlAdminMessage='Fehler: '+err.message;const target=$('#mdl-admin-status');if(target)target.textContent=mdlAdminMessage;}
 }));
}

function localGroups(){
 const groups=ORTE.groups;
 return `${head('DEIN LANDKREIS · DEINE ANSPRECHPARTNER','FREIE WÄHLER vor Ort','Wähle eine Gemeinde und finde die veröffentlichte Website der örtlichen Gruppierung oder die zuständige Kreisorganisation.')}
 <div class="local-disclaimer"><strong>Wichtig:</strong> Ortsgruppe, kommunale Wählergemeinschaft und Parteigliederung sind nicht immer dasselbe. Ein Eintrag bedeutet nicht automatisch eine Mitgliedschaft in der Bundespartei. Die hier aufgeführten örtlichen Gruppen stammen aus den öffentlichen Verzeichnissen von Kreis und Land. Angaben werden nicht automatisch synchronisiert.</div>
 ${sectionLine('Kreisorganisationen')}
 <div class="local-county-grid">${ORTE.county.map(c=>`<article class="local-county"><h3>${esc(c.name)}</h3><p>${esc(c.description)}</p>${external(c.url,'Offizielle Kontaktseite','btn small')}</article>`).join('')}</div>
 ${sectionLine('Ortsgruppen und Wählergemeinschaften',groups.length+' Einträge')}
 <div class="local-controls"><div><label for="local-search">Gemeinde suchen</label><input id="local-search" class="people-search" type="search" placeholder="z. B. Dorfen, Isen, Sankt Wolfgang …" value="${esc(state.localQuery)}" /></div><div><label for="local-filter">Herkunft der Einträge</label><select id="local-filter"><option value="all" ${state.localFilter==='all'?'selected':''}>Alle veröffentlichten Einträge</option><option value="kreis" ${state.localFilter==='kreis'?'selected':''}>Kreiswebsite</option><option value="land" ${state.localFilter==='land'?'selected':''}>Landesverzeichnis ergänzend</option></select></div></div>
 <div class="people-bar"><span id="local-count"></span><span>Geprüft: ${date(ORTE.updated)}</span></div><div class="local-grid" id="local-list"></div>
 <div class="local-disclaimer"><strong>Ort nicht gefunden?</strong> Das bedeutet nicht zwangsläufig, dass es keine örtliche Wählergruppe gibt. Die Listen bilden nur die derzeit in den offiziellen Quellen nachgewiesenen Einträge ab. ${external(ORTE.sources.kreis,'Kontakt Kreisvereinigung')} · ${external(ORTE.sources.land,'Ortsverzeichnis Bayern')}</div>`;
}
function localCard(p){
 const named=p.name;
 const source=p.source==='kreis'?'Verlinkt auf Kreiswebsite':'Zusätzlich im Landesverzeichnis';
 return `<article class="local-card"><div class="local-card-head"><span class="local-pin" aria-hidden="true">${iconFor('vorort')}</span><span class="local-source">${esc(source)}</span></div><h3>${esc(named)}</h3><p>Örtliche Gruppierung im Landkreis Erding</p><div class="local-actions">${p.url?external(p.url,'Zur Website','btn small primary'):external(ORTE.sources.land,'Eintrag im Landesverzeichnis','btn small')}<a class="btn small quiet" href="#kontakte">Kreiskontakt</a></div></article>`;
}
function refreshLocal(){
 const target=$('#local-list');if(!target)return;
 const q=state.localQuery.trim().toLocaleLowerCase('de-DE');
 const result=ORTE.groups.filter(p=>(state.localFilter==='all'||p.source===state.localFilter)&&p.name.toLocaleLowerCase('de-DE').includes(q));
 target.innerHTML=result.length?result.map(localCard).join(''):'<div class="empty">Kein Eintrag gefunden. Bitte über die Kreisorganisation nachfragen.</div>';
 $('#local-count').textContent=`${result.length} von ${ORTE.groups.length} örtlichen Einträgen`;
}
function whoIsWho(){
 const tabs=[['landtag','MdL in Bayern'],['bund','Bundesvorstand'],['land','Landesvorstand Bayern']];
 return `${head('Menschen & Verantwortung','Who is Who','Wer gestaltet Politik und Organisation? Personen, Funktionen und direkte Links zu den offiziellen Profilen.')}
 <div class="who-intro-alert"><strong>Stand: ${date(WHO.updated)} · Führungswechsel</strong><p>Nach dem Tod von Hubert Aiwanger am 4. November 2026 ist der Bundes- und Landesvorsitz neu zu besetzen. Laut BR24 führt Manfred Petry die Bundespartei vorläufig. Die Fraktionsliste der Website wurde noch nicht entsprechend bereinigt. Dieser Wegweiser führt Hubert Aiwanger deshalb nicht als amtierende Person.</p><p>Quelle: ${external('https://www.br.de/nachrichten/bayern/freie-waehler-wie-geht-es-nach-aiwangers-tod-weiter%2CVa5uNYW','BR24, 05.11.2026','text-link')}</p></div>
 <div class="people-tabbar" role="group" aria-label="Personengruppen">${tabs.map(([key,label])=>`<button type="button" class="chip ${state.peopleGroup===key?'active':''}" data-people-tab="${key}" aria-pressed="${state.peopleGroup===key}">${label} <span class="count-inline">${WHO[key].length}</span></button>`).join('')}</div>
 <label class="people-search-label" for="people-search">Namen und Funktionen durchsuchen</label><input class="people-search" type="search" id="people-search" placeholder="z. B. Gesundheit, Mehring, Vorstand …" value="${esc(state.peopleQuery)}" />
 <div class="people-bar"><span id="people-count"></span><span>Porträts aus offiziellen Profilquellen</span></div>
 <div class="people-photo-toolbar" role="group" aria-label="Porträtbilder anzeigen">
  <div><strong>${state.peopleGroup==='landtag'?'Fotos der FW-Landtagsabgeordneten': 'Offizielle Porträtbilder'}</strong>
  <p>${mdlPhotoConsent?'Die Bilder werden von offiziellen Bildquellen geladen.':'Aus Datenschutzgründen laden Fotos erst nach deiner Zustimmung. Ein Klick reicht für alle Personen.'}</p></div>
  <button type="button" class="btn small ${mdlPhotoConsent?'quiet':'primary'}" id="who-photo-toggle" aria-pressed="${mdlPhotoConsent?'true':'false'}">${mdlPhotoConsent?'Fotos ausblenden':'Alle Porträts anzeigen'}</button>
 </div>
 <div class="people-grid" id="people-grid"></div>
 <div class="who-disclaimer"><strong>Hinweis zu Fotos:</strong> Die Porträts werden direkt von ihren externen Ursprungsseiten angezeigt. Manche fehlen derzeit und sind durch einen neutralen Platzhalter ersetzt. Für eine offizielle Veröffentlichung sollten die Nutzungsrechte der jeweiligen Fotos geklärt werden. Die Angaben werden nicht automatisch synchronisiert; neue Vorstandsentscheidungen sind zeitnah zu prüfen. ${external(WHO.sources[state.peopleGroup],'Offizielles Verzeichnis','text-link')}</div>`;
}
function personPhoto(p){
 const initials=p.name.replace(/\b(?:Dr|Prof)\.?\s*/gi,'').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase();
 const fallback=`<span class="portrait-fallback"><span>${esc(initials)}</span><small>${p.image?(mdlPhotoConsent?'Foto wird geladen':'Foto anzeigen'): 'Foto folgt'}</small></span>`;
 if(!p.image)return fallback;
 return `<span class="portrait-wrap portrait-pending">${fallback}${mdlPhotoConsent?`<img loading="lazy" decoding="async" referrerpolicy="no-referrer" src="${esc(safeUrl(p.image))}" alt="Porträt von ${esc(p.name)}">`:''}</span>`;
}
function whoCard(p){return `<article class="person-card"><div class="person-photo">${personPhoto(p)}</div><div class="person-info"><h3>${esc(p.name)}</h3><p class="person-role">${esc(p.role)}</p><div class="person-bottom">${external(p.url,'Offizielles Profil','text-link')}${p.imageSource?`<span class="person-photo-credit">Foto: ${esc(p.imageSource)}</span>`:''}</div></div></article>`;}
function refreshPeople(){
 const results=WHO[state.peopleGroup].filter(p=>`${p.name} ${p.role}`.toLocaleLowerCase('de-DE').includes(state.peopleQuery.trim().toLocaleLowerCase('de-DE')));
 const list=$('#people-grid');if(list)list.innerHTML=results.length?results.map(whoCard).join(''):'<div class="empty">Keine Person gefunden.</div>';
 document.querySelectorAll('.portrait-wrap img').forEach(img=>{
  const wrap=img.closest('.portrait-wrap');
  img.addEventListener('load',()=>wrap.classList.add('portrait-loaded'));
  img.addEventListener('error',()=>{img.remove();wrap.classList.add('portrait-failed');const label=wrap.querySelector('.portrait-fallback small');if(label)label.textContent='Foto nicht verfügbar';});
  if(img.complete&&img.naturalWidth>0)wrap.classList.add('portrait-loaded');
 });
 const c=$('#people-count');if(c)c.textContent=`${results.length} von ${WHO[state.peopleGroup].length} Personen`;
}

function federalBodies(){
 const tabs=[['bag','Bundesarbeitsgemeinschaften (BAG)'],['bfa','Bundesfachausschüsse (BFA)']];
 const arr=GREMIEN[state.gremienGroup];
 return `${head('Mitmachen auf Bundesebene','Bundesgremien – BFA & BAG','Entdecke die thematische Arbeit der FREIEN WÄHLER, finde Vorsitzende und offizielle Kontaktwege.')}
 <div class="gremien-explainer"><article class="gremien-explain-card"><span class="gremien-kicker">BAG</span><h2>Bundesarbeitsgemeinschaften</h2><p>Themenbezogene Netzwerke für Austausch, Vernetzung und Mitwirkung von Mitgliedern. Die jeweiligen BAGs informieren über die Möglichkeiten zur Teilnahme.</p></article>
 <article class="gremien-explain-card"><span class="gremien-kicker">BFA</span><h2>Bundesfachausschüsse</h2><p>Fachgremien zur inhaltlichen Unterstützung des Bundesvorstands. Themen, Berufungen und Vorsitz richten sich nach Satzung und Beschlüssen des Bundesvorstands.</p></article></div>
 <div class="gremien-tabbar" role="group" aria-label="Gremientyp auswählen">${tabs.map(([k,l])=>`<button type="button" class="chip ${state.gremienGroup===k?'active':''}" data-gremien-tab="${k}" aria-pressed="${state.gremienGroup===k}">${l} <span class="count-inline">${GREMIEN[k].length}</span></button>`).join('')}</div>
 <label class="people-search-label" for="gremien-search">Gremium, Thema oder Vorsitz durchsuchen</label><input class="people-search" id="gremien-search" type="search" placeholder="z. B. Pflege, Wirtschaft, Frauen …" value="${esc(state.gremienQuery)}"/>
 <div class="people-bar"><span id="gremien-count"></span><span>Stand: ${date(GREMIEN.updated)}</span></div>
 <div class="gremien-grid" id="gremien-list"></div>
 <section class="gremien-join"><div><span class="gremien-kicker">MITMACHEN</span><h2>Du möchtest Dich engagieren?</h2><p>Wende Dich bei einer BAG direkt an die veröffentlichte Kontaktadresse. Für die Mitarbeit in einem BFA klärst Du die Voraussetzungen über die Bundesgeschäftsstelle.</p></div><div class="gremien-join-links">${external('https://www.freiewaehler.eu/mitmachen/bag/','Offizielle BAG-Übersicht','btn primary')}${external('https://www.freiewaehler.eu/services/kontakt/','Bundesgeschäftsstelle','btn')}</div></section>
 <p class="who-disclaimer"><strong>Hinweis zur Vollständigkeit:</strong> Die vier BAGs sind auf der offiziellen Bundeswebsite veröffentlicht. Bei den BFAs liegt keine öffentlich bestätigte vollständige aktuelle Gesamtliste vor. Hier sind nur einzeln nachgewiesene Fachausschüsse aufgenommen; unbestätigte Vorsitzende werden bewusst nicht genannt. Der Stand muss bei der Bundesgeschäftsstelle regelmäßig überprüft werden.</p>`;
}
function gremienCard(g){
 const chair=g.chair?`<p class="gremien-contact"><span>Vorsitz</span><strong>${esc(g.chair)}</strong></p>`:`<p class="gremien-contact"><span>Vorsitz</span><strong>Bitte offiziell erfragen</strong></p>`;
 const mail=g.email?`<a class="btn small primary" href="mailto:${esc(g.email)}">E-Mail senden</a>`:'';
 return `<article class="gremium-card"><span class="gremien-badge">${state.gremienGroup.toUpperCase()}</span><h3>${esc(g.name)}</h3><p class="gremien-desc">${esc(g.description)}</p>${chair}<div class="gremien-card-footer">${mail}${external(g.url,g.linkLabel||'Offizielle Quelle','btn small')}</div></article>`;
}
function refreshGremien(){
 const a=GREMIEN[state.gremienGroup];const q=state.gremienQuery.trim().toLocaleLowerCase('de-DE');
 const filtered=a.filter(g=>`${g.name} ${g.description} ${g.chair||''}`.toLocaleLowerCase('de-DE').includes(q));
 $('#gremien-list').innerHTML=filtered.length?filtered.map(gremienCard).join(''):'<div class="empty">Kein Gremium zu diesem Suchbegriff gefunden.</div>';
 $('#gremien-count').textContent=`${filtered.length} von ${a.length} erfassten Gremien`;
}
function guide(){
 const towns=state.data.regions.towns||[];
 return `${head('Dein Ansprechpartner-Finder','Wohin mit Deiner Frage?','Wähle Dein Anliegen und die zuständige Ebene. Der Kompass zeigt Dir den nächsten sinnvollen Schritt und offizielle Kontaktwege.')}
 <section class="panel"><div class="form-grid"><div class="field"><label for="guide-topic">Was möchtest Du tun?</label><select id="guide-topic">${Object.entries(PURPOSES).map(([key,v])=>`<option value="${key}" ${state.guideTopic===key?'selected':''}>${esc(v.title)}</option>`).join('')}</select></div><div class="field"><label for="guide-level">Auf welcher Ebene?</label><select id="guide-level">${Object.entries(LEVELS).filter(([key])=>key!=='all').map(([key,v])=>`<option value="${key}" ${state.guideLevel===key?'selected':''}>${esc(v)}</option>`).join('')}</select></div><div class="field"><label for="guide-town">Mein Ort (optional)</label><select id="guide-town"><option value="">Keine Ortsauswahl</option>${towns.map(t=>`<option value="${esc(t.name)}" ${state.guideTown===t.name?'selected':''}>${esc(t.name)}</option>`).join('')}</select></div></div><p class="tiny">Hinweis: Vorschläge dienen der Orientierung und ersetzen keine bestätigte Zuständigkeitsauskunft der Organisation.</p></section>
 <div id="guide-result">${guideResult()}</div>`;
}
function guideResult(){
 const p=PURPOSES[state.guideTopic]||PURPOSES.mitgliedschaft;
 const level=state.guideLevel;
 const contacts=state.data.contacts.filter(c=>c.level===level&&(c.topics||[]).some(x=>p.topics.includes(x)));
 const fallback=state.data.contacts.filter(c=>c.level===level).slice(0,2);
 const matches=contacts.length?contacts:fallback;
 const town=state.data.regions.towns.find(x=>x.name===state.guideTown);
 let townLine='';
 if(town){townLine=town.website?`<p><strong>Dein Ort:</strong> ${esc(town.name)} – ${external(town.website,'örtliche Website öffnen')}.</p>`:`<p><strong>Dein Ort:</strong> ${esc(town.name)} – ist derzeit keine bestätigte Ortswebsite hinterlegt. Bitte direkt beim Kreisverband nachfragen.</p>`;}
 return `<section class="result"><div class="eyebrow">DEINE ORIENTIERUNG</div><h2>${esc(p.title)}</h2><p>${esc(p.text)}</p>${townLine}<div class="meta-line"><span>Gewählte Ebene: ${esc(LEVELS[level])}</span><span>Zuletzt geprüfte Links: November 2026</span></div></section>
 ${state.guideTopic==='gremien'?'<p class="gremien-guide-link"><a class="btn primary" href="#gremien">Bundesfachausschüsse & Bundesarbeitsgemeinschaften ansehen →</a></p>':''}
 ${state.guideTopic==='ortsverband'||state.guideTopic==='mitgliedschaft'?'<p class="gremien-guide-link"><a class="btn primary" href="#mitglied">Mitglied werden →</a> <a class="btn" href="#vorort">Ortsgruppen finden →</a> <a class="btn" href="#struktur">Partei und Landesverband unterscheiden →</a></p>':''}
 ${sectionLine('Passende Anlaufstellen')}
 <div class="cards">${matches.length?matches.map(contactCard).join(''):'<div class="empty">Für dieses Anliegen ist noch kein einzelner Ansprechpartner bestätigt. Nutze bitte die zentrale Geschäftsstelle der gewählten Ebene.</div>'}</div>
 ${sectionLine('Noch nicht sicher?')}<div class="padded-note">Für eine rein kommunale Wählergemeinschaft ist nicht automatisch die Parteikreisvereinigung zuständig. Kläre zuerst, welcher Organisation Deine Mitgliedschaft oder Dein Vorhaben zugeordnet ist.</div>`;
}
function sortedNews(){return [...publicNewsArticles()].filter(a=>(state.newsLevel==='all'||a.level===state.newsLevel)&&(`${a.title||''} ${a.excerpt||''} ${a.source||''}`.toLocaleLowerCase('de-DE').includes(state.newsQuery.trim().toLocaleLowerCase('de-DE')))).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||(a.title||'').localeCompare(b.title||''));}
function newsStatus(){
 const meta=state.data.news.metadata||{};
 const active=meta.mode==='source-sync';
 const statuses=meta.sources||{};
 const readable={'ok':'Import aktiv','error':'Abruf fehlgeschlagen','no-dated-articles':'Keine eindeutig datierten Meldungen','not-checked':'Noch ungeprüft','disabled':'Ausgeschaltet'};
 const details=Object.entries(statuses).map(([key,v])=>`<span class="sync-source-note">${esc(LEVELS[key]||key)}: ${esc(readable[v.state]||'Noch ungeprüft')}</span>`).join(' · ');
 const last=meta.lastSuccessfulAt?new Date(meta.lastSuccessfulAt).toLocaleString('de-DE'):'noch keiner';
 const selection=state.newsLevel==='all'?null:statuses[state.newsLevel];
 const selectedDate=selection?.lastSuccess?new Date(selection.lastSuccess).toLocaleString('de-DE'):'noch keine erfolgreiche Übernahme';
 const selectedLine=selection?`<p class="tiny"><strong>${esc(LEVELS[state.newsLevel])}:</strong> letzte erfolgreiche Übernahme ${esc(selectedDate)}. ${selection.state==='error'?'Der aktuelle Abruf ist fehlgeschlagen; ältere Meldungen können weiterhin angezeigt werden.':''}</p>`:'';
 const loadLine=state.newsRefreshing?'<p class="tiny" role="status">Aktuelle Meldungen werden geprüft …</p>':'';
 const errorLine=state.newsFetchError?`<p class="tiny" role="alert">${esc(state.newsFetchError)}</p>`:'';
 if(active)return `<div class="alert news-status" role="status"><strong><span class="status-dot" style="background:#338d64"></span>${Number(meta.feedCount||0)} Quellen mit zuletzt erfolgreich erkannten Meldungen</strong><p>Letzter erfolgreicher Import: ${esc(last)}. Bei Ausfall einer Quelle bleiben zuvor gespeicherte Meldungen sichtbar, aber nicht automatisch aktuell.</p><div class="sync-source-line">${details}</div>${selectedLine}${loadLine}${errorLine}<p class="tiny">Nur Überschriften, Datum und Link zum Original – ohne Artikeltexte oder Bilder.</p></div>`;
 return `<div class="alert orange news-status" role="status"><strong><span class="status-dot"></span>Aktuelle Nachrichten direkt bei den Originalquellen</strong><p>Der automatische Abruf ist eingerichtet, aber derzeit sind keine erfolgreich importierten Meldungen bestätigt. Die offiziellen Nachrichtenlinks stehen unten bereit. ${details}</p>${selectedLine}${loadLine}${errorLine}<p class="tiny"><a href="./api/news.php?admin=1" target="_blank" rel="noopener noreferrer">Synchronisation verwalten ↗</a></p></div>`;
}
let newsRequestSerial=0;
async function refreshNewsFromServer(level=state.newsLevel){
 const requestId=++newsRequestSerial;
 state.newsRefreshing=true;
 state.newsFetchError='';
 if(state.route==='news')draw();
 try {
  const response=await fetch('./api/news.php?level='+encodeURIComponent(level)+'&t='+Date.now(),{cache:'no-store'});
  if(!response.ok)throw new Error('Serverantwort '+response.status);
  const result=await response.json();
  if(!result||!Array.isArray(result.articles))throw new Error('Ungültige Nachrichtenliste');
  if(requestId===newsRequestSerial)state.data.news=result;
 } catch(error){
  if(requestId===newsRequestSerial){
   state.newsFetchError='Der automatische Abruf war nicht möglich. Vorhandene Meldungen bleiben sichtbar. Die Originalquelle kannst Du unten öffnen.';
   console.warn('FW Kompass: Nachrichtenprüfung fehlgeschlagen',error);
  }
 } finally {
  if(requestId===newsRequestSerial){state.newsRefreshing=false;if(state.route==='news')draw();}
 }
}
// Dauerhafter redaktioneller Gedenkbeitrag: nicht Teil des automatisch überschriebenen News-Feeds.
function memorialHomeTeaser(){
 return `<a class="memorial-home-link" href="#gedenken" aria-label="In stillem Gedenken an Hubert Aiwanger – Nachruf lesen"><span aria-hidden="true">🕯</span><span><strong>In stillem Gedenken an Hubert Aiwanger</strong><small>Den Nachruf jederzeit nachlesen.</small></span><span aria-hidden="true">→</span></a>`;
}
function memorialNewsTeaser(){
 return `<article class="memorial-news-card" aria-label="Gedenkbeitrag"><img src="./assets/gedenken-hubert-aiwanger.webp?v=1.3.13" alt="Schwarz-weißes Gedenkbild für Hubert Aiwanger" loading="lazy" decoding="async" width="1122" height="1402"><div><span class="memorial-kicker">IN STILLEM GEDENKEN</span><h2>Hubert Aiwanger</h2><p>Wir trauern um unseren Vorsitzenden. Sein Engagement und Wirken für die FREIEN WÄHLER bleiben unvergessen.</p><a class="btn small memorial-cta" href="#gedenken">Nachruf lesen →</a></div></article>`;
}
function memorialPage(){
 return `${head('IN STILLEM GEDENKEN','Hubert Aiwanger','Ein würdevoller Abschied. Sein Andenken bleibt.')}
 <article class="memorial-article">
 <img src="./assets/gedenken-hubert-aiwanger.webp?v=1.3.13" alt="Gedenkkarte: In stillem Gedenken an Hubert Aiwanger. Wir trauern um unseren Vorsitzenden. Sein Engagement und Wirken für die FREIEN WÄHLER bleiben unvergessen." width="1122" height="1402" decoding="async" />
 <div class="memorial-article-text"><h2>In stillem Gedenken</h2><p>Wir trauern um unseren Vorsitzenden Hubert Aiwanger. Mit großer Bestürzung nehmen wir Abschied. Sein Engagement und Wirken für die FREIEN WÄHLER bleiben unvergessen.</p><p>Wir werden ihm ein ehrendes Andenken bewahren.</p><a href="#news" class="btn quiet">← Zurück zu Aktuelles</a></div>
 </article>`;
}

function news(){
 const articles=sortedNews();
 return `${head('Informiert bleiben','Aktuelles aus drei Ebenen','Bundesweite, bayerische und regionale Nachrichten – mit direktem Link zum Original.')}
 ${memorialNewsTeaser()}
 ${newsStatus()}
 <div class="news-tools"><div class="filters" id="news-filters" role="group" aria-label="Nachrichtenebene">${Object.entries(LEVELS).map(([key,v])=>`<button type="button" data-news-level="${key}" class="chip ${state.newsLevel===key?'active':''}" aria-pressed="${state.newsLevel===key}">${esc(v)}</button>`).join('')}</div>
 <label class="news-search-label" for="news-search">Meldungen durchsuchen</label><div class="news-search-row"><div class="news-search-wrap"><span aria-hidden="true">⌕</span><input id="news-search" aria-label="Nachrichten durchsuchen" type="search" placeholder="Suchbegriff eingeben …" value="${esc(state.newsQuery)}" autocomplete="off"></div><button type="button" class="btn news-refresh" id="news-reload" ${state.newsRefreshing?'disabled':''}>↻ ${state.newsRefreshing?'Lädt …':'Aktualisieren'}</button></div></div>
 <div class="news-list-meta" id="news-result-count" role="status">${articles.length} ${articles.length===1?'Meldung':'Meldungen'} · Neueste zuerst</div>
 <div class="cards" id="news-list">${articles.length?articles.map(newsCard).join(''):'<div class="empty">Derzeit keine bestätigten Meldungen in der Übersicht. Bitte die offiziellen Quellenlinks unten öffnen oder den Suchfilter ändern.</div>'}</div>
 ${sectionLine('Aktuelle Veröffentlichungen direkt lesen')}
 <p class="tiny source-help">Diese Links führen zu den offiziellen Websites. Dort findest Du die aktuell veröffentlichten Meldungen. Die automatische Erkennung kann je nach Aufbau der Quelle eingeschränkt sein.</p><p class="tiny"><a href="./api/news.php?admin=1" target="_blank" rel="noopener noreferrer">⚙ Synchronisation verwalten (Admin) ↗</a></p>
 <div class="source-strip news-sources">${SOURCE_LINKS.map(s=>external(s.url,s.label,'btn')).join('')}</div>`;
}
function contacts(){
 const filtered=state.data.contacts.filter(c=>(state.contactLevel==='all'||c.level===state.contactLevel)&&(`${c.name} ${c.role} ${c.organization}`.toLowerCase().includes(state.contactQuery.toLowerCase())));
 return `${head('Menschen & Stellen','Ansprechpartner finden','Hier stehen nur öffentlich belegte Kontakte beziehungsweise offizielle Geschäftsstellen. Bitte Änderungen vor der Veröffentlichung mit den jeweiligen Organisationen abgleichen.')}
 <div class="spread" style="margin-bottom:17px"><div class="filters" id="contact-filters">${Object.entries(LEVELS).map(([key,v])=>`<button type="button" data-contact-level="${key}" class="chip ${state.contactLevel===key?'active':''}" aria-pressed="${state.contactLevel===key}">${esc(v)}</button>`).join('')}</div><div class="searchbox"><input type="search" id="contact-search" placeholder="Name oder Funktion suchen …" aria-label="Kontakte durchsuchen" value="${esc(state.contactQuery)}"></div></div>
 <div class="cards" id="contact-list">${filtered.length?filtered.map(contactCard).join(''):'<div class="empty">Keine Kontakte gefunden.</div>'}</div>`;
}
function events(){
 return `${head('Termine & Begegnungen','Dabei sein und mitmachen','Lokale und überregionale Termine findest Du über die verlinkten offiziellen Veranstaltungskalender. Hier werden keine unbestätigten Termine angezeigt.')}
 <div class="panel"><div class="eyebrow">TERMINKALENDER</div><h2 style="font-size:21px;margin-top:10px">Veranstaltungen aus offiziellen Quellen</h2><p>Auf den unten verlinkten Kalenderseiten kannst Du die jeweils aktuellen Termine prüfen. Veranstaltungsdaten werden derzeit nicht automatisch zusammengeführt.</p><div class="source-strip">${external('https://www.fw-landkreis-erding.de/veranstaltungen','Landkreis Erding','btn')}${external('https://www.fw-bayern.de','Bayern','btn')}${external('https://www.freiewaehler.eu/','Bundesvereinigung','btn')}</div></div>
 <div class="padded-note">Hinweis: Für Terminänderungen, Uhrzeiten, Veranstaltungsorte und Anmeldungen gelten die Angaben des jeweiligen Veranstalters auf der verlinkten Website.</div>`;
}
function becomeMember(){
 const party='https://www.fw-bayern.de/mitglied-werden/';
 const national='https://www.freiewaehler.eu/mitmachen/mitglied-werden/';
 const federation='https://www.fw-bayern.de/landesverband-vereinigung/mitgliedschaft';
 return `${head('MITMACHEN · MITGLIEDSCHAFT','Mitglied werden','Es gibt verschiedene Wege, sich bei den FREIEN WÄHLERN zu engagieren. Wähle die passende Organisationsform.')}
 <div class="member-choice-grid">
  <article class="member-choice member-choice-party"><span class="structure-kind">01 · PERSÖNLICHE PARTEIMITGLIEDSCHAFT</span><h2>FREIE WÄHLER – Partei</h2><p>Du möchtest selbst Mitglied der politischen Partei werden? Nutze die offizielle Beitrittsseite der Landesvereinigung Bayern. Dort erhältst Du die Informationen zum persönlichen Mitgliedsantrag.</p>
  ${external(party,'Zur offiziellen Mitgliedschaftsseite','btn primary')}
  <p class="member-extra">Alternativ: ${external(national,'Bundesvereinigung – Mitglied werden')}</p></article>
  <article class="member-choice"><span class="structure-kind">02 · KOMMUNALE MITARBEIT</span><h2>Örtliche Wählergemeinschaft</h2><p>Du möchtest in Deiner Gemeinde mitarbeiten? Wende Dich an die örtliche Wählergemeinschaft und erkundige Dich dort nach den Mitgliedschaftsbedingungen. Die Gruppen sind eigenständig organisiert.</p>
  <a class="btn primary" href="#vorort">Ortsgruppe im Landkreis Erding finden <span aria-hidden="true">→</span></a></article>
 </div>
 <section class="member-federation"><div><span class="structure-kind">FÜR VEREINE UND ORTS-/KREISVERBÄNDE</span><h2>Mitgliedschaft im FW-Landesverband Bayern</h2><p>Der Landesverband ist ein Dachverband kommunaler Wählergemeinschaften. Hier beantragen die örtlichen Organisationen die Mitgliedschaft – keine Einzelpersonen unmittelbar beim Landesverband.</p></div><div>${external(federation,'Informationen für Mitgliedsverbände','btn')}</div></section>
 <div class="member-clarify"><strong>Partei und Landesverband sind nicht dasselbe.</strong> Ein Beitritt zu einer örtlichen Wählergemeinschaft bedeutet nicht automatisch eine Parteimitgliedschaft – und umgekehrt. <a href="#struktur">Unterschiede und Satzungen ansehen →</a></div>
 <p class="tiny">Der FW Kompass stellt selbst keinen Mitgliedsantrag bereit und erhebt hier keine persönlichen Antragsdaten. Maßgeblich sind die Angaben der jeweils zuständigen Organisation.</p>`;
}

/** Die rechtliche Abgrenzung stammt aus den verlinkten Satzungen, nicht aus der bloßen Namensgleichheit. */
function partyOrFederation(){
 const partySatz='https://www.fw-bayern.de/fileadmin/fw_bayern/Dokumente/Satzungen/Satzung_Landesvereinigung_aktuell.pdf';
 const verbandSatz='https://www.fw-bayern.de/fileadmin/user_upload/SatzLV_2012_-_Stand_20240601.pdf';
 const mitglied='https://www.fw-bayern.de/landesverband-vereinigung/mitgliedschaft';
 const historisch='https://www.fw-bayern.de/unser-landesverband/historie-und-struktur';
 return `${head('ORGANISATION VERSTEHEN','Landesvereinigung oder Landesverband?','Zwei eigenständige Organisationen unter dem Namen FREIE WÄHLER – mit unterschiedlichen Mitgliedern, Aufgaben und Satzungen.')}
 <section class="structure-lead" aria-label="Das Wichtigste"><span class="structure-mark" aria-hidden="true">!</span><div><strong>Das Wichtigste zuerst</strong><p>Eine Mitgliedschaft in einer kommunalen Wählergemeinschaft bedeutet <b>nicht automatisch</b>, dass Du Mitglied der Partei FREIE WÄHLER bist. Umgekehrt musst Du für eine Parteimitgliedschaft keiner kommunalen Wählergemeinschaft angehören. Beides ist nebeneinander möglich.</p></div></section>
 <div class="structure-grid" aria-label="Vergleich beider Organisationen">
   <article class="structure-org"><div class="structure-org-heading"><span class="structure-number">01</span><div><span class="structure-kind">POLITISCHE PARTEI</span><h2>Landesvereinigung FREIE WÄHLER Bayern</h2></div></div>
    <dl class="structure-facts"><div><dt>Rechtlich</dt><dd>Bayerischer Gebietsverband der Bundesvereinigung FREIE WÄHLER nach § 4 Abs. 2 Parteiengesetz.</dd></div><div><dt>Wer gehört dazu?</dt><dd>Einzelne Menschen. Die Mitgliedschaft in Bayern folgt der Mitgliedschaft in der Bundesvereinigung.</dd></div><div><dt>Was macht sie?</dt><dd>Politische Arbeit und Wahlteilnahme auf kommunaler, Bezirks-, Landes-, Bundes- und Europaebene gemäß Parteisatzung.</dd></div><div><dt>Struktur laut Satzung</dt><dd>Landesvereinigung, Bezirksvereinigungen, Kreisvereinigungen und mögliche Ortsvereinigungen.</dd></div><div><dt>Beispiel im Landkreis</dt><dd>Eine <b>Kreisvereinigung Erding</b> der Partei ist keine automatische Untergliederung einer kommunalen Wählergemeinschaft.</dd></div></dl>
    <p class="structure-clause">Grundlage: Satzung der Landesvereinigung, insbesondere Abschnitte 1, 2 und 3 (Fassung vom 15.10.2022).</p>
    ${external(partySatz,'Originalsatzung Landesvereinigung (PDF)','btn primary')}
   </article>
   <article class="structure-org"><div class="structure-org-heading"><span class="structure-number">02</span><div><span class="structure-kind">DACHVERBAND KOMMUNALER GRUPPEN</span><h2>FW-Landesverband Bayern der Wählergemeinschaften</h2></div></div>
    <dl class="structure-facts"><div><dt>Rechtlich</dt><dd>Eigenständiger eingetragener Verein als überregionaler Zusammenschluss unabhängiger Wählergemeinschaften.</dd></div><div><dt>Wer gehört dazu?</dt><dd>Orts-, Stadt- und Kreisverbände bzw. Wählergemeinschaften als Organisationen – <b>keine Einzelpersonen</b> unmittelbar im Landesverband.</dd></div><div><dt>Was macht er?</dt><dd>Kommunalpolitische Informationen, organisatorische Hilfe sowie Interessenvertretung seiner Mitgliedsverbände, ohne deren Sachpolitik verbindlich vorzugeben.</dd></div><div><dt>Struktur</dt><dd>Selbstständige Mitgliedsgruppen und übergeordneter Landesverband. Die örtlichen Gruppen besitzen ihre eigene Organisation und Satzung.</dd></div><div><dt>Beispiel im Landkreis</dt><dd>Eine örtliche Wählergemeinschaft kann Mitglied dieses Dachverbands sein, ohne deshalb Parteigliederung zu werden.</dd></div></dl>
    <p class="structure-clause">Grundlage: Satzung des Landesverbands, insbesondere §§ 1–3 (verlinktes Dokument: Fassung vom 07.04.2012).</p>
    ${external(verbandSatz,'Originalsatzung Landesverband (PDF)','btn primary')}
   </article>
 </div>
 ${sectionLine('Beispiel: Landkreis Erding')}
 <div class="structure-local"><div><span class="structure-kind">PARTEI</span><h3>Kreisvereinigung der FREIEN WÄHLER</h3><p>Die örtliche Gebietsorganisation der Partei. Ihre Mitgliedschaft und inneren Zuständigkeiten richten sich nach der Parteisatzung.</p></div><div><span class="structure-kind">KOMMUNALE WÄHLERSCHAFT</span><h3>Freie Wählerschaft des Landkreises Erding</h3><p>Eine eigenständige kommunalpolitische Organisation. Trotz gemeinsamer Bezeichnung und möglicher personeller Überschneidungen nicht automatisch mit der Kreisvereinigung der Partei identisch.</p></div></div>
 <p class="structure-local-source">Die Kreiswebsite unterscheidet ihre Meldungen zur Kreisvereinigung (Partei) und zur Freien Wählerschaft ausdrücklich: ${external('https://www.fw-landkreis-erding.de/aktuelles','Kreisportal Erding ansehen')}.</p>
 ${sectionLine('Was bedeutet das für mich?')}
 <div class="structure-questions">
   <details class="accordion"><summary>Ich will in meiner Gemeinde mitarbeiten. Wohin wende ich mich?</summary><div>Beginne bei der örtlichen Wählergemeinschaft oder einer vorhandenen Parteiorganisation. Prüfe, welcher rechtlichen Organisation die Gruppe angehört. Namen wie „FREIE WÄHLER“ allein reichen dafür nicht aus. <a href="#vorort">Örtliche Gruppen im Landkreis Erding ansehen →</a></div></details>
   <details class="accordion"><summary>Ich möchte persönlich Mitglied der Partei werden.</summary><div>Die Parteimitgliedschaft läuft über die Bundesvereinigung und die zuständige Landesvereinigung. Ein kommunaler Vereinsbeitritt ersetzt sie nicht. ${external(mitglied,'Offizielle Informationen zur Mitgliedschaft')}</div></details>
   <details class="accordion"><summary>Unsere Wählergemeinschaft möchte dem Landesverband beitreten.</summary><div>Hier beantragt die <strong>Organisation</strong> ihre Mitgliedschaft im Landesverband, nicht jedes Mitglied einzeln. Die Aufnahme richtet sich nach § 3 der Landesverbandssatzung. Dort sind auch Anforderungen an die Mitgliedsgruppen geregelt, unter anderem zum Ausschluss anderer Parteimitgliedschaften außer bei den FREIEN WÄHLERN. ${external(mitglied,'Beitrittsinformationen für Orts- und Kreisverbände')}</div></details>
   <details class="accordion"><summary>Gibt es auch Ortsvereinigungen der Partei?</summary><div><strong>Ja, die Parteisatzung sieht sie ausdrücklich vor</strong> (§ 3.1 und 3.5). Eine Gründung erfordert nach § 3.6 die Zustimmung des Landesvorstands. Das ist nicht automatisch derselbe Verein wie eine örtliche kommunale Wählergemeinschaft.</div></details>
   <details class="accordion"><summary>Darf man in beiden Organisationen aktiv sein?</summary><div>Ja, eine persönliche Parteimitgliedschaft und die Mitgliedschaft in einer kommunalen Wählergemeinschaft können nebeneinander bestehen. Die Rechte und Pflichten ergeben sich aus den jeweils geltenden Satzungen. Die Aufnahmebedingungen der konkreten örtlichen Gruppe sind gesondert zu prüfen.</div></details>
   <details class="accordion"><summary>Wer entscheidet bei einer Kommunalwahl?</summary><div>Entscheidend ist, <strong>welcher Wahlvorschlagsträger</strong> tatsächlich antritt: eine eigenständige Wählergemeinschaft oder eine Parteigliederung. Nicht allein die Bezeichnung „FREIE WÄHLER“. Wahlvorschläge und Aufstellungen richten sich nach dem einschlägigen Wahlrecht und der jeweiligen Satzung.</div></details>
 </div>
 ${sectionLine('Satzungen und offizielle Erläuterungen')}
 <div class="structure-sources">
  ${external(partySatz,'Satzung: Landesvereinigung (Partei) – PDF','btn')}
  ${external(verbandSatz,'Satzung: Landesverband – PDF','btn')}
  ${external(historisch,'Offizieller Überblick: Geschichte & Struktur','btn')}
  ${external(mitglied,'Mitgliedschaft: Partei oder Verband','btn')}
 </div>
 <div class="structure-footnote"><strong>Hinweis:</strong> Dies ist eine verständliche Orientierung anhand der verlinkten Satzungen. Maßgeblich sind die jeweils gültigen Originalfassungen und die konkrete Organisationszugehörigkeit vor Ort. Die bayerische Website stellt beide Organisationen nebeneinander dar; personelle Überschneidungen in Gremien ändern nichts an ihrer rechtlichen Eigenständigkeit.</div>`;
}

function knowledge(){
 const r=state.data.resources.filter(x=>`${x.title} ${x.description} ${x.category}`.toLowerCase().includes(state.resourceQuery.toLowerCase()));
 return `${head('Die Organisation verstehen','Wissen & wichtige Links','Die wichtigsten Fragen zum Start, dazu geprüfte Einstiegspunkte zu offiziellen Dokumenten und Arbeitsbereichen.')}
 <div class="stack">
 <details class="accordion" open><summary>Was ist der Unterschied zwischen Partei und kommunaler Wählergemeinschaft?</summary><div><p>Die <strong>Landesvereinigung FREIE WÄHLER Bayern</strong> ist die Parteigliederung für Einzelpersonen. Der <strong>FW-Landesverband Bayern</strong> ist der Dachverband örtlicher und regionaler Wählergemeinschaften. Die beiden Organisationen sind rechtlich getrennt; eine örtliche Vereinsmitgliedschaft ist nicht automatisch eine Parteimitgliedschaft.</p><p style="margin-top:12px"><a class="btn primary" href="#struktur">Ausführlichen Vergleich und beide Satzungen öffnen →</a></p></div></details>
 <details class="accordion"><summary>Wie ist der Weg von meinem Ort bis zur Bundesebene?</summary><div><p>Die Orientierung läuft über örtliche Gruppierungen oder Parteigliederungen, Kreisorganisation, Bezirks- und Landesebene bis zur Bundesvereinigung. Zuständigkeiten und Mitgliedsrechte richten sich nach der konkreten Organisation und ihren aktuellen Satzungen.</p></div></details>
 <details class="accordion"><summary>Wie kann ich mich in einem Fachgremium engagieren?</summary><div><p>Suche zunächst Deinen Themenbereich, zum Beispiel Soziales, Gesundheit, Wirtschaft oder Bildung. Nimm über die zuständige Landes- beziehungsweise Bundesgeschäftsstelle Kontakt auf und frage nach der aktuellen Struktur und Teilnahmevoraussetzungen.</p></div></details>
 <details class="accordion"><summary>Wer pflegt Inhalte und Kontakte im Kompass?</summary><div><p>Inhalte und Kontakte werden aus veröffentlichten Quellen sowie über die geschützten Redaktionsfunktionen gepflegt. Hinweise auf Änderungen kannst Du über die angegebenen Kontaktseiten melden.</p></div></details>
 </div>
 ${sectionLine('Offizielle Dokumente & Websites')}
 <div class="searchbox" style="max-width:100%;margin-bottom:16px"><input id="resource-search" aria-label="Wissensbereich durchsuchen" placeholder="Links und Themen suchen …" type="search" value="${esc(state.resourceQuery)}"></div>
 <div class="cards" id="resource-list">${r.length?r.map(x=>`<article class="resource-card"><span class="badgel">${esc(x.category)}</span><h3>${esc(x.title)}</h3><p>${esc(x.description)}</p>${external(x.url,'Offizielle Website öffnen')}</article>`).join(''):'<div class="empty">Keine Links gefunden.</div>'}</div>
 ${sectionLine('Lokale Gruppierungen im Landkreis Erding')}
 <p class="muted" style="font-size:13px">Öffentlich gelistete Websites; nicht jede Gruppierung muss ein Parteiorgan sein.</p>
 <div class="source-strip">${state.data.regions.towns.map(t=>t.website?external(t.website,t.name,'btn small'):`<span class="btn small quiet" title="Keine verifizierte Ortswebsite hinterlegt">${esc(t.name)} · Kreis kontaktieren</span>`).join('')}</div>`;
}
function onboarding(){
 const saved=introStatus(),count=introCount();
 return `${head('Für neue Mitglieder','Deine ersten Schritte','Hake ab, was Du bereits erledigt hast. Die Angaben bleiben ausschließlich in Deinem Browser auf diesem Gerät.')}
 <div class="panel" style="margin-bottom:15px"><div class="spread"><div><h2>Dein persönlicher Start</h2><span class="tiny">${count} von ${INTRO_STEPS.length} erledigt</span></div><span class="tag">${Math.round(count/INTRO_STEPS.length*100)} %</span></div><div class="progress-line"><div class="progress-fill" style="width:${count/INTRO_STEPS.length*100}%"></div></div></div>
 <div class="checklist">${INTRO_STEPS.map(([title,desc],i)=>`<label class="check-item"><input type="checkbox" data-step="${i}" ${saved[i]?'checked':''}><span><strong>${esc(title)}</strong><small>${esc(desc)}</small></span></label>`).join('')}</div>
 <div class="actions" style="margin-top:16px"><button id="clear-steps" class="btn quiet" type="button">Checkliste zurücksetzen</button><a href="#wegweiser" class="btn primary">Passenden Kontakt suchen →</a></div>`;
}
function info(){
 return `${head('PILOTPROJEKT · LANDKREIS ERDING','Über den FW Kompass','Der FW Kompass ist öffentlich gestartet und hilft bei der Orientierung in der Welt der FREIEN WÄHLER im Landkreis Erding. Das Angebot wird im Rahmen eines Pilotprojekts weiterentwickelt.')}
 <div class="stack"><div class="panel"><h2>Was Du im FW Kompass findest</h2><ul class="bullets"><li>Mitgliederwegweiser und Ansprechpartner der verschiedenen Organisationsebenen</li><li>Ortsgruppen im Landkreis Erding und Links zu den jeweiligen Organisationen</li><li>Vergleich von Landesvereinigung (Partei) und Landesverband (Wählergemeinschaften) anhand ihrer Satzungen</li><li>Informationen zu Bundesfachausschüssen und Bundesarbeitsgemeinschaften</li><li>Who is Who mit Abgeordneten und veröffentlichten Vorstandsangaben</li><li>Nachrichten aus bestätigten Quellen und Links zu den Originalseiten</li><li>Redaktionell verlinkte Beiträge von Landtagsabgeordneten</li><li>Mitteilungen, freiwillige Push-Benachrichtigungen und Installationshilfe</li></ul></div>
 <div class="panel"><h2>Aktualität und Quellen</h2><p>Die Nachrichten werden nur angezeigt, wenn sie redaktionell eingetragen oder durch die Quellenprüfung eindeutig erkannt wurden. Instagram-Beiträge werden nicht automatisch importiert; aktuelle Posts sind über die Profil-Links erreichbar. Termine werden direkt auf den Seiten ihrer Veranstalter gepflegt.</p><p>Kontakte und Funktionen können sich ändern. Maßgeblich sind die jeweils verlinkten offiziellen Websites.</p></div>
 <div class="panel"><h2>Quellen und Kontakt</h2><div class="source-strip">${SOURCE_LINKS.map(s=>external(s.url,s.label,'btn')).join('')}${external('https://www.fw-landkreis-erding.de/kontakt','Kontakt Erding','btn')}${external('https://www.freiewaehler.eu/services/kontakt/','Kontakt Bund','btn')}</div></div>
 <div class="padded-note"><strong>Projektstatus:</strong> Der FW Kompass wird als eigenständig betriebenes, öffentlich zugängliches Pilotprojekt für den Landkreis Erding bereitgestellt. Eine formelle Herausgeberschaft oder Beauftragung durch die Bundes- oder Landesvereinigung wird damit nicht behauptet. Betreiberinformationen und Datenschutz findest Du unter <a href="#rechtliches">Rechtliches</a>.</div></div>`;
}

// Freiwillige, ausschließlich aggregierte Statistik. Ohne Opt-in: keine Ereignisse.
// Neue ausdrückliche Zustimmung für Inhaltsaufrufe und Betrachtungszeiten erforderlich.
const STATS_PREF='fw-kompass-analytics-consent-v2';
let statsConsent=false;try{statsConsent=localStorage.getItem(STATS_PREF)==='yes'}catch{}
let visitRecorded=false,lastRouteRecorded='';
function track(type,category=''){
 if(!statsConsent || location.protocol!=='https:')return;
 const body=new URLSearchParams({type,category});
 fetch('./api/version.php?mode=stats&action=event',{method:'POST',body,credentials:'omit',cache:'no-store',keepalive:true}).catch(()=>{});
}
// Bei Zustimmung: Inhaltskarten zählen, die mindestens 3 Sekunden sichtbar sind.
// Messung erfolgt OHNE Nutzerkennungen, Cookies oder individuelle Sitzungsprotokolle.
// Die Zeit misst nur aktive Sichtbarkeit, nicht ob der Beitrag tatsächlich gelesen wurde.
let contentObserver=null;
let trackedContent=new Map();
let trackedOnce=new Set();
function trackContent(type,info,seconds=0){
 if(!statsConsent||location.protocol!=='https:')return;
 const body=new URLSearchParams({type,category:info.kind,item:info.id,title:info.title});
 if(type==='content_seconds')body.set('value',String(seconds));
 fetch('./api/version.php?mode=stats&action=event',{method:'POST',body,credentials:'omit',cache:'no-store',keepalive:true}).catch(()=>{});
}
function flushContent(info){
 if(info.timer){clearTimeout(info.timer);info.timer=null;}
 if(info.started===null)return;
 const elapsed=Math.min(300,Math.floor((performance.now()-info.started)/1000));
 if(elapsed>=5 && info.counted){
  const bucket=Math.min(300,Math.floor(elapsed/5)*5);
  if(bucket>=5)trackContent('content_seconds',info,bucket);
 }
 info.started=null;
}
function stopContentTracking(){
 if(contentObserver){contentObserver.disconnect();contentObserver=null;}
 for(const info of trackedContent.values())flushContent(info);
 trackedContent.clear();
}
function startContentTracking(){
 if(!statsConsent||!('IntersectionObserver' in window)||document.hidden)return;
 const cards=document.querySelectorAll('[data-stat-kind][data-stat-id][data-stat-title]');
 if(!cards.length)return;
 contentObserver=new IntersectionObserver(entries=>{
  for(const entry of entries){
   const info=trackedContent.get(entry.target);if(!info)continue;
   if(entry.isIntersecting && entry.intersectionRatio>=0.4 && !document.hidden){
    if(info.started!==null)continue;
    info.started=performance.now();
    if(!info.counted){
     info.timer=setTimeout(()=>{
      if(info.started!==null && !document.hidden){
       info.counted=true;
       trackedOnce.add(info.kind+':'+info.id);
       trackContent('content_view',info);
      }
     },3000);
    }
   }else flushContent(info);
  }
 },{threshold:[0,0.4,0.6]});
 for(const card of cards){
  const kind=card.dataset.statKind,id=card.dataset.statId,title=card.dataset.statTitle;
  if(!['news','mdl'].includes(kind)||!id||!title||!/^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$/.test(id))continue;
  const info={kind,id,title: title.slice(0,140),started:null,timer:null,counted:trackedOnce.has(kind+':'+id)};
  trackedContent.set(card,info);contentObserver.observe(card);
 }
}
document.addEventListener('visibilitychange',()=>{
 if(document.hidden)stopContentTracking();else startContentTracking();
});
window.addEventListener('pagehide',stopContentTracking);
function maybeTrackRoute(id){
 if(!statsConsent)return;
 if(!visitRecorded){track('visit');visitRecorded=true;}
 if(id!==lastRouteRecorded&&id!=='statistik'){track('section',id);lastRouteRecorded=id;}
}
function setStatsChoice(allowed){
 statsConsent=allowed;
 try{localStorage.setItem(STATS_PREF,allowed?'yes':'no')}catch{}
 if(allowed){visitRecorded=false;lastRouteRecorded='';maybeTrackRoute(state.route);}else{stopContentTracking();trackedOnce.clear();}
 draw();
}
document.addEventListener('click',event=>{
 if(!statsConsent)return;
 const a=event.target.closest('a[href]');if(!a)return;
 let u;try{u=new URL(a.href,location.href)}catch{return;}
 if(!['https:','http:'].includes(u.protocol)||u.origin===location.origin)return;
 const host=u.hostname;
 let category='sonstige';
 if(host.endsWith('freiewaehler.eu'))category='bund';
 else if(host.endsWith('fw-bayern.de'))category='bayern';
 else if(host.endsWith('fw-landkreis-erding.de'))category='erding';
 const download=a.hasAttribute('download')||/\.(?:pdf|zip|docx?|xlsx?|pptx?)(?:$|[?#])/i.test(u.pathname);
 track(download?'download':'external',category);
},true);

let legalConfig={configured:false};
const legalFields=['operator_name','street','postal','city','email','phone','editor_name','editor_address','hosting_logs'];
const publicValue=(key,fallback='Noch einzutragen')=>esc(legalConfig[key]||fallback);
async function loadLegal(){try{const r=await fetch('./api/version.php?mode=legal',{cache:'no-store'});if(r.ok){legalConfig=await r.json();if(state.route==='rechtliches')draw();}}catch{}}
function legalPage(){
 const ready=legalConfig.configured;
 const address=`${publicValue('street')}<br>${publicValue('postal')} ${publicValue('city')}`;
 const mail=legalConfig.email?`<a href="mailto:${esc(legalConfig.email)}">${esc(legalConfig.email)}</a>`:'<strong>E-Mail noch einzutragen</strong>';
 return `${head('Transparenz & rechtliche Angaben','Impressum & Datenschutz','Informationen zum FW Kompass, zum Betreiber und zur freiwilligen Nutzung der Statistik.')}
 ${ready?'':'<div class="alert orange"><strong>Betreiberangaben noch unvollständig.</strong> Der Betreiber muss sie unverzüglich in der geschützten Statistikverwaltung ergänzen. Dieser Text ersetzt kein fertiges Impressum.</div>'}
 <section class="panel legal-document"><h2>Impressum</h2><p>Angaben nach § 5 Digitale-Dienste-Gesetz (DDG) und § 18 Medienstaatsvertrag (MStV), soweit jeweils anwendbar.</p>
 <h3>Anbieter / Verantwortlicher</h3><p><strong>${publicValue('operator_name')}</strong><br>${address}<br>E-Mail: ${mail}${legalConfig.phone?`<br>Telefon: ${esc(legalConfig.phone)}`:''}</p>
 <h3>Verantwortlich für journalistisch-redaktionelle Inhalte</h3><p>${publicValue('editor_name','Noch festzulegen (sofern § 18 Abs. 2 MStV einschlägig)')}<br>${publicValue('editor_address','Anschrift der verantwortlichen Person ergänzen, soweit erforderlich')}</p>
 <h3>Projektstatus</h3><p>FW Kompass ist ein öffentlich gestartetes, eigenständig betriebenes Pilotprojekt für den Landkreis Erding. Eine offizielle Herausgeberschaft oder Beauftragung durch die Bundes- oder Landesvereinigung wird nicht behauptet.</p>
 <h3>Externe Links und Inhalte</h3><p>Auf Drittseiten und deren Datenschutzbestimmungen haben wir keinen Einfluss. Offizielle Verbandsseiten werden als Quellen verlinkt.</p></section>
 <section class="panel legal-document"><h2>Datenschutzhinweise gemäß Art. 13 DSGVO</h2>
 <h3>1. Verantwortliche Stelle</h3><p>${publicValue('operator_name')} · ${address}. Kontakt: ${mail}.</p>
 <h3>2. Hosting und technische Zugriffe</h3><p>Die App wird über den deutschen Hostingdienst goneo bereitgestellt. Beim Abruf kann der Hoster technisch notwendige Verbindungsdaten (einschließlich IP-Adresse, Zeitpunkt und angeforderter Datei) verarbeiten. Zwecke: Bereitstellung und Sicherheit des Angebots; als mögliche Rechtsgrundlage kommt Art. 6 Abs. 1 lit. f DSGVO in Betracht. Die konkreten Speicherfristen und der Auftragsverarbeitungsvertrag müssen mit dem Anbieter abgeglichen werden.</p>
 <p><strong>Speicherfrist der Hosting-Logs:</strong> ${publicValue('hosting_logs','Noch mit goneo zu klären und nachzutragen')}.</p>
 <h3>3. Freiwillige Nutzungsstatistik</h3><p>Die Statistik ist zunächst deaktiviert. Erst nach aktiver Zustimmung (Art. 6 Abs. 1 lit. a DSGVO, § 25 TDDDG soweit einschlägig) sendet die App an den eigenen Server: App-Aufrufe, geöffnete Bereiche, Klicks auf externe Links/Downloads sowie die Kennung und Überschrift öffentlich angezeigter Nachrichten- und MdL-Beiträge. Ein Beitrag zählt als „betrachtet“, wenn seine Karte mindestens drei Sekunden überwiegend sichtbar war. Zusätzlich wird die sichtbare Zeit in fünf-Sekunden-Schritten erfasst, höchstens 300 Sekunden pro Betrachtungsphase. Die Stunden der App-Aufrufe werden nach deutscher Ortszeit in stündlichen Summen gezählt.</p>
 <p>Der Server speichert ausschließlich Tages-, Stunden- und Beitragssummen, <strong>keine IP-Adressen in der Statistikdatei, Geräte-IDs, Benutzerkennungen, exakten einzelnen Nutzungszeitpunkte oder individuellen Besuchsverläufe</strong>. Ergebnisse gelten nur für zustimmende Geräte und sind keine exakte Besucherzahl. „Betrachtungsdauer“ bedeutet sichtbare Bildschirmzeit, nicht nachgewiesene Lesezeit. Tagesdaten werden 120 Tage aufbewahrt und bei späterer Erfassung bereinigt. Die Zusammenfassungen können kleine Fallzahlen enthalten; die Auswertung ist daher nur für den geschützten Administratorbereich zugänglich.</p>
 <p>Du kannst die Zustimmung jederzeit zurückziehen. Die Entscheidung wird im Browser gespeichert. Für diese erweiterte Statistik ist auch bei einer früheren Zustimmung eine erneute Einwilligung nötig. Ein Personenbezug zu bereits aggregierten Daten ist nicht möglich. Es gibt keine Werbe-Cookies und keine Drittanbieter wie Google Analytics oder Meta Pixel.</p>
 <h3>4. Speicherung auf dem Gerät</h3><p>Als installierbare Web-App (PWA) verwendet der FW Kompass einen Service Worker und einen lokalen Cache für offline nutzbare Programmdateien. Die freiwillige Einsteiger-Checkliste wird nur gespeichert, wenn du die betreffenden Schritte auswählst. Die Statistik-Einstellung wird lokal gespeichert, sobald du dich entscheidest. Ob du App-Mitteilungen bereits gelesen hast und welche App-Version du zuletzt gesehen hast, wird ebenfalls ausschließlich lokal auf deinem Gerät gespeichert. Für Mitteilungen ist keine Besucherregistrierung vorgesehen. Es werden keine Werbe-Cookies gesetzt. § 25 TDDDG ist bei Zugriffen auf das Endgerät zu beachten.</p>
 <h3>5. Externe Porträts und Verweise</h3><p>Porträtbilder im „Who is Who“ kommen teilweise von fremden Websites. Sie werden deshalb <strong>erst nach Tippen auf „Foto laden“</strong> angefordert. Dabei kann die Bildquelle technische Daten wie deine IP-Adresse erhalten. Beim Öffnen externer Links gelten die Hinweise der Zielseite.</p>
 <h3>6. Nachrichten aus offiziellen Quellen</h3><p>Der FW Kompass kann die frei zugänglichen Nachrichtenseiten der Bundesvereinigung, der Landesvereinigung Bayern und des Kreisportals Erding serverseitig in festgelegten Abständen prüfen. Gespeichert werden ausschließlich erkennbare Überschriften, Veröffentlichungsdaten und Links. Beim normalen Aufruf des FW Kompass werden die Drittseiten für diese Nachrichten nicht direkt von deinem Browser kontaktiert. Die Server-IP kann beim Abruf durch die Quellseiten verarbeitet werden. Die Einbindung richtet sich nach den Nutzungsbedingungen der jeweiligen Quelle.</p>
 <h3>7. In-App-Mitteilungen</h3><p>Die App ruft öffentliche Mitteilungen vom eigenen Server ab. Der Betreiber kann Hinweise in der geschützten Verwaltung veröffentlichen. Bereits gelesene In-App-Mitteilungen werden nur auf deinem Gerät vermerkt. Optional kannst du Push-Nachrichten für ausgewählte Themen aktivieren. Erst nach Klick auf „Benachrichtigungen aktivieren“ und Bestätigung der Browserberechtigung speichern wir serverseitig den Push-Endpunkt, die dazugehörigen Verschlüsselungsschlüssel, die gewählten Themen sowie Erstellungs-/Änderungszeitpunkte in einer geschützten SQLite-Datenbank. Wir speichern dafür keine Namen, E-Mail-Adressen oder Mitgliederkennungen. Der Push-Endpunkt ist gerätebezogen und kann personenbezogen sein; die Nutzung einer politisch ausgerichteten App kann Rückschlüsse auf politische Interessen erlauben. Die Verarbeitung erfolgt auf Grundlage deiner ausdrücklichen, freiwilligen Einwilligung gemäß Art. 6 Abs. 1 lit. a DSGVO; soweit besondere Kategorien personenbezogener Daten betroffen sind, kommt Art. 9 Abs. 2 lit. a DSGVO hinzu. Bei der Zustellung werden technisch notwendige Daten an den Push-Dienst des Browsers (z. B. Google, Mozilla, Apple) übermittelt; Drittlandtransfers sind möglich und müssen konkret rechtlich bewertet werden. Abmeldung und Löschung des gespeicherten Abonnements sind jederzeit über den Button „Benachrichtigungen abmelden“ möglich. Wenn du den Zugriff auf dein Gerät verlierst, wende dich an den Betreiber für eine Löschanfrage; nicht mehr zustellbare Abonnements werden bei Rückmeldung HTTP 404/410 aus der Datenbank entfernt. Nicht erneuerte Abonnements werden nach 180 Tagen bei einem späteren Zugriff automatisch gelöscht; erneuerte Abonnements bleiben bestehen. Die Löschung kann früher durch Abmeldung erfolgen. Die Datenübermittlungen an die jeweiligen Anbieter müssen rechtlich geprüft und in den Datenschutzhinweisen zutreffend beschrieben werden.</p>
 <h3>8. Kontaktaufnahme</h3><p>Bei Kontaktaufnahme per E-Mail werden die übermittelten Angaben zur Bearbeitung deines Anliegens verwendet. Je nach Anlass kommen Art. 6 Abs. 1 lit. b oder f DSGVO in Betracht. Der Betreiber muss konkrete Löschfristen seiner Korrespondenz festlegen.</p>
 <h3>9. Deine Rechte</h3><p>Du hast – soweit die Voraussetzungen vorliegen – Rechte auf Auskunft, Berichtigung, Löschung, Einschränkung, Widerspruch, Datenübertragbarkeit und Widerruf erteilter Einwilligungen. Außerdem kannst du dich bei der zuständigen Datenschutzaufsichtsbehörde beschweren. Eine ausschließlich aggregierte Statistik kann nicht einzelnen Personen zugeordnet werden.</p>
 <h3>10. Automatisierte Entscheidungen und Datenübermittlungen</h3><p>Der FW Kompass trifft keine Entscheidungen mit rechtlicher Wirkung über Personen. Die optionalen externen Bildquellen und verlinkten Websites sind gesondert auf Datenübermittlungen außerhalb der EU zu prüfen.</p></section>
 <section class="panel" id="tracking-setting"><h2>Deine Statistik-Einstellung</h2><p>Nur nach aktiver Zustimmung erfassen wir zusammengefasste Aufrufe, angezeigte Beiträge, ungefähre Sichtbarkeitszeiten und Zugriffe nach Tagesstunde. Ohne Zustimmung sendet die App keine Statistikereignisse.</p>
 <div class="privacy-actions"><button type="button" class="btn ${statsConsent?'quiet':'primary'}" id="allow-stats">Statistik erlauben</button><button type="button" class="btn ${!statsConsent?'quiet':'primary'}" id="deny-stats">Nicht erfassen</button></div>
 <p class="tiny" role="status" id="stats-choice">Aktueller Status: <strong>${statsConsent?'Erlaubt':'Ausgeschaltet'}</strong></p></section>
 <p class="legal-below">Stand: November 2026. Diese Datenschutzhinweise sind ein anpassbarer Entwurf; Betreiberidentität, Hosting-Logs, externe Dienste und redaktionelle Verantwortung müssen unabhängig vom öffentlichen Projektstart rechtlich geprüft und vervollständigt werden.</p>
 <a href="#statistik" class="btn quiet">Geschützte Betreiberangaben & Statistik ↗</a>`;
}

// Einmaliges Gedenkfenster: LOCAL STORAGE – keine Serverereignisse, kein Tracking.
const FW_MEMORIAL_SEEN_KEY='fw-kompass-gedenken-hubert-v1';
let memorialStartupPending=true;
let memorialOpen=false;
let memorialShownThisVisit=false;
function closeMemorial(){
 const overlay=$('#fw-memorial-overlay');if(!overlay)return;
 overlay.hidden=true;memorialOpen=false;
 document.body.classList.remove('fw-memorial-open');
 try{localStorage.setItem(FW_MEMORIAL_SEEN_KEY,'seen')}catch{}
}
function showMemorialOnce(){
 const overlay=$('#fw-memorial-overlay');if(!overlay||memorialOpen)return;
 try{if(localStorage.getItem(FW_MEMORIAL_SEEN_KEY)==='seen')return;}catch{}
 memorialShownThisVisit=true;memorialOpen=true;
 overlay.hidden=false;document.body.classList.add('fw-memorial-open');
 $('#fw-memorial-close')?.focus({preventScroll:true});
}
function initMemorial(){
 const overlay=$('#fw-memorial-overlay');if(!overlay)return;
 $('#fw-memorial-close')?.addEventListener('click',closeMemorial);
 $('#fw-memorial-read')?.addEventListener('click',closeMemorial);
 document.addEventListener('keydown',event=>{
  if(!memorialOpen)return;
  if(event.key==='Escape'){event.preventDefault();closeMemorial();return;}
  if(event.key!=='Tab')return;
  const focusable=[...overlay.querySelectorAll('button:not([disabled]),a[href]')].filter(el=>el.offsetParent!==null);
  if(!focusable.length)return;
  const i=focusable.indexOf(document.activeElement);
  if(event.shiftKey&&i===0){event.preventDefault();focusable.at(-1).focus();}
  else if(!event.shiftKey&&i===focusable.length-1){event.preventDefault();focusable[0].focus();}
 });
}

// Einmalige Willkommensauswahl: kein Tracking und keine Push-Berechtigung vor der Interaktion.
const WELCOME_PREF='fw-kompass-welcome-choice-v1';
let welcomeDialogOpen=false;
function closeWelcome(remember=true){
 const overlay=$('#fw-welcome-overlay'); if(!overlay)return;
 overlay.hidden=true;welcomeDialogOpen=false;
 document.body.classList.remove('welcome-open');
 if(remember){try{localStorage.setItem(WELCOME_PREF,'seen')}catch{}}
}
function showWelcomeOnce(){
 const overlay=$('#fw-welcome-overlay');if(!overlay||state.route!=='start'||welcomeDialogOpen)return;
 try{if(localStorage.getItem(WELCOME_PREF)==='seen')return;}catch{}
 const stats=$('#welcome-analytics');if(stats)stats.checked=statsConsent; // Reflect an existing, explicitly granted choice.
 overlay.hidden=false;welcomeDialogOpen=true;
 document.body.classList.add('welcome-open');
 $('#welcome-save')?.focus({preventScroll:true});
}
function initWelcome(){
 const overlay=$('#fw-welcome-overlay');if(!overlay)return;
 const status=$('#welcome-status');const save=$('#welcome-save');const skip=$('#welcome-skip');
 const pushCheck=$('#welcome-push');const topics=$('#welcome-push-topics');
 pushCheck?.addEventListener('change',()=>{if(topics)topics.hidden=!pushCheck.checked;if(status)status.textContent='';});
 skip?.addEventListener('click',()=>closeWelcome(true)); // Does not alter any earlier consent.
 $('#welcome-privacy')?.addEventListener('click',()=>closeWelcome(false));
 document.addEventListener('keydown',e=>{
  if(!welcomeDialogOpen)return;
  if(e.key==='Escape'){e.preventDefault();closeWelcome(true);return;}
  if(e.key==='Tab'){
   const focusable=[...overlay.querySelectorAll('button:not([disabled]),a[href],input:not([disabled])')].filter(el=>el.offsetParent!==null);
   if(focusable.length){const i=focusable.indexOf(document.activeElement);if(e.shiftKey&&i===0){e.preventDefault();focusable.at(-1).focus();}else if(!e.shiftKey&&i===focusable.length-1){e.preventDefault();focusable[0].focus();}}
  }
 });
 save?.addEventListener('click',async()=>{
  if(save.disabled)return;
  const wantsStats=Boolean($('#welcome-analytics')?.checked);
  const wantsPush=Boolean(pushCheck?.checked);
  const selected=['updates','news','events'].filter(k=>$('#welcome-topic-'+k)?.checked);
  if(wantsPush&&!selected.length){status.textContent='Bitte mindestens ein Push-Thema auswählen oder Push deaktivieren.';return;}
  // Explicit opt-in/out to statistics. This does not request system permissions.
  setStatsChoice(wantsStats);
  if(!wantsPush){closeWelcome(true);return;}
  save.disabled=true;skip.disabled=true;status.textContent='Push-Anmeldung wird eingerichtet …';
  try{
   // Subscribing invokes Notification.requestPermission directly from this click handler.
   await subscribeFromWelcome(selected);
   closeWelcome(true);
  }catch(err){
   // Statistics choice remains independent; failed push consent does not block app access.
   status.textContent='Push ist noch nicht aktiviert: '+err.message+' Du kannst trotzdem fortfahren.';
   save.disabled=false;skip.disabled=false;
  }
 });
}

// Öffentliche Mitteilungen – Push nur nach separatem, ausdrücklichem Opt-in.
const NOTICE_READ_KEY='fw-kompass-notice-read-v1';
let noticeFeed={notices:[],release:null};
let noticeStatus='',noticeAdminFeedback='',noticeAdminItems=[];
function readNotices(){try{const data=JSON.parse(localStorage.getItem(NOTICE_READ_KEY)||'[]');return Array.isArray(data)?data.filter(x=>typeof x==='string').slice(-100):[];}catch{return [];}}
function noticedIds(){return new Set(readNotices());}
function notificationEntries(){
 // Versionsinformationen gehören in den Update-Service und werden nicht
 // automatisch dauerhaft als öffentliche redaktionelle Meldungen angezeigt.
 // Bestehende redaktionelle Hinweise bleiben erhalten; nur die veraltete
 // Einführungsmitteilung zum Push-Start wird nicht mehr ausgeliefert.
 const notes=Array.isArray(noticeFeed.notices)?noticeFeed.notices:[];
 return notes.filter(n=>{
  const title=String(n.title||'').trim().toLocaleLowerCase('de');
  const body=String(n.text||'').trim().toLocaleLowerCase('de');
  if(title==='push nachrichten' && body==='push nachrichten sind jetzt verfügbar.')return false;
  return true;
 }).sort((a,b)=>String(b.published||'').localeCompare(String(a.published||'')));
}
function unreadNotices(){const seen=noticedIds();return notificationEntries().filter(n=>!seen.has(n.id));}
function noticeHomeTeaser(){
 const pending=unreadNotices();
 if(!pending.length)return `<div class="notice-home"><span class="notice-dot" aria-hidden="true"></span><strong>Neuigkeiten zum FW Kompass</strong><a href="#mitteilungen">Alle Mitteilungen ansehen →</a></div>`;
 return `<div class="notice-home notice-home-new"><span class="notice-dot" aria-hidden="true"></span><div><strong>${pending.length} neue ${pending.length===1?'Mitteilung':'Mitteilungen'}</strong><p>${esc(pending[0].title)}</p></div><a class="btn small primary" href="#mitteilungen">Jetzt ansehen →</a></div>`;
}
function markAllNotices(){try{localStorage.setItem(NOTICE_READ_KEY,JSON.stringify([...new Set([...readNotices(),...notificationEntries().map(n=>n.id)])].slice(-100)));}catch{}draw();}
function noticeBadge(){
 const n=unreadNotices().length;
 const indicator=document.querySelector('#notice-badge');
 if(indicator){indicator.hidden=!n;indicator.textContent=n>9?'9+':String(n);}
 const header=document.querySelector('#header-notice-link');
 if(header)header.setAttribute('aria-label',n?`Mitteilungen: ${n} ungelesen`:'Mitteilungen');
}
async function loadPublicNotices(){
 try{
  const r=await fetch('./api/version.php?mode=notices&t='+Date.now(),{cache:'no-store',credentials:'omit'});
  if(!r.ok)throw new Error('HTTP '+r.status);
  const data=await r.json();
  if(!data||!Array.isArray(data.notices))throw new Error('Ungültiges Format');
  noticeFeed=data;noticeStatus='';
 }catch(e){
  noticeStatus='Neue Mitteilungen sind momentan nicht erreichbar. Bitte später erneut prüfen.';
 }
 if(state.route==='mitteilungen'||state.route==='start')draw();else noticeBadge();
}
function notificationCard(n){const seen=noticedIds().has(n.id);const l=n.link&&safeUrl(n.link)!=='#'?`<a class="text-link" href="${esc(safeUrl(n.link))}" target="_blank" rel="noopener noreferrer">Weitere Informationen ↗</a>`:n.link&&n.link.startsWith('#')?`<a class="text-link" href="${esc(n.link)}">In der App öffnen →</a>`:'';
 return `<article class="notice-item ${seen?'':'notice-unread'}"><div class="notice-heading"><span class="notice-kind">${esc(({update:'App-Update',hinweis:'Hinweis',termin:'Termin'}[n.type])||'Mitteilung')}</span>${!seen?'<span class="notice-new">NEU</span>':''}<time class="tiny" datetime="${esc(n.published||'')}">${date(n.published||'')}</time></div><h3>${esc(n.title)}</h3><p>${esc(n.text)}</p>${l}</article>`;
}
function notificationsPage(){
 const items=notificationEntries();
 const list=items.length?items.map(notificationCard).join(''):'<p>Momentan gibt es keine Mitteilungen.</p>';
 const admin=statSession.authenticated?`
 <section class="panel notice-admin"><h2>Mitteilung veröffentlichen</h2><p>Neue Hinweise erscheinen nach dem Speichern für alle, die die App öffnen. Keine Push-Nachricht bei geschlossener App.</p>
 <form id="notice-form" class="stat-form">
 <label>Art<select name="type"><option value="hinweis">Allgemeiner Hinweis</option><option value="update">Update-Hinweis</option><option value="termin">Termin-Hinweis</option></select></label>
 <label>Überschrift<input name="title" maxlength="120" required placeholder="z. B. Neue Funktionen im FW Kompass"></label>
 <label>Mitteilung<textarea name="text" rows="4" maxlength="1200" required placeholder="Was sollen die Nutzer wissen?"></textarea></label>
 <label>Optionaler Link (https://... oder #news)<input name="link" maxlength="500" placeholder="https://..."></label>
 <label>Optionales Ablaufdatum<input type="date" name="expires"></label>
 <button class="btn primary" type="submit">Mitteilung veröffentlichen</button>
 </form><p id="notice-admin-feedback" role="status">${esc(noticeAdminFeedback)}</p></section>
 <section class="panel"><h2>Mitteilungen verwalten</h2>${noticeAdminItems.map(n=>`<div class="notice-admin-row"><span>${esc(n.title)}</span><button class="btn small quiet" data-notice-remove="${esc(n.id)}" type="button">Löschen</button></div>`).join('')||'<p>Keine redaktionellen Mitteilungen.</p>'}</section>`
 :`<section class="panel notice-admin"><h2>Redaktion (geschützt)</h2><p>Als Administrator kannst du neue Mitteilungen ohne GitHub-Update veröffentlichen.</p><form id="notice-login" class="stat-form"><label>Administratorpasswort<input type="password" name="password" minlength="12" autocomplete="current-password" required></label><button class="btn primary" type="submit">Anmelden</button></form><p id="notice-admin-feedback" role="status">${esc(noticeAdminFeedback)}</p></section>`;
 return `${head('Aktuelles aus der App','Mitteilungen & Hinweise','Aktuelle Informationen des FW-Kompass-Betreibers.')}
 <section class="panel"><div class="spread"><h2>Alle Mitteilungen</h2><span class="tag">${unreadNotices().length} ungelesen</span></div><p class="tiny">Mitteilungen werden beim Öffnen der App und beim Zurückwechseln automatisch geprüft. Keine Benachrichtigungen bei geschlossener App.</p><button type="button" id="notice-mark-all" class="btn small quiet">Alle als gelesen markieren</button><button type="button" id="notice-check" class="btn small quiet">Jetzt prüfen</button>${noticeStatus?`<p class="tiny" role="status">${esc(noticeStatus)}</p>`:''}</section>
 <div class="notice-list">${list}</div>${pushPanel()}${admin}${statSession.authenticated?pushAdminPanel():''}`;
}
async function loadNoticeAdmin(){if(statSession.authenticated){try{const d=await noticesApi('admin');noticeAdminItems=d.notices||[];}catch{noticeAdminItems=[];}}}
async function noticesApi(action,body=null){const q=new URLSearchParams({mode:'notices',action});const res=await fetch('./api/version.php?'+q.toString(),{method:body?'POST':'GET',credentials:'same-origin',cache:'no-store',body:body?new URLSearchParams(body):undefined});const d=await res.json();if(!res.ok)throw new Error(d.error||'Serverfehler');return d;}
function wireNotices(){
 wirePush(statSession.authenticated?statSession.csrf:'');
 $('#notice-mark-all')?.addEventListener('click',markAllNotices);
 $('#notice-check')?.addEventListener('click',loadPublicNotices);
 $('#notice-login')?.addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget;noticeAdminFeedback='Anmeldung läuft …';try{if(!statSession.csrf)statSession=await apiStats('status');await apiStats('login',{csrf:statSession.csrf,password:f.elements.password.value});noticeAdminFeedback='Angemeldet.';await loadStatSession();await loadNoticeAdmin();await loadPublicNotices();}catch(err){noticeAdminFeedback='Anmeldung fehlgeschlagen: '+err.message;draw();}});
 $('#notice-form')?.addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget;const data={csrf:statSession.csrf};for(const key of ['title','text','type','link','expires'])data[key]=f.elements[key].value;noticeAdminFeedback='Wird veröffentlicht …';try{await noticesApi('add',data);noticeAdminFeedback='Mitteilung veröffentlicht.';f.reset();await loadNoticeAdmin();await loadPublicNotices();}catch(err){noticeAdminFeedback=err.message;draw();}});
 document.querySelectorAll('[data-notice-remove]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Mitteilung wirklich löschen?'))return;try{await noticesApi('remove',{csrf:statSession.csrf,id:b.dataset.noticeRemove});noticeAdminFeedback='Mitteilung gelöscht.';await loadNoticeAdmin();await loadPublicNotices();}catch(err){noticeAdminFeedback=err.message;draw();}}));
}

const apiStats=(action,body=null)=>fetch(`./api/version.php?mode=stats&action=${action}`,{method:body?'POST':'GET',body:body?new URLSearchParams(body):undefined,credentials:'same-origin',cache:'no-store'}).then(async r=>{const data=await r.json();if(!r.ok)throw new Error(data.error||`HTTP ${r.status}`);return data;});
const statLabels={start:'Startseite',wegweiser:'Wegweiser',vorort:'FW vor Ort',struktur:'Partei oder Verband',news:'Aktuelles',mitteilungen:'Mitteilungen',kontakte:'Ansprechpartner',personen:'Who is Who',mdl:'MdL Aktuell',gremien:'Bundesgremien',termine:'Termine',wissen:'Wissen',einstieg:'Mein Einstieg',info:'Über das Projekt',rechtliches:'Rechtliches'};
let statSession={authenticated:false,csrf:''},statReport=null;
let statsPeriod=30;
function statsPage(){
 const top=head('Administration','Statistik & Betreiberangaben','Geschützter Bereich. Anmeldung mit deinem bisherigen FW-Kompass-Administratorpasswort.');
 if(!statSession.authenticated)return `${top}<section class="panel"><h2>Anmelden</h2><form id="stats-login" class="stat-form"><label for="stats-password">Administratorpasswort</label><input id="stats-password" name="password" type="password" autocomplete="current-password" required minlength="12"/><button class="btn primary" type="submit">Statistik öffnen</button></form><p class="tiny">Der Statistikbereich hat aus technischen Gründen eine separate Sitzung. Dein bestehendes Passwort aus der Updateverwaltung gilt auch hier.</p><p id="stats-feedback" class="tiny" role="status"></p></section>`;
 if(!statReport)return `${top}<section class="panel"><p>Die Statistik wird geladen …</p><p id="stats-feedback" role="status"></p></section>`;
 const from=new Date(Date.now()-(statsPeriod-1)*86400000).toLocaleDateString('sv-SE',{timeZone:'Europe/Berlin'});
 const days=Object.entries(statReport.days||{}).filter(([day])=>day>=from).sort((a,b)=>a[0].localeCompare(b[0]));
 const totals={visit:0,section:{},external:{},download:{},install:0};
 days.forEach(([,d])=>{totals.visit+=d.visit||0;totals.install+=d.install||0;for(const k of ['section','external','download'])Object.entries(d[k]||{}).forEach(([label,val])=>{totals[k][label]=(totals[k][label]||0)+val;});});
 const sum=x=>Object.values(x).reduce((a,b)=>a+b,0);
 const last=days.slice(-14);const max=Math.max(1,...last.map(([,v])=>v.visit||0));
 const chart=last.map(([day,v])=>`<div class="stat-bar-col"><div class="stat-bar" style="height:${Math.max(3,(v.visit||0)/max*120)}px" title="${esc(day)}: ${v.visit||0} Aufrufe"></div><small>${esc(day.slice(5))}</small></div>`).join('');
 const sections=Object.entries(totals.section).sort((a,b)=>b[1]-a[1]);
 const breakdown=sections.length?sections.map(([name,n])=>`<li><span>${esc(statLabels[name]||name)}</span><strong>${n}</strong></li>`).join(''):'<li>Noch keine Daten</li>';
 const byHour=Array(24).fill(0),byWeekday=Array(7).fill(0),items={};
 days.forEach(([day,d])=>{
  for(const [h,n] of Object.entries(d.hours||{}))if(/^\d\d$/.test(h)&&Number(h)<24)byHour[Number(h)]+=Number(n)||0;
  const dow=new Date(day+'T12:00:00+01:00').getUTCDay();byWeekday[(dow+6)%7]+=Number(d.visit)||0;
  for(const [key,obj] of Object.entries(d.content||{})){
   if(!obj||!['news','mdl'].includes(obj.kind)||typeof obj.title!=='string')continue;
   const x=items[key]||(items[key]={title:obj.title,kind:obj.kind,views:0,seconds:0});
   x.views+=Number(obj.views)||0;x.seconds+=Number(obj.seconds)||0;
  }
 });
 const maxHour=Math.max(1,...byHour);
 const hourBars=byHour.map((n,i)=>`<div class="insight-hour" title="${i}:00–${i}:59 Uhr · ${n} Aufrufe"><div class="insight-hour-track"><span style="height:${Math.max(2,n/maxHour*100)}%"></span></div><small>${i%3===0?i.toString().padStart(2,'0'):''}</small></div>`).join('');
 const maxWeekday=Math.max(1,...byWeekday);
 const weekdayBars=['Mo','Di','Mi','Do','Fr','Sa','So'].map((label,i)=>`<div class="insight-day"><span>${label}</span><div class="insight-day-track"><span style="width:${byWeekday[i]/maxWeekday*100}%"></span></div><strong>${byWeekday[i]}</strong></div>`).join('');
 const peakHour=byHour.some(x=>x>0)?byHour.indexOf(Math.max(...byHour)):-1;
 const contentRanking=Object.values(items).filter(x=>x.views>0).sort((a,b)=>b.views-a.views).slice(0,15);
 const contentRows=contentRanking.map((item,i)=>`<tr><td>${i+1}</td><td><strong>${esc(item.title)}</strong><small>${item.kind==='mdl'?'MdL Aktuell':'Nachrichten'}</small></td><td>${item.views}</td><td>${item.seconds?Math.round(item.seconds/item.views)+' s':'–'}</td></tr>`).join('');
 const legal=statReport.legal||{};
 const field=(key,label,required=false)=>`<label>${esc(label)}${required?' *':''}<input type="${key==='email'?'email':'text'}" name="${key}" maxlength="500" value="${esc(legal[key]||'')}" ${required?'required':''}/></label>`;
 return `${top}<div class="stat-mini-actions"><span class="tag">Summierte Daten · ${days.length} Tage</span><button class="btn small quiet" id="stats-refresh">Aktualisieren</button><button class="btn small quiet" id="stats-logout">Abmelden</button></div>
 <div class="stat-cards"><div><small>App-Aufrufe*</small><strong>${totals.visit}</strong></div><div><small>Bereichsaufrufe</small><strong>${sum(totals.section)}</strong></div><div><small>Externe Klicks</small><strong>${sum(totals.external)}</strong></div><div><small>Download-Klicks</small><strong>${sum(totals.download)}</strong></div><div><small>Installationsereignisse*</small><strong>${totals.install}</strong></div></div>
 <section class="panel insight-panel"><h2>Vertiefte Nutzungsanalyse</h2><p class="tiny">Zeitraum: <select id="stats-period" aria-label="Auswertungszeitraum"><option value="7" ${statsPeriod===7?'selected':''}>7 Tage</option><option value="30" ${statsPeriod===30?'selected':''}>30 Tage</option><option value="90" ${statsPeriod===90?'selected':''}>90 Tage</option><option value="120" ${statsPeriod===120?'selected':''}>120 Tage</option></select> · Nur freiwillig zustimmende Geräte; keine Personenanalyse.</p>
 <h3>Wann wird der FW Kompass aufgerufen?</h3><p>${peakHour<0?'Noch keine Messwerte.':`Höchste erfasste Aufrufzahl zwischen <strong>${String(peakHour).padStart(2,'0')}:00 und ${String(peakHour+1).padStart(2,'0')}:00 Uhr</strong> (über alle ausgewählten Tage zusammen).`}</p>
 <div class="insight-hours" aria-label="App-Aufrufe nach Uhrzeit">${hourBars}</div>
 <h3>Welche Wochentage sind am stärksten?</h3><div class="insight-weekdays">${weekdayBars}</div>
 <h3>Welche Einzelbeiträge werden betrachtet?</h3><div class="insight-table-scroll"><table class="insight-table"><thead><tr><th>#</th><th>Beitrag</th><th>Sichtkontakte</th><th>Ø Sichtzeit</th></tr></thead><tbody>${contentRows||'<tr><td colspan="4">Noch keine Zustimmungsdaten zu Beiträgen.</td></tr>'}</tbody></table></div>
 <p class="tiny">Ein Sichtkontakt entsteht, wenn eine Beitragskarte mindestens 3 Sekunden überwiegend im Sichtfeld bleibt. Das ist kein Nachweis, dass der Text gelesen wurde. Die Ø Sichtzeit ist grob gerundet und technisch bedingt nicht auf allen Geräten verfügbar. Keine Aufzeichnung, welcher Nutzer wann welchen Beitrag gelesen hat.</p></section>
 <section class="panel"><h2>App-Aufrufe der letzten 14 Tage</h2><div class="stat-bars">${chart||'<p>Noch keine Daten.</p>'}</div><p class="tiny">* Aufrufe mit Zustimmung; keine eindeutigen Besucher. Installationen sind technisch nicht auf jedem Gerät messbar. Download-Klicks sind keine bestätigten Downloads. Statistiken sind nicht rückwirkend verfügbar.</p></section>
 <div class="split"><section class="panel"><h2>Bereiche</h2><ul class="stat-list">${breakdown}</ul></section><section class="panel"><h2>Externe Zielkategorien</h2><ul class="stat-list">${Object.entries(totals.external).map(([k,n])=>`<li><span>${esc(k)}</span><strong>${n}</strong></li>`).join('')||'<li>Keine Klicks</li>'}</ul><h2>Download-Klicks</h2><ul class="stat-list">${Object.entries(totals.download).map(([k,n])=>`<li><span>${esc(k)}</span><strong>${n}</strong></li>`).join('')||'<li>Keine Klicks</li>'}</ul></section></div>
 <section class="panel"><h2>Impressum und Verantwortliche pflegen</h2><p>Diese Angaben erscheinen nach dem Speichern öffentlich im Rechtliches-Bereich der App. Bitte trage den <strong>tatsächlich verantwortlichen Betreiber</strong> und eine ladungsfähige Anschrift ein – keine erfundenen oder privaten Mitgliederdaten.</p>
 <form id="legal-form" class="stat-form"><div class="legal-fields">${field('operator_name','Betreiber / Name oder Organisation',true)}${field('street','Straße und Hausnummer',true)}${field('postal','PLZ',true)}${field('city','Ort',true)}${field('email','Kontakt-E-Mail',true)}${field('phone','Telefon / unmittelbarer Kontaktweg')}${field('editor_name','Redaktionell verantwortlich (falls zutreffend)')}${field('editor_address','Anschrift des redaktionell Verantwortlichen')}${field('hosting_logs','Speicherfrist goneo-Serverlogs (noch zu prüfen)')}</div><button class="btn primary" type="submit">Rechtliche Angaben speichern</button></form><p id="stats-feedback" role="status" class="tiny"></p></section>
 <p class="tiny">Statistikdatei: ausschließlich aufsummierte Tageswerte, automatische Löschung nach 120 Tagen bei der nächsten Erfassung. Die Daten werden in einem gegen Webzugriffe geschützten Verzeichnis der Serverinstallation gespeichert.</p>`;
}
async function loadStatSession(){try{statSession=await apiStats('status');if(statSession.authenticated){statReport=await apiStats('read',{csrf:statSession.csrf});}if(['statistik','mdl','redaktion'].includes(state.route))draw();}catch(e){if(state.route==='statistik'||state.route==='redaktion'){const el=$(state.route==='statistik'?'#stats-feedback':'#mdl-login-status');if(el)el.textContent='Statistik derzeit nicht erreichbar: '+e.message;}}}
function wireLegal(){
 $('#allow-stats')?.addEventListener('click',()=>setStatsChoice(true));
 $('#deny-stats')?.addEventListener('click',()=>setStatsChoice(false));
}
function wireStats(){
 $('#stats-login')?.addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget;const feedback=$('#stats-feedback');feedback.textContent='Anmeldung läuft …';try{await apiStats('login',{csrf:statSession.csrf,password:f.elements.password.value});await loadStatSession();}catch(err){feedback.textContent=err.message;}});
 $('#stats-refresh')?.addEventListener('click',()=>loadStatSession());
 $('#stats-period')?.addEventListener('change',e=>{statsPeriod=Number(e.target.value)||30;draw();});
 $('#stats-logout')?.addEventListener('click',async()=>{await apiStats('logout',{csrf:statSession.csrf});statSession.authenticated=false;statReport=null;draw();});
 $('#legal-form')?.addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget;const data={csrf:statSession.csrf};for(const name of legalFields)data[name]=f.elements[name].value;const fb=$('#stats-feedback');fb.textContent='Speichert …';try{await apiStats('save_legal',data);await loadLegal();fb.textContent='Betreiberangaben gespeichert.';}catch(err){fb.textContent='Fehler: '+err.message;}});
}

function draw(){
 stopContentTracking();
 const hash=location.hash.slice(1).toLowerCase();state.route=ROUTES.some(r=>r.id===hash)?hash:'start';nav();
 const views={start,mitteilungen:notificationsPage,mitglied:becomeMember,wegweiser:guide,vorort:localGroups,struktur:partyOrFederation,news,gedenken:memorialPage,mdl:mdlAktuell,redaktion:mdlEditorPage,kontakte:contacts,personen:whoIsWho,gremien:federalBodies,termine:events,wissen:knowledge,einstieg:onboarding,info,rechtliches:legalPage,statistik:statsPage};
 $('#view').innerHTML=(state.loadError?'<div class="alert orange">Einige lokale Datendateien konnten nicht geladen werden. Bitte die App über HTTPS oder einen lokalen Webserver öffnen – nicht direkt mit file://.</div>':'')+views[state.route]();
 wire();
 noticeBadge();
 maybeTrackRoute(state.route);
 startContentTracking();
 // Das Gedenken zuerst zeigen. Die freiwilligen Einstellungen frühestens beim nächsten App-Start anbieten.
 if(memorialStartupPending){memorialStartupPending=false;showMemorialOnce();}
 if(state.route==='start'&&!memorialOpen&&!memorialShownThisVisit)showWelcomeOnce();
}

function wire(){
 if(state.route==='rechtliches')wireLegal();
 if(state.route==='statistik')wireStats();
 if(state.route==='mitteilungen')wireNotices();
 if(state.route==='mdl')wireMdl();
 if(state.route==='redaktion')wireMdlEditor();
 if(state.route==='start'){
  const install=$('#install-app-btn'); if(install)install.addEventListener('click',installApp);
  $('#check-app-updates')?.addEventListener('click',()=>checkForUpdate(true));
  $('#apply-app-update')?.addEventListener('click',applyUpdate);
  updateUi();
 }
 if(state.route==='news'){
  document.querySelectorAll('[data-news-level]').forEach(btn=>btn.addEventListener('click',()=>{
   state.newsLevel=btn.dataset.newsLevel;
   draw();
   // Jeden Filterwechsel am Server prüfen; die Quellen selbst sind intervallgeschützt.
   refreshNewsFromServer(state.newsLevel);
  }));
  $('#news-search').addEventListener('input',event=>{state.newsQuery=event.target.value;updateNewsList();});
  $('#news-reload').addEventListener('click',()=>refreshNewsFromServer(state.newsLevel));
 }
 if(state.route==='vorort'){
  $('#local-search').addEventListener('input',event=>{state.localQuery=event.target.value;refreshLocal();});
  $('#local-filter').addEventListener('change',event=>{state.localFilter=event.target.value;refreshLocal();});
  refreshLocal();
 }
 if(state.route==='gremien'){
  document.querySelectorAll('[data-gremien-tab]').forEach(btn=>btn.addEventListener('click',()=>{state.gremienGroup=btn.dataset.gremienTab;draw();}));
  $('#gremien-search').addEventListener('input',e=>{state.gremienQuery=e.target.value;refreshGremien();});refreshGremien();
 }
 if(state.route==='personen'){
  $('#who-photo-toggle')?.addEventListener('click',()=>{setPortraitConsent(!mdlPhotoConsent);draw();});
  document.querySelectorAll('[data-people-tab]').forEach(btn=>btn.addEventListener('click',()=>{state.peopleGroup=btn.dataset.peopleTab;draw();}));
  $('#people-search').addEventListener('input',event=>{state.peopleQuery=event.target.value;refreshPeople();});refreshPeople();
 }
 if(state.route==='kontakte'){
  document.querySelectorAll('[data-contact-level]').forEach(btn=>btn.addEventListener('click',()=>{state.contactLevel=btn.dataset.contactLevel;draw();}));
  $('#contact-search').addEventListener('input',event=>{state.contactQuery=event.target.value;updateContactList();});
 }
 if(state.route==='wissen'){$('#resource-search').addEventListener('input',event=>{state.resourceQuery=event.target.value;updateResourceList();});}
 if(state.route==='wegweiser'){
  ['topic','level','town'].forEach(key=>$('#guide-'+key).addEventListener('change',e=>{state['guide'+key[0].toUpperCase()+key.slice(1)]=e.target.value;$('#guide-result').innerHTML=guideResult();}));
 }
 if(state.route==='einstieg'){
  document.querySelectorAll('[data-step]').forEach(input=>input.addEventListener('change',e=>{const values=introStatus();values[e.target.dataset.step]=e.target.checked;try{localStorage.setItem(LOCAL_KEY,JSON.stringify(values));}catch{}draw();}));
  $('#clear-steps').addEventListener('click',()=>{if(confirm('Deine Checkliste wirklich zurücksetzen?')){try{localStorage.removeItem(LOCAL_KEY);}catch{}draw();}});
 }
}
function updateNewsList(){const articles=sortedNews();$('#news-list').innerHTML=articles.length?articles.map(newsCard).join(''):'<div class="empty">Keine Meldungen gefunden.</div>';$('#news-result-count').textContent=`${articles.length} ${articles.length===1?'Meldung':'Meldungen'} · Neueste zuerst`; }
function updateContactList(){const contacts=state.data.contacts.filter(c=>(state.contactLevel==='all'||c.level===state.contactLevel)&&(`${c.name} ${c.role} ${c.organization}`.toLowerCase().includes(state.contactQuery.toLowerCase())));$('#contact-list').innerHTML=contacts.length?contacts.map(contactCard).join(''):'<div class="empty">Keine Kontakte gefunden.</div>';}
function updateResourceList(){const r=state.data.resources.filter(x=>`${x.title} ${x.description} ${x.category}`.toLowerCase().includes(state.resourceQuery.toLowerCase()));$('#resource-list').innerHTML=r.length?r.map(x=>`<article class="resource-card"><span class="badgel">${esc(x.category)}</span><h3>${esc(x.title)}</h3><p>${esc(x.description)}</p>${external(x.url,'Offizielle Website öffnen')}</article>`).join(''):'<div class="empty">Keine Links gefunden.</div>';}
async function dataFetch(path,fallBack){try{const res=await fetch(path,{cache:'no-cache'});if(!res.ok)throw new Error(`HTTP ${res.status}`);return await res.json()}catch(e){state.loadError=true;console.warn('FW Kompass Daten konnten nicht geladen werden',path,e);return fallBack;}}
// --- PWA-Installation und selbst gehosteter Update-Service v0.3 ---
// Es gibt keine Mitglieder-Accounts und keine Push-Überwachung. Die Prüfung erfolgt nur,
// wenn die App läuft (beim Start, Wiederöffnen, Onlinegehen und alle 15 Minuten).
let installPrompt=null;
let installedMode=window.matchMedia('(display-mode: standalone)').matches || navigator.standalone===true;
let registration=null;
let availableUpdate=null;
let checking=false;
let lastChecked='Noch nicht geprüft';
let updateMessage='';
let dismissForVersion=null;
const UPDATE_PERIOD_MS=15*60*1000;
const sameVersion=(a,b)=>String(a||'').trim()===String(b||'').trim();
function newerVersion(latest,current){
 const parse=s=>/^\d+\.\d+\.\d+$/.test(s)?s.split('.').map(Number):null;
 const a=parse(latest),b=parse(current);if(!a||!b)return false;
 for(let i=0;i<3;i++){if(a[i]>b[i])return true;if(a[i]<b[i])return false;}return false;
}
function updateUi(){
 const installButton=$('#install-app-btn');
 if(installButton){installButton.disabled=installedMode;installButton.textContent=installedMode?'Bereits installiert':'App installieren';}
 const install=$('#install-app-state');
 if(install)install.textContent=installedMode?'Die App läuft bereits im installierten Modus.':installPrompt?'Dein Browser bietet die direkte Installation an.':'Keine direkte Installationsabfrage verfügbar? Der Knopf zeigt Dir die manuellen Schritte.';
 const checker=$('#update-check-state');
 if(checker)checker.textContent=checking?'Suche nach Updates …':availableUpdate?(availableUpdate.version==='neu'?'Ein Browser-Update ist verfügbar.':`Version v${availableUpdate.version} ist verfügbar. ${availableUpdate.notes||''}`):updateMessage||`Installierte Webversion v${APP_VERSION} · ${lastChecked}`;
 const apply=$('#apply-app-update');
 if(apply)apply.hidden=!availableUpdate;
 const banner=$('#update-banner');
 if(banner){
  banner.hidden=!availableUpdate||dismissForVersion===availableUpdate.version;
  if(!banner.hidden)$('#update-banner-text').textContent=availableUpdate.version==='neu'?'Eine neue Browser-Version der App ist bereit.':`Version v${availableUpdate.version} ist bereit. Du kannst jetzt aktualisieren.`;
 }
}
function showInstallHelp(){
 const help=$('#install-app-help');
 if(help){help.hidden=false;help.scrollIntoView({block:'nearest',behavior:'smooth'});}
}
async function installApp(){
 if(installedMode){showInstallHelp();return;}
 if(!installPrompt){showInstallHelp();return;}
 const prompt=installPrompt;installPrompt=null;
 try{await prompt.prompt();await prompt.userChoice;}catch(e){console.warn('Installationsdialog nicht verfügbar',e);showInstallHelp();}
 updateUi();
}
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installPrompt=event;updateUi();});
window.addEventListener('appinstalled',()=>{track('install');installedMode=true;installPrompt=null;updateUi();});
function watchRegistration(reg){
 registration=reg;
 const inspect=()=>{
  if(reg.waiting && navigator.serviceWorker.controller){
   if(!availableUpdate)availableUpdate={version:'neu',notes:'Eine App-Aktualisierung wurde vom Browser geladen.'};
   updateUi();
  }
 };
 inspect();
 reg.addEventListener('updatefound',()=>{
  const worker=reg.installing;if(!worker)return;
  worker.addEventListener('statechange',()=>{if(worker.state==='installed')inspect();});
 });
}
let waitingForControlledUpdate=false;
if('serviceWorker' in navigator){
 navigator.serviceWorker.addEventListener('controllerchange',()=>{
  if(waitingForControlledUpdate){waitingForControlledUpdate=false;window.location.reload();}
 });
}
async function retrieveRelease(){
 for(const source of ['./api/version.php','./release.json']){
  try{
   const url=source+'?t='+Date.now();
   const response=await fetch(url,{cache:'no-store',headers:{'Accept':'application/json'}});
   if(!response.ok)continue;
   const obj=await response.json();
   if(/^\d+\.\d+\.\d+$/.test(String(obj.version||'')))return obj;
  }catch(e){/* PHP may be unavailable; static JSON still works. */}
 }
 throw new Error('Versionsdatei nicht erreichbar');
}
async function checkForUpdate(manual=false){
 if(checking)return;
 checking=true;if(manual)updateMessage='';updateUi();
 try{
  const release=await retrieveRelease();
  lastChecked=`Zuletzt geprüft: ${new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})}`;
  if(newerVersion(release.version,APP_VERSION)){
   availableUpdate={version:release.version,notes:typeof release.notes==='string'?release.notes.slice(0,180):''};
   updateMessage='Neue Version bereit';
   if(registration)await registration.update().catch(()=>{});
  } else {
   if(!availableUpdate||availableUpdate.version!=='neu')availableUpdate=null;
   updateMessage=`Du nutzt Version v${APP_VERSION}. Alles aktuell. ${lastChecked}`;
  }
 }catch(e){updateMessage=`Update-Prüfung nicht möglich (offline oder Versionsdatei nicht erreichbar). ${lastChecked}`;}
 finally{checking=false;updateUi();}
}
async function applyUpdate(){
 if(!availableUpdate)return;
 updateMessage='Update wird vorbereitet …';updateUi();
 try{
  if(registration){
   await registration.update();
   if(registration.waiting){
    waitingForControlledUpdate=true;
    registration.waiting.postMessage({type:'SKIP_WAITING'});
    // controllerchange triggers reload; avoid forced refresh before the worker is active.
    return;
   }
  }
  // Without a waiting worker the browser may need another start after the upload.
  // This reload uses a cache-busted URL so HTML is retrieved afresh.
  window.location.href='./index.html?updated='+Date.now()+window.location.hash;
 }catch(e){updateMessage='Aktualisierung fehlgeschlagen. Bitte erneut prüfen oder die Seite in Chrome neu laden.';updateUi();}
}
$('#update-banner-go')?.addEventListener('click',applyUpdate);
$('#update-banner-later')?.addEventListener('click',()=>{dismissForVersion=availableUpdate?.version||null;updateUi();});
function setupPwa(){
 if('serviceWorker' in navigator && location.protocol==='https:'){
  navigator.serviceWorker.register('./sw.js',{scope:'./',updateViaCache:'none'})
   .then(watchRegistration).catch(error=>console.warn('Service Worker konnte nicht registriert werden',error));
 }
 checkForUpdate();
 setInterval(()=>{if(!document.hidden)checkForUpdate();},UPDATE_PERIOD_MS);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)checkForUpdate();});
 window.addEventListener('online',()=>checkForUpdate());
}

async function init(){
 initMemorial();
 initWelcome();
 if(window.__FW_DATA__){state.data=window.__FW_DATA__;window.addEventListener('hashchange',()=>{draw();if(state.route==='news')refreshNewsFromServer(state.newsLevel);window.scrollTo(0,0);});draw();if(state.route==='news')refreshNewsFromServer(state.newsLevel);setupPwa();loadPublicNotices();return;}
 const [news,contacts,regions,resources]=await Promise.all([
  dataFetch('./api/news.php',{metadata:{},articles:[]}),
  dataFetch('./data/contacts.json',[]),dataFetch('./data/regions.json',{towns:[]}),dataFetch('./data/resources.json',[])
 ]);
 // Static hosts without PHP should use news.json. A PHP host returns JSON from api/news.php.
 let result=news;
 if(state.loadError||!Array.isArray(news.articles)){state.loadError=false;result=await dataFetch('./data/news.json',{metadata:{},articles:[]});}
 state.data={news:result,contacts,regions,resources};
 window.addEventListener('hashchange',()=>{draw();if(state.route==='news')refreshNewsFromServer(state.newsLevel);if(state.route==='statistik'||state.route==='mitteilungen'||state.route==='mdl'||state.route==='redaktion')loadStatSession();if(state.route==='mdl'||state.route==='redaktion')loadMdlPosts();window.scrollTo({top:0,behavior:'instant'});});
 draw();
 if(state.route==='news')refreshNewsFromServer(state.newsLevel);
 setupPwa();
 loadLegal();
 if(location.hash==='#statistik'||location.hash==='#mitteilungen'||location.hash==='#mdl'||location.hash==='#redaktion')loadStatSession();
 loadPublicNotices();
 loadMdlPosts();
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)loadPublicNotices();});
 setInterval(()=>{if(!document.hidden)loadPublicNotices();},5*60*1000);
}
init();

/* FW Kompass v0.4 – zeigt das unveränderte Original-Logo nur, wenn es unter assets/fw-logo-offiziell.png abgelegt ist. */
for(const logo of document.querySelectorAll('.fw-official-logo')){
 const show=()=>logo.parentElement?.classList.add('logo-ready');
 const hide=()=>logo.parentElement?.classList.remove('logo-ready');
 logo.addEventListener('load',show);logo.addEventListener('error',hide);
 if(logo.complete && logo.naturalWidth>0)show();
}
