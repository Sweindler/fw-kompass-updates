/* FW Kompass 1.1.0 – optional Web Push, no tracking. */
const API='./api/version.php?mode=push&action=';
const post=async(action,data)=>{
 const opts={method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)};
 const r=await fetch(API+action,opts);const j=await r.json();if(!r.ok)throw new Error(j.error||`HTTP ${r.status}`);return j;
};
const adminPost=async(action,data)=>{
 const r=await fetch(API+action,{method:'POST',credentials:'same-origin',cache:'no-store',body:new URLSearchParams(data)});
 const j=await r.json();if(!r.ok)throw new Error(j.error||`HTTP ${r.status}`);return j;
};
function base64Key(s){let b=s.replace(/-/g,'+').replace(/_/g,'/');while(b.length%4)b+='=';return Uint8Array.from(atob(b),x=>x.charCodeAt(0));}
const current=async()=>{if(!('serviceWorker' in navigator))return null;const reg=await navigator.serviceWorker.getRegistration('./');return reg?.pushManager?.getSubscription()||null;};
const text=(id,val)=>{const el=document.getElementById(id);if(el)el.textContent=val;};
function supported(){return window.isSecureContext&&'serviceWorker' in navigator&&'PushManager' in window&&'Notification' in window;}
export function pushPanel(){return `<section class="panel fw-push-panel"><h2>🔔 Push-Nachrichten auf deinem Smartphone</h2><p>Erhalte wichtige Hinweise auch bei geschlossener App. Die Anmeldung ist freiwillig und kann jederzeit rückgängig gemacht werden.</p>
 <div class="push-options"><label><input type="checkbox" id="push-opt-updates" checked/> App-Updates</label><label><input type="checkbox" id="push-opt-news"/> Wichtige Nachrichten</label><label><input type="checkbox" id="push-opt-events"/> Veranstaltungen</label></div>
 <div class="push-actions"><button id="push-enable" class="btn primary" type="button">Benachrichtigungen aktivieren</button><button id="push-disable" class="btn quiet" type="button">Benachrichtigungen abmelden</button></div>
 <p id="push-status" class="tiny" role="status">Push-Status wird geprüft …</p><p class="tiny">Zum Aktivieren muss dein Browser eine Berechtigung erteilen. Dabei wird ein verschlüsseltes Geräte-Abonnement auf dem FW-Kompass-Server gespeichert; der jeweilige Push-Anbieter (z. B. Google, Mozilla oder Apple) übernimmt die Zustellung. <a href="#rechtliches">Datenschutzhinweise</a>.</p></section>`;}
export function pushAdminPanel(){return `<section class="panel fw-push-admin"><h2>Push-Verwaltung (Administrator)</h2><p>Nur an Geräte, die das jeweilige Thema ausdrücklich abonniert haben. Keine personenbezogenen Verteiler.</p><p id="push-counts" class="tiny">Abonnements werden geladen …</p>
 <form id="push-admin-form" class="stat-form"><label>Art der Nachricht<select name="category"><option value="updates">App-Updates</option><option value="news">Wichtige Nachrichten</option><option value="events">Veranstaltung</option></select></label>
 <label>Überschrift<input name="title" required maxlength="90" placeholder="Neue Version verfügbar"></label><label>Nachricht<textarea name="body" required maxlength="230" rows="3" placeholder="Das hat sich geändert …"></textarea></label>
 <label>Ziel in der App<select name="link"><option value="#mitteilungen">Mitteilungen</option><option value="#news">Aktuelles</option><option value="#termine">Termine</option><option value="#start">Startseite</option></select></label>
 <div class="push-actions"><button type="button" class="btn quiet" id="push-test">Test an dieses Gerät</button><button type="submit" class="btn primary">An Abonnenten senden</button></div></form><p class="tiny" id="push-admin-status" role="status"></p><p class="tiny">Ein Testversand funktioniert nur, wenn dieses Gerät im aktuellen Browser Push abonniert hat. Eine erfolgreiche Annahme durch den Push-Dienst garantiert keine sofortige Anzeige auf dem Gerät.</p></section>`;}
function choices(){return ['updates','news','events'].filter(k=>document.getElementById('push-opt-'+k)?.checked);}
async function refreshStatus(){
 if(!document.getElementById('push-status'))return;
 if(!supported()){text('push-status','Push wird auf diesem Gerät/Browser nicht unterstützt. Auf iPhones muss die Web-App zum Home-Bildschirm hinzugefügt sein.');return;}
 const sub=await current();
 if(sub){text('push-status','Push auf diesem Gerät abonniert. Du kannst die Themenauswahl ändern und erneut speichern.');
  // Local topic preference only; database is authoritative for actual delivery.
  const saved=JSON.parse(localStorage.getItem('fw-push-topics-v1')||'null');if(Array.isArray(saved))for(const k of ['updates','news','events']){
   const input=document.getElementById('push-opt-'+k);if(input)input.checked=saved.includes(k);
  }
 }else{text('push-status',Notification.permission==='denied'?'Benachrichtigungen wurden im Browser blockiert. Erlaube sie in den Website-Einstellungen.':'Noch nicht angemeldet.');}
}
async function subscribe(){
 if(!supported())throw new Error('Push wird hier nicht unterstützt.');
 const cats=choices();if(!cats.length)throw new Error('Bitte mindestens ein Thema auswählen.');
 // Request permission synchronously from the actual button tap.
 const permissionPromise=Notification.permission==='granted'?Promise.resolve('granted'):Notification.requestPermission();
 text('push-status','Berechtigung und Geräteanmeldung werden geprüft …');
 const permission=await permissionPromise;
 if(permission!=='granted')throw new Error('Ohne Berechtigung keine Push-Nachrichten.');
 const response=await fetch(API+'config',{cache:'no-store',credentials:'same-origin'});
 const cfg=await response.json();if(!response.ok||!cfg.enabled)throw new Error('Der Push-Dienst ist derzeit nicht verfügbar.');
 const reg=await navigator.serviceWorker.ready;
 let sub=await reg.pushManager.getSubscription();let newly=false;
 if(!sub){sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:base64Key(cfg.publicKey)});newly=true;}
 try{
  await post('subscribe',{...sub.toJSON(),categories:cats});
  localStorage.setItem('fw-push-topics-v1',JSON.stringify(cats));
  text('push-status','Erfolgreich angemeldet! Du kannst jederzeit wieder abmelden.');
 }catch(e){if(newly)await sub.unsubscribe().catch(()=>{});throw e;}
}
async function unsubscribe(){
 const sub=await current();if(!sub){text('push-status','Auf diesem Gerät ist kein Push-Abonnement aktiv.');return;}
 await post('unsubscribe',{endpoint:sub.endpoint});
 await sub.unsubscribe();localStorage.removeItem('fw-push-topics-v1');
 text('push-status','Push-Abonnement wurde gelöscht.');
}
async function sendBatch(csrf,fields,only=''){
 const start=await adminPost('start',{...fields,csrf,only});
 if(!start.total){text('push-admin-status','Keine passenden Geräte für dieses Thema abonniert.');return;}
 let progress;
 do{
  progress=await adminPost('next',{csrf});
  text('push-admin-status',`Versand: ${progress.processed}/${progress.total} verarbeitet · ${progress.success} angenommen · ${progress.failed} fehlgeschlagen`);
 }while(!progress.done);
}
const fieldsFromForm=(form)=>({category:form.elements.category.value,title:form.elements.title.value,body:form.elements.body.value,link:form.elements.link.value});
export function wirePush(csrf=''){
 const enable=document.getElementById('push-enable');
 enable?.addEventListener('click',()=>{subscribe().catch(e=>text('push-status',e.message));});
 document.getElementById('push-disable')?.addEventListener('click',()=>{unsubscribe().catch(e=>text('push-status','Abmeldung fehlgeschlagen: '+e.message));});
 if(enable)refreshStatus().catch(()=>text('push-status','Status momentan nicht verfügbar.'));
 const adminForm=document.getElementById('push-admin-form');if(!adminForm||!csrf)return;
 fetch(API+'status',{credentials:'same-origin',cache:'no-store'}).then(r=>r.json()).then(d=>{
  if(!d.counts)throw new Error();text('push-counts',`Angemeldete Geräte: ${d.counts.total} · Updates: ${d.counts.updates} · Nachrichten: ${d.counts.news} · Termine: ${d.counts.events}`);
 }).catch(()=>text('push-counts','Abonnements derzeit nicht abrufbar.'));
 let running=false;
 async function send(test){
  if(running)return;running=true;
  const buttons=adminForm.querySelectorAll('button');buttons.forEach(b=>b.disabled=true);
  try{
   let only='';
   if(test){const sub=await current();if(!sub)throw new Error('Dieses Gerät hat noch kein Push-Abonnement.');
    const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(sub.endpoint));
    only=Array.from(new Uint8Array(digest)).map(b=>b.toString(16).padStart(2,'0')).join('');
   }else if(!confirm('Push-Nachricht an alle Geräte mit diesem Themenabo versenden?'))return;
   text('push-admin-status','Push-Versand beginnt …');
   await sendBatch(csrf,fieldsFromForm(adminForm),only);
  }catch(e){text('push-admin-status','Fehler: '+e.message);}finally{running=false;buttons.forEach(b=>b.disabled=false);}
 }
 adminForm.addEventListener('submit',e=>{e.preventDefault();send(false);});
 document.getElementById('push-test')?.addEventListener('click',()=>send(true));
}
