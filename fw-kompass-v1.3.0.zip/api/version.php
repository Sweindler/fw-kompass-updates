<?php
/** FW Kompass v1.3: freiwillige aggregierte Nutzungsstatistik, ohne Besucherprofile. */
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private, max-age=0');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'");
$root=dirname(__DIR__);
$private=$root.'/.fw-private';
$mode=(string)($_GET['mode']??'version');
function reply(int $code, array $obj):never {http_response_code($code);echo json_encode($obj,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
function privateDir(string $private):void {
 if(!is_dir($private)&&!@mkdir($private,0700,true))reply(503,['error'=>'Speicher nicht verfügbar']);
 if(!is_file($private.'/.htaccess'))reply(503,['error'=>'Privater Ordner noch nicht geschützt: Updater zuerst einrichten']);
}
function legalData(string $private):array {
 $path=$private.'/legal.json';$v=is_file($path)?json_decode((string)@file_get_contents($path),true):[];
 if(!is_array($v))$v=[];
 $fields=['operator_name','street','postal','city','email','phone','editor_name','editor_address','hosting_logs'];
 $r=[];foreach($fields as $f)$r[$f]=(string)($v[$f]??'');
 $r['configured']=$r['operator_name']!==''&&$r['street']!==''&&$r['postal']!==''&&$r['city']!==''&&filter_var($r['email'],FILTER_VALIDATE_EMAIL)!==false;
 return $r;
}
function sameOrigin():bool {
 $site=(string)($_SERVER['HTTP_SEC_FETCH_SITE']??'');
 if($site!==''&&!in_array($site,['same-origin','none'],true))return false;
 $origin=(string)($_SERVER['HTTP_ORIGIN']??'');
 if($origin!==''){
  $host=(string)($_SERVER['HTTP_HOST']??'');
  if(!hash_equals('https://'.$host,$origin))return false;
 }
 return true;
}
// Push integration 1.1.0. No third-party services besides the browser vendors' Web Push endpoints.
// No static secret keys in the release: VAPID keys are generated on the hosting server and kept under .fw-private.
function pushB64(string $s):string{return rtrim(strtr(base64_encode($s),'+/','-_'),'=');}
function pushUn64(string $s):string|false{
 if(!preg_match('~^[A-Za-z0-9_-]+$~D',$s)||strlen($s)>200)return false;
 return base64_decode(strtr($s,'-_','+/').str_repeat('=',(4-strlen($s)%4)%4),true);
}
function pushKeyDetails($pkey):array{
 $d=openssl_pkey_get_details($pkey);
 if(!is_array($d)||($d['ec']['curve_name']??'')!=='prime256v1')throw new RuntimeException('P-256 nicht verfügbar.');
 return ['pub'=>"\x04".$d['ec']['x'].$d['ec']['y'],'d'=>$d];
}
function pushKeys(string $private):array{
 privateDir($private);
 $p=$private.'/push-vapid.json';
 if(!is_file($p)){
  $lock=@fopen($private.'/push-key.lock','c');if(!$lock||!flock($lock,LOCK_EX))throw new RuntimeException('Schlüsseldatei gesperrt.');
  try{
   if(!is_file($p)){
    $k=openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1']);
    if(!$k||!openssl_pkey_export($k,$pem))throw new RuntimeException('VAPID-Schlüssel konnte nicht erzeugt werden.');
    $d=pushKeyDetails($k);
    $json=json_encode(['private_pem'=>$pem,'public'=>pushB64($d['pub'])],JSON_UNESCAPED_SLASHES);
    $tmp=tempnam($private,'vapid-');if($tmp===false||file_put_contents($tmp,$json,LOCK_EX)===false||!rename($tmp,$p))throw new RuntimeException('Schlüssel konnte nicht gespeichert werden.');
    @chmod($p,0600);
   }
  }finally{flock($lock,LOCK_UN);fclose($lock);}
 }
 $keys=json_decode((string)@file_get_contents($p),true);
 if(!is_array($keys)||empty($keys['private_pem'])||empty($keys['public']))throw new RuntimeException('VAPID-Konfiguration beschädigt.');
 return $keys;
}
function pushDb(string $private):PDO{
 privateDir($private);
 if(!extension_loaded('pdo_sqlite'))throw new RuntimeException('SQLite ist nicht aktiviert.');
 $pdo=new PDO('sqlite:'.$private.'/push-subs.sqlite',null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_TIMEOUT=>5]);
 $pdo->exec('PRAGMA busy_timeout=5000');
 $pdo->exec('CREATE TABLE IF NOT EXISTS subs (id TEXT PRIMARY KEY, endpoint TEXT NOT NULL, p256dh TEXT NOT NULL, auth TEXT NOT NULL, categories TEXT NOT NULL, created INTEGER NOT NULL, updated INTEGER NOT NULL)');
 // Privacy: inactive subscriptions are not retained indefinitely.
 $pdo->prepare('DELETE FROM subs WHERE updated < ?')->execute([time()-180*86400]);
 @chmod($private.'/push-subs.sqlite',0600);
 return $pdo;
}
function pushSameOrigin():bool{
 $site=(string)($_SERVER['HTTP_SEC_FETCH_SITE']??'');
 if($site!==''&&!in_array($site,['same-origin','none'],true))return false;
 $origin=(string)($_SERVER['HTTP_ORIGIN']??'');
 $host=(string)($_SERVER['HTTP_HOST']??'');
 return $origin===''||hash_equals('https://'.$host,$origin);
}
function pushEndpointAllowed(string $url):bool{
 if(strlen($url)>1800||!filter_var($url,FILTER_VALIDATE_URL))return false;
 $p=parse_url($url);if(!is_array($p)||strtolower((string)($p['scheme']??''))!=='https'||isset($p['user'])||isset($p['pass'])||isset($p['port']))return false;
 $host=strtolower((string)($p['host']??''));
 return in_array($host,['fcm.googleapis.com','updates.push.services.mozilla.com','web.push.apple.com'],true)||
  (str_ends_with($host,'.notify.windows.com')&&strlen($host)<80);
}
function pushBody():array{
 if((int)($_SERVER['CONTENT_LENGTH']??0)>5000)reply(413,['error'=>'Anfrage zu groß.']);
 $v=json_decode((string)file_get_contents('php://input'),true);
 if(!is_array($v))reply(400,['error'=>'Ungültige Anfrage.']);return $v;
}
function pushAllowedCategories(mixed $categories):array{
 if(!is_array($categories))return [];
 return array_values(array_intersect(['updates','news','events'],array_filter($categories,'is_string')));
}
function pushSubscribe(string $private,array $data):never{
 $endpoint=(string)($data['endpoint']??'');$p256=(string)($data['keys']['p256dh']??'');$auth=(string)($data['keys']['auth']??'');
 $rawP=pushUn64($p256);$rawA=pushUn64($auth);
 $categories=pushAllowedCategories($data['categories']??[]);
 if(!pushEndpointAllowed($endpoint)||$rawP===false||strlen($rawP)!==65||$rawP[0]!=="\x04"||$rawA===false||strlen($rawA)!==16||!$categories)reply(422,['error'=>'Ungültige Geräteanmeldung oder Themenauswahl.']);
 // Verify that the supplied EC point is valid, rather than trusting arbitrary subscription keys.
 if(!openssl_pkey_get_public(pushEcPublicPem($rawP)))reply(422,['error'=>'Ungültiger Verschlüsselungsschlüssel.']);
 $db=pushDb($private);$count=(int)$db->query('SELECT COUNT(*) FROM subs')->fetchColumn();if($count>=5000)reply(503,['error'=>'Maximale Zahl von Abonnements erreicht.']);
 $now=time();$id=hash('sha256',$endpoint);
 $stmt=$db->prepare('INSERT INTO subs (id,endpoint,p256dh,auth,categories,created,updated) VALUES (?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET p256dh=excluded.p256dh,auth=excluded.auth,categories=excluded.categories,updated=excluded.updated');
 $stmt->execute([$id,$endpoint,$p256,$auth,json_encode($categories),$now,$now]);
 reply(200,['ok'=>true,'subscribed'=>true,'categories'=>$categories]);
}
function pushEcPublicPem(string $raw):string{
 // ASN.1 SubjectPublicKeyInfo for uncompressed NIST P-256.
 $der=hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200').$raw;
 return "-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode($der),64,"\n")."-----END PUBLIC KEY-----\n";
}
function pushHkdfExtract(string $salt,string $secret):string{return hash_hmac('sha256',$secret,$salt,true);}
function pushHkdfExpand(string $prk,string $info,int $length):string{
 $out='';$prev='';$counter=1;
 while(strlen($out)<$length){$prev=hash_hmac('sha256',$prev.$info.chr($counter++),$prk,true);$out.=$prev;}
 return substr($out,0,$length);
}
function pushDerToJose(string $der):string{
 // OpenSSL returns DER-encoded ECDSA signature, VAPID/JWT requires 32-byte r || 32-byte s.
 $pos=0;$length=strlen($der);
 if($length<8||ord($der[$pos++])!==0x30)throw new RuntimeException('ECDSA-Signatur ungültig.');
 $seq=ord($der[$pos++]);if($seq&0x80){$num=$seq&0x7f;$seq=0;for($i=0;$i<$num;$i++)$seq=($seq<<8)|ord($der[$pos++]);}
 $vals=[];
 for($part=0;$part<2;$part++){
  if($pos>=$length||ord($der[$pos++])!==0x02)throw new RuntimeException('ECDSA-Signatur ungültig.');
  $n=ord($der[$pos++]);if($n&0x80){$lenBytes=$n&0x7f;$n=0;for($i=0;$i<$lenBytes;$i++)$n=($n<<8)|ord($der[$pos++]);}
  $chunk=substr($der,$pos,$n);$pos+=$n;$chunk=ltrim($chunk,"\x00");if(strlen($chunk)>32)throw new RuntimeException('ECDSA-Signatur zu lang.');
  $vals[]=str_pad($chunk,32,"\x00",STR_PAD_LEFT);
 }
 return implode('',$vals);
}
function pushPayload(string $p256,string $auth,string $message):string{
 $clientPub=pushUn64($p256);$authSecret=pushUn64($auth);
 if($clientPub===false||strlen($clientPub)!==65||$authSecret===false||strlen($authSecret)!==16)throw new RuntimeException('Push-Schlüssel ungültig.');
 $server=openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1']);
 if(!$server)throw new RuntimeException('ECDH nicht verfügbar.');
 $serverPub=pushKeyDetails($server)['pub'];
 $client=openssl_pkey_get_public(pushEcPublicPem($clientPub));
 if($client===false)throw new RuntimeException('Browser-Push-Schlüssel ungültig.');
 $secret=openssl_pkey_derive($client,$server,32);
 if(!is_string($secret)||strlen($secret)!==32)throw new RuntimeException('Schlüsselaustausch fehlgeschlagen.');
 $ikm=pushHkdfExpand(pushHkdfExtract($authSecret,$secret),"WebPush: info\x00".$clientPub.$serverPub,32);
 $salt=random_bytes(16);$prk=pushHkdfExtract($salt,$ikm);
 $cek=pushHkdfExpand($prk,"Content-Encoding: aes128gcm\x00",16);
 $nonce=pushHkdfExpand($prk,"Content-Encoding: nonce\x00",12);
 $cipher=openssl_encrypt($message."\x02",'aes-128-gcm',$cek,OPENSSL_RAW_DATA,$nonce,$tag,'',16);
 if($cipher===false)throw new RuntimeException('Verschlüsselung fehlgeschlagen.');
 return $salt.pack('N',4096).chr(65).$serverPub.$cipher.$tag;
}
function pushJwt(string $endpoint,array $keys):string{
 $p=parse_url($endpoint);$aud='https://'.$p['host'];
 $head=pushB64('{"typ":"JWT","alg":"ES256"}');
 $claims=pushB64(json_encode(['aud'=>$aud,'exp'=>time()+12*3600,'sub'=>'https://weindler.net/fw-kompass/'],JSON_UNESCAPED_SLASHES));
 $unsigned=$head.'.'.$claims;
 $private=openssl_pkey_get_private($keys['private_pem']);
 if(!$private||!openssl_sign($unsigned,$signature,$private,OPENSSL_ALGO_SHA256))throw new RuntimeException('VAPID-Signatur fehlgeschlagen.');
 return $unsigned.'.'.pushB64(pushDerToJose($signature));
}
function pushSend(array $sub,array $keys,array $payload):array{
 $endpoint=(string)$sub['endpoint'];if(!pushEndpointAllowed($endpoint))return ['ok'=>false,'status'=>0];
 $body=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
 if(!is_string($body)||strlen($body)>1500)return ['ok'=>false,'status'=>0];
 $encrypted=pushPayload((string)$sub['p256dh'],(string)$sub['auth'],$body);
 $jwt=pushJwt($endpoint,$keys);
 $ch=curl_init($endpoint);
 curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$encrypted,CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,
  CURLOPT_CONNECTTIMEOUT=>3,CURLOPT_TIMEOUT=>8,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,
  CURLOPT_HTTPHEADER=>['TTL: 3600','Content-Type: application/octet-stream','Content-Encoding: aes128gcm',
   'Authorization: vapid t='.$jwt.', k='.$keys['public'],'Urgency: normal'],
  CURLOPT_USERAGENT=>'FWKompassWebPush/1.1.0',CURLOPT_MAXREDIRS=>0]);
 if(defined('CURLOPT_PROTOCOLS')&&defined('CURLPROTO_HTTPS'))curl_setopt($ch,CURLOPT_PROTOCOLS,CURLPROTO_HTTPS);
 $response=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
 return ['ok'=>$response!==false&&$status>=200&&$status<300,'status'=>$status];
}
function pushAdminCount(PDO $db):array{
 $items=$db->query('SELECT categories FROM subs')->fetchAll();$counts=['total'=>count($items),'updates'=>0,'news'=>0,'events'=>0];
 foreach($items as $r){$cats=json_decode($r['categories'],true);foreach(pushAllowedCategories($cats) as $cat)$counts[$cat]++;}
 return $counts;
}
if($mode==='push'){
 header('Cache-Control: no-store, private, max-age=0');
 $action=(string)($_GET['action']??'');
 if($action==='config'&&$_SERVER['REQUEST_METHOD']==='GET'){
  try{$k=pushKeys($private);reply(200,['enabled'=>true,'publicKey'=>$k['public'],'topics'=>['updates','news','events']]);}
  catch(Throwable $ex){reply(503,['enabled'=>false,'error'=>'Push-Dienst ist noch nicht eingerichtet.']);}
 }
 if(in_array($action,['subscribe','unsubscribe'],true)){
  if($_SERVER['REQUEST_METHOD']!=='POST'||!pushSameOrigin())reply(403,['error'=>'Anfrage nicht erlaubt.']);
  $payload=pushBody();
  $endpoint=(string)($payload['endpoint']??'');
  if(!pushEndpointAllowed($endpoint))reply(422,['error'=>'Push-Endpunkt nicht zulässig.']);
  if($action==='subscribe')pushSubscribe($private,$payload);
  $db=pushDb($private);$db->prepare('DELETE FROM subs WHERE id = ?')->execute([hash('sha256',$endpoint)]);
  reply(200,['ok'=>true,'subscribed'=>false]);
 }
 // Protected admin actions reuse the existing statistics/notifications admin session.
 $https=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off')||(int)($_SERVER['SERVER_PORT']??0)===443;
 if(!$https)reply(403,['error'=>'HTTPS erforderlich.']);
 ini_set('session.use_strict_mode','1');session_name('FWKOMPASS_STATS');
 session_set_cookie_params(['lifetime'=>0,'path'=>'/fw-kompass/api/','secure'=>true,'httponly'=>true,'samesite'=>'Strict']);session_start();
 if(empty($_SESSION['stats_admin']))reply(401,['error'=>'Bitte zunächst im Mitteilungen-Bereich anmelden.']);
 if($action==='status'&&$_SERVER['REQUEST_METHOD']==='GET'){
  try{reply(200,['counts'=>pushAdminCount(pushDb($private))]);}catch(Throwable $e){reply(503,['error'=>'Speicher nicht verfügbar']);}
 }
 if(!pushSameOrigin()||$_SERVER['REQUEST_METHOD']!=='POST')reply(403,['error'=>'Anfrage nicht zulässig.']);
 if(!hash_equals((string)($_SESSION['csrf']??''),(string)($_POST['csrf']??'')))reply(403,['error'=>'Sicherheitsprüfung fehlgeschlagen.']);
 try{
  $db=pushDb($private);
  if($action==='start'){
   $title=trim((string)($_POST['title']??''));$body=trim((string)($_POST['body']??''));
   $cat=(string)($_POST['category']??'updates');$link=(string)($_POST['link']??'#mitteilungen');
   if($title===''||mb_strlen($title)>90||$body===''||mb_strlen($body)>230||!in_array($cat,['updates','news','events'],true)||!preg_match('/^#[a-z-]{2,32}$/D',$link))reply(422,['error'=>'Bitte Nachricht und Ziel prüfen.']);
   $only=(string)($_POST['only']??'');
   $ids=[];
   if($only!==''){
    if(!preg_match('/^[a-f0-9]{64}$/D',$only))reply(422,['error'=>'Testgerät ungültig.']);
    $get=$db->prepare('SELECT id,categories FROM subs WHERE id=?');$get->execute([$only]);$s=$get->fetch();
    if($s&&in_array($cat,pushAllowedCategories(json_decode($s['categories'],true)),true))$ids[]=$s['id'];
   }else{
    foreach($db->query('SELECT id,categories FROM subs ORDER BY created ASC')->fetchAll() as $s)
     if(in_array($cat,pushAllowedCategories(json_decode($s['categories'],true)),true))$ids[]=$s['id'];
   }
   $_SESSION['push_job']=['ids'=>$ids,'pos'=>0,'success'=>0,'failed'=>0,'title'=>$title,'body'=>$body,'category'=>$cat,'link'=>$link,'created'=>time()];
   reply(200,['ok'=>true,'total'=>count($ids)]);
  }
  if($action==='next'){
   $job=$_SESSION['push_job']??null;
   if(!is_array($job)||time()-(int)($job['created']??0)>900)reply(409,['error'=>'Versandauftrag abgelaufen oder fehlt.']);
   $batch=array_slice($job['ids'],$job['pos'],3);$keys=pushKeys($private);
   foreach($batch as $id){
    $query=$db->prepare('SELECT endpoint,p256dh,auth FROM subs WHERE id=?');$query->execute([$id]);$sub=$query->fetch();
    if(!$sub){$job['failed']++;continue;}
    $out=pushSend($sub,$keys,['title'=>$job['title'],'body'=>$job['body'],'category'=>$job['category'],'link'=>$job['link']]);
    if($out['ok'])$job['success']++;else{$job['failed']++;if(in_array($out['status'],[404,410],true))$db->prepare('DELETE FROM subs WHERE id=?')->execute([$id]);}
   }
   $job['pos']+=count($batch);$done=$job['pos']>=count($job['ids']);
   if($done)unset($_SESSION['push_job']);else $_SESSION['push_job']=$job;
   reply(200,['ok'=>true,'done'=>$done,'processed'=>$job['pos'],'total'=>count($job['ids']),'success'=>$job['success'],'failed'=>$job['failed']]);
  }
  reply(404,['error'=>'Unbekannte Push-Aktion']);
 }catch(Throwable $e){reply(503,['error'=>'Push-Versand konnte nicht abgeschlossen werden. Bitte Server-Einstellungen prüfen.']);}
}


// MdL Aktuell: Redaktion fügt ausschließlich Quellen-Links hinzu. Keine Instagram-Scraper.
function mdlPosts(string $private):array {
 $file=$private.'/mdl-posts.json';$list=is_file($file)?json_decode((string)@file_get_contents($file),true):[];
 if(!is_array($list))return [];
 return array_values(array_filter($list,static fn($x)=>is_array($x)&&isset($x['id'],$x['person'],$x['title'],$x['url'],$x['date'])));
}
function mdlSave(string $private,array $posts):void {
 privateDir($private);$t=tempnam($private,'mdl-');if($t===false)reply(503,['error'=>'Speicher nicht verfügbar']);
 $body=json_encode(array_values($posts),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
 if(!is_string($body)||@file_put_contents($t,$body,LOCK_EX)===false||!@rename($t,$private.'/mdl-posts.json')){ @unlink($t);reply(503,['error'=>'Beiträge konnten nicht gespeichert werden']); }
 @chmod($private.'/mdl-posts.json',0600);
}
if($mode==='mdl'){
 $action=(string)($_GET['action']??'');
 if($action===''&&$_SERVER['REQUEST_METHOD']==='GET'){
  $p=mdlPosts($private);usort($p,static fn($a,$b)=>strcmp((string)$b['date'],(string)$a['date']));
  reply(200,['posts'=>array_slice($p,0,80),'mode'=>'editorial-links','updatedAt'=>gmdate('Y-m-d')]);
 }
 if($_SERVER['REQUEST_METHOD']!=='POST'||!sameOrigin())reply(403,['error'=>'Unzulässige Anfrage']);
 $https=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off')||(int)($_SERVER['SERVER_PORT']??0)===443;
 if(!$https)reply(403,['error'=>'HTTPS erforderlich']);
 ini_set('session.use_strict_mode','1');session_name('FWKOMPASS_STATS');
 session_set_cookie_params(['lifetime'=>0,'path'=>'/fw-kompass/api/','secure'=>true,'httponly'=>true,'samesite'=>'Strict']);session_start();
 if(empty($_SESSION['stats_admin']))reply(401,['error'=>'Bitte über Mitteilungen als Administrator anmelden']);
 if(!hash_equals((string)($_SESSION['csrf']??''),(string)($_POST['csrf']??'')))reply(403,['error'=>'Sicherheitsprüfung fehlgeschlagen']);
 $posts=mdlPosts($private);
 if($action==='remove'){
  $id=(string)($_POST['id']??'');if(!preg_match('/^[a-f0-9]{16}$/D',$id))reply(422,['error'=>'Ungültige Kennung']);
  mdlSave($private,array_values(array_filter($posts,static fn($p)=>(string)$p['id']!==$id)));reply(200,['ok'=>true]);
 }
 if($action==='add'){
  if((int)($_SERVER['CONTENT_LENGTH']??0)>4500)reply(413,['error'=>'Eingabe zu groß']);
  $person=(string)($_POST['person']??'');$title=trim((string)($_POST['title']??''));$summary=trim((string)($_POST['summary']??''));
  $url=trim((string)($_POST['url']??''));$date=trim((string)($_POST['date']??''));
  if(!in_array($person,['zierer','lausch','saller'],true))reply(422,['error'=>'Unbekannte Person']);
  if($title===''||mb_strlen($title)>130||mb_strlen($summary)>400)reply(422,['error'=>'Titel oder Beschreibung zu lang']);
  if(!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$date)||DateTimeImmutable::createFromFormat('!Y-m-d',$date)?->format('Y-m-d')!==$date)reply(422,['error'=>'Ungültiges Datum']);
  $p=parse_url($url);$host=strtolower((string)($p['host']??''));$path=(string)($p['path']??'');
  if(!is_array($p)||($p['scheme']??'')!=='https'||isset($p['user'])||isset($p['pass'])||isset($p['port']))reply(422,['error'=>'Nur HTTPS-Quellen erlaubt']);
  $websites=['zierer'=>'benno-zierer.de','lausch'=>'josef-lausch.de','saller'=>'markus-saller.de'];
  $webHost=$websites[$person];
  $isWeb=in_array($host,[$webHost,'www.'.$webHost],true);
  $isIg=in_array($host,['www.instagram.com','instagram.com'],true)&&preg_match('~^/(?:p|reel|tv)/[A-Za-z0-9_-]{5,60}/?$~D',$path);
  if(!$isWeb&&!$isIg)reply(422,['error'=>'Bitte einen direkten Instagram-Post oder die Website dieser Person verlinken']);
  $url='https://'.$host.$path;
  if(strlen($url)>800)reply(422,['error'=>'Link zu lang']);
  if(count($posts)>=80)reply(422,['error'=>'Maximal 80 Beiträge, zuerst ältere entfernen']);
  foreach($posts as $item)if(($item['url']??'')===$url)reply(409,['error'=>'Dieser Beitrag ist bereits eingetragen']);
  array_unshift($posts,['id'=>bin2hex(random_bytes(8)),'person'=>$person,'title'=>$title,'summary'=>$summary,'url'=>$url,'date'=>$date]);
  mdlSave($private,$posts);reply(200,['ok'=>true,'count'=>count($posts)]);
 }
 reply(404,['error'=>'Aktion unbekannt']);
}

if($mode==='version'){
 $v=json_decode((string)@file_get_contents($root.'/release.json'),true);
 if(!is_array($v)||!preg_match('/^\d+\.\d+\.\d+$/D',(string)($v['version']??'')))reply(503,['error'=>'invalid-release']);
 reply(200,['version'=>$v['version'],'published'=>(string)($v['published']??''),'notes'=>(string)($v['notes']??'')]);
}
if($mode==='legal'){
 if($_SERVER['REQUEST_METHOD']!=='GET')reply(405,['error'=>'Nur GET']);
 reply(200,legalData($private));
}
function noticeList(string $private):array {
 $p=$private.'/notices.json';$d=is_file($p)?json_decode((string)@file_get_contents($p),true):[];
 if(!is_array($d))return [];
 return array_values(array_filter($d,fn($x)=>is_array($x)&&isset($x['id'],$x['title'],$x['text'],$x['type'],$x['published'])));
}
function publicNotices(string $private):array {
 $today=(new DateTimeImmutable('now',new DateTimeZone('Europe/Berlin')))->format('Y-m-d');
 return array_values(array_filter(noticeList($private),fn($v)=>(string)($v['expires']??'')===''||(string)($v['expires']??'')>=$today));
}
function writeNotices(string $private,array $items):void {
 privateDir($private);
 $tmp=tempnam($private,'notice-');
 if($tmp===false)reply(503,['error'=>'Speichern fehlgeschlagen']);
 $encoded=json_encode(array_values($items),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
 if(@file_put_contents($tmp,$encoded,LOCK_EX)===false||!@rename($tmp,$private.'/notices.json')){
  @unlink($tmp);reply(503,['error'=>'Mitteilung konnte nicht gespeichert werden']);
 }
 @chmod($private.'/notices.json',0600);
}
$action=(string)($_GET['action']??'');
if($mode==='notices' && $action==='' && $_SERVER['REQUEST_METHOD']==='GET'){
 $release=json_decode((string)@file_get_contents($root.'/release.json'),true);
 if(!is_array($release))$release=[];
 reply(200,['release'=>['version'=>(string)($release['version']??''),'notes'=>(string)($release['notes']??''),'published'=>(string)($release['published']??'')], 'notices'=>publicNotices($private)]);
}
if(!in_array($mode,['stats','notices'],true))reply(404,['error'=>'Unbekannte Anfrage']);
$allowedRoutes=['mitteilungen','start','wegweiser','vorort','news','kontakte','personen','gremien','termine','wissen','einstieg','info','rechtliches'];
$allowedExternal=['bund','bayern','erding','sonstige'];
if($mode==='stats' && $action==='event') {
 // Anonymes Ereignis nur nach bewusster Zustimmung im Browser (nicht serverseitig beweisbar).
 if($_SERVER['REQUEST_METHOD']!=='POST'||!sameOrigin())reply(403,['error'=>'Anfrage nicht zulässig']);
 if((int)($_SERVER['CONTENT_LENGTH']??0)>650)reply(413,['error'=>'Zu groß']);
 $type=(string)($_POST['type']??'');$category=(string)($_POST['category']??'');
 if(!in_array($type,['visit','section','external','download','install','content_view','content_seconds'],true))reply(422,['error'=>'Unbekanntes Ereignis']);
 if($type==='section'&&!in_array($category,$allowedRoutes,true))reply(422,['error'=>'Unbekannter Bereich']);
 if(in_array($type,['external','download'],true)&&!in_array($category,$allowedExternal,true))reply(422,['error'=>'Unbekannte Linkklasse']);
 $contentEvent=in_array($type,['content_view','content_seconds'],true);
 $item='';$title='';$value=0;
 if($contentEvent){
  if(!in_array($category,['news','mdl'],true))reply(422,['error'=>'Unbekannte Inhaltsart']);
  $item=(string)($_POST['item']??'');
  if(!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$/D',$item))reply(422,['error'=>'Ungültige Inhaltskennung']);
  $title=trim(preg_replace('/\s+/u',' ',strip_tags((string)($_POST['title']??'')))??'');
  if($title===''||(function_exists('mb_strlen')?mb_strlen($title):strlen($title))>140)reply(422,['error'=>'Ungültiger Titel']);
  if($type==='content_seconds'){
   $value=filter_var($_POST['value']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>5,'max_range'=>300]]);
   if($value===false||$value%5!==0)reply(422,['error'=>'Ungültige Zeitspanne']);
  }
 }elseif(!in_array($type,['section','external','download'],true))$category='';
 privateDir($private);
 $file=$private.'/stats-aggregate.json';$h=@fopen($file,'c+');if(!$h)reply(503,['error'=>'Statistik derzeit nicht verfügbar']);
 try {
  if(!flock($h,LOCK_EX))reply(503,['error'=>'Statistik gesperrt']);
  $data=json_decode((string)stream_get_contents($h),true);if(!is_array($data))$data=[];
  $today=(new DateTimeImmutable('now',new DateTimeZone('Europe/Berlin')))->format('Y-m-d');
  $min=(new DateTimeImmutable($today))->modify('-120 days')->format('Y-m-d');
  foreach(array_keys($data) as $day){if(!preg_match('/^\d{4}-\d{2}-\d{2}$/D',(string)$day)||$day<$min)unset($data[$day]);}
  if(!isset($data[$today]))$data[$today]=['visit'=>0,'section'=>[],'external'=>[],'download'=>[],'install'=>0];
  if($type==='visit'||$type==='install')$data[$today][$type]=(int)($data[$today][$type]??0)+1;
  elseif($type==='section'||$type==='external'||$type==='download')$data[$today][$type][$category]=(int)($data[$today][$type][$category]??0)+1;
  elseif($contentEvent){
   // Only publicly named content counts: no visitor tokens or navigation histories.
   $key=$category.':'.$item;
   if(!isset($data[$today]['content'][$key])){
    if(count($data[$today]['content']??[])>=250)reply(429,['error'=>'Tageslimit erreicht']);
    $data[$today]['content'][$key]=['kind'=>$category,'title'=>$title,'views'=>0,'seconds'=>0];
   }
   $data[$today]['content'][$key][$type==='content_view'?'views':'seconds']+=$type==='content_view'?1:$value;
  }
  if($type==='visit'){
   // Hour aggregates only: no timestamps or user identifiers are persisted.
   $hour=(new DateTimeImmutable('now',new DateTimeZone('Europe/Berlin')))->format('H');
   $data[$today]['hours'][$hour]=(int)($data[$today]['hours'][$hour]??0)+1;
  }
  rewind($h);ftruncate($h,0);fwrite($h,json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));fflush($h);
  flock($h,LOCK_UN);
  reply(200,['ok'=>true]);
 }finally{fclose($h);}
}
// Separate Admin-Session nur für die Statistik/Impressum-Verwaltung.
$https=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off')||(int)($_SERVER['SERVER_PORT']??0)===443;
if(!$https)reply(403,['error'=>'Nur HTTPS']);
ini_set('session.use_strict_mode','1');
session_name('FWKOMPASS_STATS');
session_set_cookie_params(['lifetime'=>0,'path'=>'/fw-kompass/api/','secure'=>true,'httponly'=>true,'samesite'=>'Strict']);
session_start();
if(!isset($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));
if($mode==='notices' && $action==='admin'){
 if($_SERVER['REQUEST_METHOD']!=='GET'||empty($_SESSION['stats_admin']))reply(401,['error'=>'Bitte anmelden']);
 reply(200,['notices'=>noticeList($private)]);
}
if($action==='status')reply(200,['authenticated'=>!empty($_SESSION['stats_admin']),'csrf'=>$_SESSION['csrf']]);
if(!sameOrigin())reply(403,['error'=>'Unzulässige Herkunft']);
if($_SERVER['REQUEST_METHOD']!=='POST')reply(405,['error'=>'Nur POST']);
if(!hash_equals((string)$_SESSION['csrf'],(string)($_POST['csrf']??'')))reply(403,['error'=>'Sicherheitsprüfung fehlgeschlagen']);
if($action==='login'){
 privateDir($private);$conf=$private.'/config.php';
 if(!is_file($conf))reply(503,['error'=>'Bitte Admin-Updater einrichten']);
 if(!defined('FW_ADMIN'))define('FW_ADMIN',true);
 $cfg=require $conf;
 if(!is_array($cfg)||!isset($cfg['password_hash']))reply(503,['error'=>'Admin-Konfiguration fehlt']);
 // Kein IP-Logging im Statistiksystem; zeitweises Sitzungs-Limit für Fehlversuche.
 if((int)($_SESSION['bad_count']??0)>=6)reply(429,['error'=>'Zu viele Versuche. Bitte Browser neu starten.']);
 if(!password_verify((string)($_POST['password']??''),(string)$cfg['password_hash'])){
  $_SESSION['bad_count']=(int)($_SESSION['bad_count']??0)+1;reply(401,['error'=>'Passwort falsch']);
 }
 session_regenerate_id(true);$_SESSION['stats_admin']=true;$_SESSION['bad_count']=0;
 reply(200,['ok'=>true,'csrf'=>$_SESSION['csrf']]);
}
if($action==='logout'){$_SESSION['stats_admin']=false;reply(200,['ok'=>true]);}
if(empty($_SESSION['stats_admin']))reply(401,['error'=>'Bitte anmelden']);
if($mode==='notices'){
 if((int)($_SERVER['CONTENT_LENGTH']??0)>4096)reply(413,['error'=>'Eingabe zu groß']);
 privateDir($private);
 $items=noticeList($private);
 if($action==='add'){
  $title=trim((string)($_POST['title']??''));$body=trim((string)($_POST['text']??''));
  $type=(string)($_POST['type']??'');$link=trim((string)($_POST['link']??''));$expires=(string)($_POST['expires']??'');
  if($title===''||strlen($title)>240||$body===''||strlen($body)>2000)reply(422,['error'=>'Überschrift oder Text ungültig (max. 120/1200 Zeichen)']);
  if(!in_array($type,['hinweis','update','termin'],true))reply(422,['error'=>'Ungültiger Typ']);
  if($link!==''&&!preg_match('~^https://[^\s<>"\']+$|^#[a-z-]+$~D',$link))reply(422,['error'=>'Nur HTTPS- oder interne App-Links erlaubt']);
  if($expires!==''&&(!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$expires)||DateTimeImmutable::createFromFormat('!Y-m-d',$expires)?->format('Y-m-d')!==$expires))reply(422,['error'=>'Ungültiges Ablaufdatum']);
  if(count($items)>=40)reply(422,['error'=>'Maximal 40 Mitteilungen. Alte Einträge bitte zuerst löschen.']);
  $today=(new DateTimeImmutable('now',new DateTimeZone('Europe/Berlin')))->format('Y-m-d');
  array_unshift($items,['id'=>bin2hex(random_bytes(8)),'title'=>$title,'text'=>$body,'type'=>$type,'link'=>$link,'published'=>$today,'expires'=>$expires]);
  writeNotices($private,$items);reply(200,['ok'=>true]);
 }
 if($action==='remove'){
  $id=(string)($_POST['id']??'');if(!preg_match('/^[a-f0-9]{16}$/D',$id))reply(422,['error'=>'Ungültige Kennung']);
  writeNotices($private,array_values(array_filter($items,fn($x)=>(string)$x['id']!==$id)));reply(200,['ok'=>true]);
 }
 reply(404,['error'=>'Unbekannte Aktion']);
}

if($action==='read'){
 $data=json_decode((string)@file_get_contents($private.'/stats-aggregate.json'),true);if(!is_array($data))$data=[];
 ksort($data);reply(200,['days'=>$data,'legal'=>legalData($private),'retention_days'=>120]);
}
if($action==='save_legal'){
 $names=['operator_name','street','postal','city','email','phone','editor_name','editor_address','hosting_logs'];$d=[];
 foreach($names as $name){$value=trim((string)($_POST[$name]??''));if(strlen($value)>1000)reply(422,['error'=>'Angabe ist zu lang: '.$name]);$d[$name]=$value;}
 foreach(['operator_name','street','postal','city','email'] as $required)if($d[$required]==='')reply(422,['error'=>'Bitte Pflichtangabe ergänzen: '.$required]);
 if(filter_var($d['email'],FILTER_VALIDATE_EMAIL)===false)reply(422,['error'=>'Ungültige E-Mail']);
 $data=json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
 privateDir($private);$tmp=tempnam($private,'legal-');
 if($tmp===false||file_put_contents($tmp,$data,LOCK_EX)===false||!rename($tmp,$private.'/legal.json'))reply(503,['error'=>'Angaben konnten nicht gespeichert werden']);
 @chmod($private.'/legal.json',0600);reply(200,['ok'=>true,'legal'=>legalData($private)]);
}
reply(404,['error'=>'Aktion unbekannt']);
