<?php
/** FW Kompass v1.0: Versionsauskunft, freiwillige aggregierte Statistik & Pflichtangaben. */
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private, max-age=0');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'");
$root=dirname(__DIR__);
$private=$root.'/.fw-private';
$mode=(string)($_GET['mode']??'version');
function reply(int $code, array $obj):never {http_response_code($code);echo json_encode($obj,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
function privateDir(string $private):void {
 if(!is_dir($private)&&!@mkdir($private,0700,true))reply(503,['error'=>'Speicher nicht verfügbar']);
 if(!is_file($private.'/.htaccess'))reply(503,['error'=>'Privater Ordner noch nicht geschützt: Updater zuerst einrichten']);
}
function legalData(string $private):array {
 $path=$private.'/legal.json';$v=is_file($path)?json_decode((string)@file_get_contents($path),true):[];
 if(!is_array($v))$v=[];
 $fields=['operator_name','street','postal','city','email','phone','editor_name','editor_address','hosting_logs'];
 $r=[];foreach($fields as $f)$r[$f]=(string)($v[$f]??'');
 $r['configured']=$r['operator_name']!==''&&$r['street']!==''&&$r['postal']!==''&&$r['city']!==''&&filter_var($r['email'],FILTER_VALIDATE_EMAIL)!==false;
 return $r;
}
function sameOrigin():bool {
 $site=(string)($_SERVER['HTTP_SEC_FETCH_SITE']??'');
 if($site!==''&&!in_array($site,['same-origin','none'],true))return false;
 $origin=(string)($_SERVER['HTTP_ORIGIN']??'');
 if($origin!==''){
  $host=(string)($_SERVER['HTTP_HOST']??'');
  if(!hash_equals('https://'.$host,$origin))return false;
 }
 return true;
}
if($mode==='version'){
 $v=json_decode((string)@file_get_contents($root.'/release.json'),true);
 if(!is_array($v)||!preg_match('/^\d+\.\d+\.\d+$/D',(string)($v['version']??'')))reply(503,['error'=>'invalid-release']);
 reply(200,['version'=>$v['version'],'published'=>(string)($v['published']??''),'notes'=>(string)($v['notes']??'')]);
}
if($mode==='legal'){
 if($_SERVER['REQUEST_METHOD']!=='GET')reply(405,['error'=>'Nur GET']);
 reply(200,legalData($private));
}
function noticeList(string $private):array {
 $p=$private.'/notices.json';$d=is_file($p)?json_decode((string)@file_get_contents($p),true):[];
 if(!is_array($d))return [];
 return array_values(array_filter($d,fn($x)=>is_array($x)&&isset($x['id'],$x['title'],$x['text'],$x['type'],$x['published'])));
}
function publicNotices(string $private):array {
 $today=(new DateTimeImmutable('now',new DateTimeZone('Europe/Berlin')))->format('Y-m-d');
 return array_values(array_filter(noticeList($private),fn($v)=>(string)($v['expires']??'')===''||(string)($v['expires']??'')>=$today));
}
function writeNotices(string $private,array $items):void {
 privateDir($private);
 $tmp=tempnam($private,'notice-');
 if($tmp===false)reply(503,['error'=>'Speichern fehlgeschlagen']);
 $encoded=json_encode(array_values($items),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
 if(@file_put_contents($tmp,$encoded,LOCK_EX)===false||!@rename($tmp,$private.'/notices.json')){
  @unlink($tmp);reply(503,['error'=>'Mitteilung konnte nicht gespeichert werden']);
 }
 @chmod($private.'/notices.json',0600);
}
$action=(string)($_GET['action']??'');
if($mode==='notices' && $action==='' && $_SERVER['REQUEST_METHOD']==='GET'){
 $release=json_decode((string)@file_get_contents($root.'/release.json'),true);
 if(!is_array($release))$release=[];
 reply(200,['release'=>['version'=>(string)($release['version']??''),'notes'=>(string)($release['notes']??''),'published'=>(string)($release['published']??'')], 'notices'=>publicNotices($private)]);
}
if(!in_array($mode,['stats','notices'],true))reply(404,['error'=>'Unbekannte Anfrage']);
$allowedRoutes=['mitteilungen','start','wegweiser','vorort','news','kontakte','personen','gremien','termine','wissen','einstieg','info','rechtliches'];
$allowedExternal=['bund','bayern','erding','sonstige'];
if($mode==='stats' && $action==='event') {
 // Anonymes Ereignis nur nach bewusster Zustimmung im Browser (nicht serverseitig beweisbar).
 if($_SERVER['REQUEST_METHOD']!=='POST'||!sameOrigin())reply(403,['error'=>'Anfrage nicht zulässig']);
 if((int)($_SERVER['CONTENT_LENGTH']??0)>256)reply(413,['error'=>'Zu groß']);
 $type=(string)($_POST['type']??'');$category=(string)($_POST['category']??'');
 if(!in_array($type,['visit','section','external','download','install'],true))reply(422,['error'=>'Unbekanntes Ereignis']);
 if($type==='section'&&!in_array($category,$allowedRoutes,true))reply(422,['error'=>'Unbekannter Bereich']);
 if(in_array($type,['external','download'],true)&&!in_array($category,$allowedExternal,true))reply(422,['error'=>'Unbekannte Linkklasse']);
 if(!in_array($type,['section','external','download'],true))$category='';
 privateDir($private);
 $file=$private.'/stats-aggregate.json';$h=@fopen($file,'c+');if(!$h)reply(503,['error'=>'Statistik derzeit nicht verfügbar']);
 try {
  if(!flock($h,LOCK_EX))reply(503,['error'=>'Statistik gesperrt']);
  $data=json_decode((string)stream_get_contents($h),true);if(!is_array($data))$data=[];
  $today=(new DateTimeImmutable('now',new DateTimeZone('Europe/Berlin')))->format('Y-m-d');
  $min=(new DateTimeImmutable($today))->modify('-120 days')->format('Y-m-d');
  foreach(array_keys($data) as $day){if(!preg_match('/^\d{4}-\d{2}-\d{2}$/D',(string)$day)||$day<$min)unset($data[$day]);}
  if(!isset($data[$today]))$data[$today]=['visit'=>0,'section'=>[],'external'=>[],'download'=>[],'install'=>0];
  if(in_array($type,['visit','install'],true))$data[$today][$type]=(int)($data[$today][$type]??0)+1;
  else $data[$today][$type][$category]=(int)($data[$today][$type][$category]??0)+1;
  rewind($h);ftruncate($h,0);fwrite($h,json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));fflush($h);
  flock($h,LOCK_UN);
  reply(200,['ok'=>true]);
 }finally{fclose($h);}
}
// Separate Admin-Session nur für die Statistik/Impressum-Verwaltung.
$https=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off')||(int)($_SERVER['SERVER_PORT']??0)===443;
if(!$https)reply(403,['error'=>'Nur HTTPS']);
ini_set('session.use_strict_mode','1');
session_name('FWKOMPASS_STATS');
session_set_cookie_params(['lifetime'=>0,'path'=>'/fw-kompass/api/','secure'=>true,'httponly'=>true,'samesite'=>'Strict']);
session_start();
if(!isset($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));
if($mode==='notices' && $action==='admin'){
 if($_SERVER['REQUEST_METHOD']!=='GET'||empty($_SESSION['stats_admin']))reply(401,['error'=>'Bitte anmelden']);
 reply(200,['notices'=>noticeList($private)]);
}
if($action==='status')reply(200,['authenticated'=>!empty($_SESSION['stats_admin']),'csrf'=>$_SESSION['csrf']]);
if(!sameOrigin())reply(403,['error'=>'Unzulässige Herkunft']);
if($_SERVER['REQUEST_METHOD']!=='POST')reply(405,['error'=>'Nur POST']);
if(!hash_equals((string)$_SESSION['csrf'],(string)($_POST['csrf']??'')))reply(403,['error'=>'Sicherheitsprüfung fehlgeschlagen']);
if($action==='login'){
 privateDir($private);$conf=$private.'/config.php';
 if(!is_file($conf))reply(503,['error'=>'Bitte Admin-Updater einrichten']);
 if(!defined('FW_ADMIN'))define('FW_ADMIN',true);
 $cfg=require $conf;
 if(!is_array($cfg)||!isset($cfg['password_hash']))reply(503,['error'=>'Admin-Konfiguration fehlt']);
 // Kein IP-Logging im Statistiksystem; zeitweises Sitzungs-Limit für Fehlversuche.
 if((int)($_SESSION['bad_count']??0)>=6)reply(429,['error'=>'Zu viele Versuche. Bitte Browser neu starten.']);
 if(!password_verify((string)($_POST['password']??''),(string)$cfg['password_hash'])){
  $_SESSION['bad_count']=(int)($_SESSION['bad_count']??0)+1;reply(401,['error'=>'Passwort falsch']);
 }
 session_regenerate_id(true);$_SESSION['stats_admin']=true;$_SESSION['bad_count']=0;
 reply(200,['ok'=>true,'csrf'=>$_SESSION['csrf']]);
}
if($action==='logout'){$_SESSION['stats_admin']=false;reply(200,['ok'=>true]);}
if(empty($_SESSION['stats_admin']))reply(401,['error'=>'Bitte anmelden']);
if($mode==='notices'){
 if((int)($_SERVER['CONTENT_LENGTH']??0)>4096)reply(413,['error'=>'Eingabe zu groß']);
 privateDir($private);
 $items=noticeList($private);
 if($action==='add'){
  $title=trim((string)($_POST['title']??''));$body=trim((string)($_POST['text']??''));
  $type=(string)($_POST['type']??'');$link=trim((string)($_POST['link']??''));$expires=(string)($_POST['expires']??'');
  if($title===''||strlen($title)>240||$body===''||strlen($body)>2000)reply(422,['error'=>'Überschrift oder Text ungültig (max. 120/1200 Zeichen)']);
  if(!in_array($type,['hinweis','update','termin'],true))reply(422,['error'=>'Ungültiger Typ']);
  if($link!==''&&!preg_match('~^https://[^\s<>"\']+$|^#[a-z-]+$~D',$link))reply(422,['error'=>'Nur HTTPS- oder interne App-Links erlaubt']);
  if($expires!==''&&(!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$expires)||DateTimeImmutable::createFromFormat('!Y-m-d',$expires)?->format('Y-m-d')!==$expires))reply(422,['error'=>'Ungültiges Ablaufdatum']);
  if(count($items)>=40)reply(422,['error'=>'Maximal 40 Mitteilungen. Alte Einträge bitte zuerst löschen.']);
  $today=(new DateTimeImmutable('now',new DateTimeZone('Europe/Berlin')))->format('Y-m-d');
  array_unshift($items,['id'=>bin2hex(random_bytes(8)),'title'=>$title,'text'=>$body,'type'=>$type,'link'=>$link,'published'=>$today,'expires'=>$expires]);
  writeNotices($private,$items);reply(200,['ok'=>true]);
 }
 if($action==='remove'){
  $id=(string)($_POST['id']??'');if(!preg_match('/^[a-f0-9]{16}$/D',$id))reply(422,['error'=>'Ungültige Kennung']);
  writeNotices($private,array_values(array_filter($items,fn($x)=>(string)$x['id']!==$id)));reply(200,['ok'=>true]);
 }
 reply(404,['error'=>'Unbekannte Aktion']);
}

if($action==='read'){
 $data=json_decode((string)@file_get_contents($private.'/stats-aggregate.json'),true);if(!is_array($data))$data=[];
 ksort($data);reply(200,['days'=>$data,'legal'=>legalData($private),'retention_days'=>120]);
}
if($action==='save_legal'){
 $names=['operator_name','street','postal','city','email','phone','editor_name','editor_address','hosting_logs'];$d=[];
 foreach($names as $name){$value=trim((string)($_POST[$name]??''));if(strlen($value)>1000)reply(422,['error'=>'Angabe ist zu lang: '.$name]);$d[$name]=$value;}
 foreach(['operator_name','street','postal','city','email'] as $required)if($d[$required]==='')reply(422,['error'=>'Bitte Pflichtangabe ergänzen: '.$required]);
 if(filter_var($d['email'],FILTER_VALIDATE_EMAIL)===false)reply(422,['error'=>'Ungültige E-Mail']);
 $data=json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
 privateDir($private);$tmp=tempnam($private,'legal-');
 if($tmp===false||file_put_contents($tmp,$data,LOCK_EX)===false||!rename($tmp,$private.'/legal.json'))reply(503,['error'=>'Angaben konnten nicht gespeichert werden']);
 @chmod($private.'/legal.json',0600);reply(200,['ok'=>true,'legal'=>legalData($private)]);
}
reply(404,['error'=>'Aktion unbekannt']);
