/* FW Kompass: geprüfte Organisationsgliederungen, Stand 08.11.2026. Keine erfundenen Ortsvereinigungen. */
export default {
  "updated": "2026-11-08",
  "sources": {
    "kreis": "https://www.fw-landkreis-erding.de/aktuelles",
    "bezirk": "https://www.fw-oberbayern.de/vorstand",
    "land": "https://www.fw-bayern.de/unser-landesverband/landesvorstand",
    "bund_vereinigung": "https://www.freiewaehler.eu/bund/vorstand/",
    "bund_verband": "https://www.bpb.de/kurz-knapp/lexika/handwoerterbuch-politisches-system/202024/freie-waehler/"
  },
  "county": [
    {
      "name": "Rainer Mehringer",
      "role": "1. Vorsitzender",
      "url": "https://www.fw-landkreis-erding.de/freie-waehlerschaft/rainer-mehringer-1-vorsitzender",
      "image": "https://www.fw-landkreis-erding.de/fileadmin/_processed_/7/2/csm_2_Rainer_Mehringer_e3481ce347.jpg",
      "imageSource": "FW-Kreisportal Erding",
      "assignment": "both"
    },
    {
      "name": "Benedikt Hoigt",
      "role": "2. Vorsitzender",
      "url": "https://www.fw-landkreis-erding.de/freie-waehlerschaft/benedikt-hoigt-2-vorsitzender",
      "image": "https://www.fw-landkreis-erding.de/fileadmin/_processed_/2/c/csm_benedikt_hoigt_f347f101d1.jpg",
      "imageSource": "FW-Kreisportal Erding",
      "assignment": "both"
    },
    {
      "name": "Christian Büchlmann",
      "role": "Schatzmeister",
      "url": "https://www.fw-landkreis-erding.de/freie-waehlerschaft/christian-buechlmann-kassierer",
      "image": "https://www.fw-landkreis-erding.de/fileadmin/_processed_/e/f/csm_Christian-B%C3%BCchlmann_af6aec94df.jpg",
      "imageSource": "FW-Kreisportal Erding",
      "assignment": "both"
    },
    {
      "name": "Klaus Hamal",
      "role": "Kreisgeschäftsführer",
      "url": "https://www.fw-landkreis-erding.de/freie-waehlerschaft/klaus-hamal-geschaeftsfuehrer",
      "image": "https://www.fw-landkreis-erding.de/fileadmin/_processed_/b/0/csm_2025-Klaus-Hamal_15d92cdec9.jpg",
      "imageSource": "FW-Kreisportal Erding",
      "assignment": "both"
    },
    {
      "name": "Ursula Angenend",
      "role": "Beisitzerin",
      "url": "https://www.fw-landkreis-erding.de/freie-waehlerschaft/beisitzer/ursula-angenend",
      "image": "https://www.fw-landkreis-erding.de/fileadmin/_processed_/1/0/csm_Angenend_Ursula_eab0e7ebc5.jpg",
      "imageSource": "FW-Kreisportal Erding",
      "assignment": "verband"
    },
    {
      "name": "Monika Schmid",
      "role": "Beisitzerin",
      "url": "https://www.fw-landkreis-erding.de/freie-waehlerschaft/beisitzer/monika-schmid",
      "image": "https://www.fw-landkreis-erding.de/fileadmin/_processed_/d/1/csm_Monika-Schmid_829d19e09e.jpg",
      "imageSource": "FW-Kreisportal Erding",
      "assignment": "verband"
    },
    {
      "name": "Georg Els jun.",
      "role": "Beisitzer",
      "url": "https://www.fw-landkreis-erding.de/aktuelles",
      "assignment": "verband"
    },
    {
      "name": "Stephan Weindler",
      "role": "Beisitzer",
      "url": "https://www.fw-landkreis-erding.de/freie-waehlerschaft/beisitzer/stephan-weindler",
      "image": "https://www.fw-landkreis-erding.de/fileadmin/_processed_/c/4/csm_49_Weindler_Stephan_1ccd553add.jpg",
      "imageSource": "FW-Kreisportal Erding",
      "assignment": "verband"
    },
    {
      "name": "Christian Nagler",
      "role": "Beisitzer",
      "url": "https://www.fw-landkreis-erding.de/aktuelles",
      "assignment": "verband"
    },
    {
      "name": "Dr. Christian Aigner",
      "role": "Beisitzer",
      "url": "https://www.fw-landkreis-erding.de/aktuelles",
      "assignment": "verband"
    },
    {
      "name": "Florian Czech",
      "role": "Beisitzer",
      "url": "https://www.fw-landkreis-erding.de/freie-waehlerschaft/beisitzer/florian-czech",
      "image": "https://www.fw-landkreis-erding.de/fileadmin/_processed_/3/b/csm_Florian-Czech_7fc558654b.jpg",
      "imageSource": "FW-Kreisportal Erding",
      "assignment": "verband"
    },
    {
      "name": "Katharinna Brunnauer",
      "role": "Kassenprüferin",
      "url": "https://www.fw-landkreis-erding.de/aktuelles",
      "assignment": "verband"
    },
    {
      "name": "Elisabeth Rackl",
      "role": "Kassenprüferin",
      "url": "https://www.fw-landkreis-erding.de/aktuelles",
      "assignment": "verband"
    }
  ],
  "district": [
    {
      "name": "Florian Streibl",
      "role": "Bezirksvorsitzender",
      "url": "https://www.fw-oberbayern.de/vorstand/florian-streibl-bezirksvorsitzender",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/a/8/csm_Streibl_Florian_c1f776b0f7.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "gemeinsam"
    },
    {
      "name": "Anton Speer",
      "role": "Stellv. Bezirksvorsitzender",
      "url": "https://www.fw-oberbayern.de/vorstand/anton-speer-stellv-vorsitzender",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/6/6/csm_Foto_Speer_aktuell_20200423_d88a22bafd.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "gemeinsam"
    },
    {
      "name": "Michael Koller",
      "role": "Stellv. Bezirksvorsitzender",
      "url": "https://www.fw-oberbayern.de/vorstand/michael-koller-stellv-vorsitzender",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/4/6/csm_Koller_Michael_28565db45b.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "gemeinsam"
    },
    {
      "name": "Rainer Schneider",
      "role": "Stellv. Bezirksvorsitzender",
      "url": "https://www.fw-oberbayern.de/vorstand/rainer-schneider-stellv-vorsitzender",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/2/3/csm_Schneider_Rainer_153cda92df.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "gemeinsam"
    },
    {
      "name": "Anton Haunsberger",
      "role": "Stellv. Vorsitzender Bezirksvereinigung",
      "url": "https://www.fw-oberbayern.de/vorstand/anton-haunsberger-stellv-vorsitzender-bezirksvereinigung",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/e/3/csm_Haunsberger_Anton_1c7f6a245f.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "vereinigung"
    },
    {
      "name": "Jürgen Haindl",
      "role": "Stellv. Vorsitzender Bezirksverband",
      "url": "https://www.fw-oberbayern.de/vorstand/juergen-haindl-stellv-vorsitzender-bezirksverband",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/f/4/csm_Haindl_J%C3%BCrgen_f7ea08c5c9.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "verband"
    },
    {
      "name": "Florian Lichtenstern",
      "role": "Vorsitzender Junge FREIE WÄHLER Oberbayern",
      "url": "https://www.fw-oberbayern.de/vorstand/florian-lichtenstern-vorsitzender-junge-freie-waehler-oberbayern",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/0/7/csm_Lichtenstern_Florian_5ee963742a.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "jfw"
    },
    {
      "name": "Martina Purkhardt",
      "role": "Schriftführerin",
      "url": "https://www.fw-oberbayern.de/vorstand/martina-purkhardt-schriftfuehrerin",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/f/4/csm_Purkhardt_Martina_fd1a4dca20.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "gemeinsam"
    },
    {
      "name": "Martina Edl",
      "role": "Schatzmeisterin",
      "url": "https://www.fw-oberbayern.de/vorstand/martina-edl-schatzmeisterin",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/d/5/csm_Edl_Martina_59571d2ab9.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "gemeinsam"
    },
    {
      "name": "Angela Mayr",
      "role": "Justitiarin",
      "url": "https://www.fw-oberbayern.de/vorstand/angela-mayr-justitiarin",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/a/7/csm_Mayr_Angela_7e0078ce4e.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "verband"
    },
    {
      "name": "Felix Leipold",
      "role": "Presse- und Öffentlichkeitsreferent Bezirksverband",
      "url": "https://www.fw-oberbayern.de/vorstand/felix-leipold-presse-und-oeffentlichkeitsreferent-bezirksverband-oberbayern",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/e/4/csm_Leipold_Felix_0ac060d57d.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "verband"
    },
    {
      "name": "Prof. Dr. Michael Piazolo",
      "role": "Vorsitzender Stadtverband München",
      "url": "https://www.fw-oberbayern.de/vorstand/prof-dr-michael-piazolo-vorsitzender-stadtverband-muenchen",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/a/d/csm_2013_MdL_Piazolo_01_79a359e865.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "verband"
    },
    {
      "name": "Dr. Martin Brunnhuber",
      "role": "Beisitzer Bezirksverband · Region 18",
      "url": "https://www.fw-oberbayern.de/vorstand/dr-martin-brunnhuber-beisitzer-bezirksverband-region-18",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/3/f/csm_Brunnhuber_Martin_d3e4fe0089.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "verband"
    },
    {
      "name": "Roland Jung",
      "role": "Beisitzer Stadtverband München",
      "url": "https://www.fw-oberbayern.de/vorstand/roland-jung-beisitzer-stadtverband-muenchen",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/c/a/csm_Jung_Roland_cf9ad0ec30.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "verband"
    },
    {
      "name": "Martin Rosenberger",
      "role": "Beisitzer Bezirksverband · Region 17",
      "url": "https://www.fw-oberbayern.de/vorstand/martin-rosenberger-beisitzer-bezirksverband-region-17",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/4/4/csm_Rosenberger_Martin_9b669b0a45.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "verband"
    },
    {
      "name": "Matthias Vilsmayer",
      "role": "Beisitzer Bezirksverband · Region 14",
      "url": "https://www.fw-oberbayern.de/vorstand/matthias-vilsmayer-beisitzer-bezirksverband-region-14",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/6/a/csm_Vilsmayer_Matthias_4c73217d1e.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "verband"
    },
    {
      "name": "Markus Weber",
      "role": "Beisitzer Bezirksverband · Region 10",
      "url": "https://www.fw-oberbayern.de/vorstand/markus-weber-beisitzer-bezirksverband-region-10",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/3/4/csm_Weber_Markus_8213ef857e.jpg",
      "imageSource": "FW Oberbayern (offizielles Profil)",
      "assignment": "verband"
    }
  ],
  "towns": [
    {
      "name": "Berglern",
      "url": "https://www.fwg-berglern.de"
    },
    {
      "name": "Dorfen",
      "url": "https://fw-dorfen.de"
    },
    {
      "name": "Erding",
      "url": "https://www.fw-erding.de"
    },
    {
      "name": "Isen",
      "url": "https://www.freiewaehler-isen.de"
    },
    {
      "name": "Lengdorf",
      "url": "https://www.freie-waehler-lengdorf.de"
    },
    {
      "name": "Moosinning",
      "url": "https://www.buergerblock-moosinning.de"
    },
    {
      "name": "Ottenhofen",
      "url": "https://www.fw-ottenhofen.de"
    },
    {
      "name": "Sankt Wolfgang",
      "url": "https://www.fw-landkreis-erding.de/kreistagskandidaten-2026",
      "linkLabel": "Nachweis / Kreiskontakt",
      "note": "Ortsvorsitz laut offiziellem Kandidatenverzeichnis 2026: Stephan Weindler; keine eigene Ortswebsite verifiziert."
    },
    {
      "name": "Taufkirchen (Vils)",
      "url": "https://www.fw-taufkirchen.de"
    },
    {
      "name": "Walpertskirchen",
      "url": "https://www.fw-walpertskirchen.de"
    },
    {
      "name": "Wartenberg",
      "url": "https://www.fw-wartenberg.de"
    }
  ]
};
