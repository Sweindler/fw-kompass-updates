/* Öffentliche Funktionsangaben (Stand 08.11.2026); FW-Landräte nach FW-Landesübersicht zur Kommunalwahl 2026, 28 Profile mit consent-basierten externen Porträts. */
export default {
  "updated": "2026-11-08",
  "sources": {
    "landtag": "https://fw-landtag.de/fraktion/",
    "bezirksrat": "https://www.bezirk-oberbayern.de/Der-Bezirk-Oberbayern/Bezirkstag/Mitglieder/Mitglieder-nach-Parteien/",
    "bund": "https://www.freiewaehler.eu/bund/vorstand/",
    "land": "https://www.fw-bayern.de/unser-landesverband/landesvorstand",
    "minister": "https://www.bayern.de/staatsregierung/kabinett/",
    "staatssekretaere": "https://www.bayern.de/staatsregierung/kabinett/",
    "euabgeordnete": "https://www.europarl.europa.eu/meps/de/search/advanced?countryCode=DE",
    "jfw": "https://www.junge-freie-waehler.de/",
    "jfwbund": "https://www.junge-freie-waehler.de/",
    "jfwland": "https://www.jfw-bayern.de/",
    "jfwbezirk": "https://www.jfw-bayern.de/bezirksvorsitzende/florian-lichtenstern-oberbayern",
    "jfwkreis": "https://www.fw-landkreis-erding.de/kontakt",
    "memorial": "https://www.stmwi.bayern.de/ministerium/trauer-um-hubert-aiwanger/",
    "landraete": "https://www.fw-bayern.de/landesverband-vereinigung/landraete"
  },
  "bezirksrat": [
    {
      "name": "Ludwig Bayer",
      "role": "Bezirksrat Oberbayern · Rennertshofen",
      "group": "bezirksrat",
      "description": "Neuburg-Schrobenhausen, Kreistag, Gemeinderat Rennertshofen",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/ludwig-bayer",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/4/8/csm_Bayer_Ludwig_44a8040427.jpg",
      "imageSource": "FW Oberbayern"
    },
    {
      "name": "Sonja Dirl",
      "role": "Bezirksrätin Oberbayern · Landkreis München",
      "group": "bezirksrat",
      "description": "München-Land, Kirchheim, Heimstetten",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/sonja-dirl",
      "image": "https://www.merkur.de/bilder/2023/09/04/92499517/32618000-sonja-dirl-bezirkstagskandidatin-der-freien-waehler-OJ7d.jpg",
      "imageSource": "Münchner Merkur / Privat"
    },
    {
      "name": "Susanne Droth",
      "role": "Bezirksrätin Oberbayern · Fürstenfeldbruck",
      "group": "bezirksrat",
      "description": "Fürstenfeldbruck",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/susanne-droth",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/0/a/csm_Droth_Susanne_bc66af34e2.jpg",
      "imageSource": "FW Oberbayern"
    },
    {
      "name": "Maria Grasser",
      "role": "Bezirksrätin Oberbayern · Landkreis Erding",
      "group": "bezirksrat",
      "description": "Isen, Landkreis Erding",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/maria-grasser",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/0/0/csm_Grasser_Maria_4ed5e0a230_1c549d8b1b.jpg",
      "imageSource": "FW Oberbayern / Privat"
    },
    {
      "name": "Jürgen Haindl",
      "role": "Bezirksrat Oberbayern · Erster Bürgermeister Hohenwart",
      "group": "bezirksrat",
      "description": "Pfaffenhofen an der Ilm, Hohenwart",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/juergen-haindl",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/f/8/csm_Haindl_Juergen_351ef442ac.jpg",
      "imageSource": "FW Oberbayern"
    },
    {
      "name": "Marianne Heigl",
      "role": "Stellv. FW-Fraktionsvorsitzende im Bezirkstag Oberbayern",
      "group": "bezirksrat",
      "description": "Zolling, Landkreis Freising, Bezirksrätin",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/marianne-heigl",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/2/a/csm_Foto_Heigl_aktuell_20200421_ccf5c4c8df.jpg",
      "imageSource": "FW Oberbayern / Foto Schranner"
    },
    {
      "name": "Sepp Hofer",
      "role": "FW-Fraktionsvorsitzender im Bezirkstag Oberbayern",
      "group": "bezirksrat",
      "description": "Rosenheim, Halfing, stellvertretender Landrat, Bezirksrat",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/sepp-hofer",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/d/d/csm_FGW_Sepp_19052020_8579ea6d8d.jpg",
      "imageSource": "FW Oberbayern / Privat"
    },
    {
      "name": "Dr. Michael Schanderl",
      "role": "Bezirksrat Oberbayern · Stellv. Landrat Fürstenfeldbruck",
      "group": "bezirksrat",
      "description": "Emmering, Fürstenfeldbruck",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/dr-michael-schanderl",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/5/6/csm_Dr._Michael_Schanderl_23052020_15aaac5737.jpg",
      "imageSource": "FW Oberbayern / Foto Peter Weber"
    },
    {
      "name": "Rainer Schneider",
      "role": "Stellvertretender Bezirkstagspräsident Oberbayern",
      "group": "bezirksrat",
      "description": "Neufahrn, Freising, Bezirksrat, stellvertretender Bezirksvorsitzender",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/rainer-schneider",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/f/c/csm_Rainer_Schneider_44c853eea1.png",
      "imageSource": "FW Oberbayern"
    },
    {
      "name": "Konrad Specker",
      "role": "Bezirksrat Oberbayern · Bad Heilbrunn",
      "group": "bezirksrat",
      "description": "Bad Tölz-Wolfratshausen, Gemeinderat, Kreisrat",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/konrad-specker"
    },
    {
      "name": "Anton Speer",
      "role": "Bezirksrat Oberbayern · Landrat Garmisch-Partenkirchen",
      "group": "bezirksrat",
      "description": "Unterammergau, Landkreis Garmisch-Partenkirchen",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/anton-speer",
      "image": "https://www.fw-oberbayern.de/fileadmin/_processed_/5/6/csm_Anton_Speer_0f9e174620.png",
      "imageSource": "FW Oberbayern"
    },
    {
      "name": "Barbara Stein",
      "role": "Bezirksrätin Oberbayern · Landkreis Rosenheim",
      "group": "bezirksrat",
      "description": "Prutting, Rosenheim, Gemeinderätin, Kreisrätin",
      "url": "https://www.fw-oberbayern.de/mandatstraeger/unsere-bezirksraete-von-oberbayern/barbara-stein"
    }
  ],
  "landtag": [
    {
      "name": "Hubert Aiwanger",
      "role": "Mitglied des Bayerischen Landtags (MdL); Wahlkreis Landshut",
      "group": "landtag",
      "url": "https://www.stmwi.bayern.de/ministerium/trauer-um-hubert-aiwanger/",
      "image": "./assets/hubert-aiwanger-portrait.webp",
      "imageSource": "Porträt aus vorhandenem Gedenkbild",
      "memorial": true,
      "memorialDate": "2026-11-04",
      "memorialNote": "† 4. November 2026",
      "localImage": true
    },
    {
      "name": "Martin Behringer",
      "role": "Wohnen, Bauen und Verkehr; Landesentwicklung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/martin-behringer",
      "image": "https://fw-landtag.de/fileadmin/_processed_/0/6/csm_Behringer_f58c20a851.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Dr. Martin Brunnhuber",
      "role": "Stv. Fraktionsvorsitzender; Bildung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/martin-brunnhuber",
      "image": "https://fw-landtag.de/fileadmin/_processed_/d/e/csm_Brunnhuber_3be9a2d8e2.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Susann Enders",
      "role": "Gesundheitspolitische Sprecherin",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/susann-enders",
      "image": "https://fw-landtag.de/fileadmin/_processed_/5/c/csm_Enders_d4c8208f7e.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Stefan Frühbeißer",
      "role": "Finanzpolitischer Sprecher",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/stefan-fruehbeisser",
      "image": "https://fw-landtag.de/fileadmin/_processed_/c/7/csm_Fruehbeisser_4139e02a52.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Thorsten Glauber",
      "role": "Staatsminister für Umwelt und Verbraucherschutz",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/thorsten-glauber",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/e/csm_Glauber_cd5df9774a.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Tobias Gotthardt",
      "role": "Staatssekretär für Wirtschaft; führt das Wirtschaftsministerium vorläufig",
      "group": "landtag",
      "url": "https://www.bayern.landtag.de/abgeordnete/abgeordnete-von-a-z/profil/tobias-gotthardt/",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/3/csm_Gotthardt_8b40767110.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Johann Groß",
      "role": "Tourismuspolitischer Sprecher",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/johann-gross",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/e/csm_Gross_693723b000.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Wolfgang Hauber",
      "role": "Innenpolitischer Sprecher",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/wolfgang-hauber",
      "image": "https://fw-landtag.de/fileadmin/_processed_/c/9/csm_Hauber_b10a4c10ab.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Bernhard Heinisch",
      "role": "Stv. Fraktionsvorsitzender; Sport",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/bernhard-heinisch",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/9/csm_Heinisch_b9d63d6802.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Alexander Hold",
      "role": "2. Vizepräsident des Bayerischen Landtags",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/alexander-hold",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/1/csm_Hold_b6574f41a1.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Marina Jakob",
      "role": "Umwelt und Verbraucherschutz",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/marina-jakob",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/5/csm_Jakob_9cce55618e.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Nikolaus Kraus",
      "role": "Landwirtschaft und Ernährung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/nikolaus-kraus",
      "image": "https://fw-landtag.de/fileadmin/_processed_/0/1/csm_Kraus_8efd9c7d1c.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Josef Lausch",
      "role": "Energiepolitischer Sprecher",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/josef-lausch",
      "image": "https://fw-landtag.de/fileadmin/_processed_/f/2/csm_Lausch_e56a403670.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Christian Lindinger",
      "role": "Jagd und öffentlicher Dienst",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/christian-lindinger",
      "image": "https://fw-landtag.de/fileadmin/_processed_/b/e/csm_Lindinger_a5c3141991.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Felix Locke",
      "role": "Parlamentarischer Geschäftsführer",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/felix-locke",
      "image": "https://fw-landtag.de/fileadmin/_processed_/1/a/csm_Locke_6915689f71.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Rainer Ludwig",
      "role": "Medienpolitischer Sprecher",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/rainer-ludwig",
      "image": "https://fw-landtag.de/fileadmin/_processed_/9/a/csm_Ludwig_799b6962d5.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Dr. Fabian Mehring",
      "role": "Staatsminister für Digitales",
      "group": "landtag",
      "url": "https://www.bayern.landtag.de/abgeordnete/abgeordnete-von-a-z/profil/fabian-mehring",
      "image": "https://fw-landtag.de/fileadmin/_processed_/8/a/csm_Mehring_57aa67bbab.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Ulrike Müller",
      "role": "Bund, Europa und Internationales",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/ulrike-mueller",
      "image": "https://fw-landtag.de/fileadmin/_processed_/1/7/csm_Mueller_18160dc15f.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Prof. Dr. Michael Piazolo",
      "role": "Wissenschaft und Hochschule",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/michael-piazolo",
      "image": "https://fw-landtag.de/fileadmin/_processed_/9/d/csm_Piazolo_a2731e2f51.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Bernhard Pohl",
      "role": "1. stv. Fraktionsvorsitzender; Haushalt",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/bernhard-pohl",
      "image": "https://fw-landtag.de/fileadmin/_processed_/0/3/csm_Pohl_cc7fc9b6f6.png",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Julian Preidl",
      "role": "Kultur und Generationen",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/julian-preidl",
      "image": "https://fw-landtag.de/fileadmin/_processed_/a/1/csm_Preidl_cb5aec44f5.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Anton Rittel",
      "role": "Arbeit, Soziales und Handwerk",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/anton-rittel",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/f/csm_Rittel_9f7254f456.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Martin Rosenberger",
      "role": "Tourismus und Erwachsenenbildung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/martin-rosenberger",
      "image": "https://fw-landtag.de/fileadmin/_processed_/5/e/csm_Rosenberger-quadratisch_120x120px_e02f2da588.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Markus Saller",
      "role": "Wirtschaft und Digitalisierung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/markus-saller",
      "image": "https://fw-landtag.de/fileadmin/_processed_/c/5/csm_Saller_3e8b7109aa.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Martin Scharf",
      "role": "Recht und Entwicklungspolitik",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/martin-scharf",
      "image": "https://fw-landtag.de/fileadmin/_processed_/9/b/csm_Scharf_245e52ede9.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Werner Schießl",
      "role": "Verbraucherschutz",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/werner-schiessl",
      "image": "https://fw-landtag.de/fileadmin/_processed_/e/8/csm_Schiessl_bdc1f0d7d4.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Gabi Schmidt",
      "role": "Ehrenamtsbeauftragte; Ehrenamt",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/gabi-schmidt",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/f/csm_Schmidt_a2d800c10b.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Johanna Schramm",
      "role": "Berufliche Bildung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/johanna-schramm",
      "image": "https://fw-landtag.de/fileadmin/_processed_/d/a/csm_Schramm-quadratisch_120x120px_d551b30859.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Anna Stolz",
      "role": "Staatsministerin für Unterricht und Kultus",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/anna-stolz",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/6/csm_Stolz_cd913e33b6.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Florian Streibl",
      "role": "Fraktionsvorsitzender",
      "group": "landtag",
      "url": "https://www.bayern.landtag.de/abgeordnete/abgeordnete-von-a-z/profil/florian-streibl/",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/6/csm_Streibl_a099409bc1.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Roswitha Toso",
      "role": "Inklusion, Frauen, Gleichstellung und Denkmalschutz",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/roswitha-toso",
      "image": "https://fw-landtag.de/fileadmin/_processed_/a/4/csm_Toso_c9eca3b951.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Roland Weigert",
      "role": "Kommunalpolitik, Wald und Forsten",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/roland-weigert",
      "image": "https://fw-landtag.de/fileadmin/_processed_/e/2/csm_Weigert_90529f9dcc.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Jutta Widmann",
      "role": "Gastronomie",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/jutta-widmann",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/5/csm_Widmann_c81d10dee4.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Benno Zierer",
      "role": "Klima",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/benno-zierer",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/e/csm_Zierer_d11edb710b.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Felix von Zobel",
      "role": "Stv. Fraktionsvorsitzender; Steuern",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/felix-von-zobel",
      "image": "https://fw-landtag.de/fileadmin/_processed_/4/3/csm_vonZobel_08c124401c.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Thomas Zöller",
      "role": "Pflegebeauftragter; Pflegepolitik",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/thomas-zoeller",
      "image": "https://fw-landtag.de/fileadmin/_processed_/b/0/csm_Zoeller_1e2fed3d72.jpg",
      "imageSource": "FW-Landtagsfraktion"
    }
  ],
  "bund": [
    {
      "name": "Hubert Aiwanger",
      "role": "Bundesvorsitzender der FREIEN WÄHLER",
      "group": "bund",
      "url": "https://www.stmwi.bayern.de/ministerium/trauer-um-hubert-aiwanger/",
      "image": "./assets/hubert-aiwanger-portrait.webp",
      "imageSource": "Porträt aus vorhandenem Gedenkbild",
      "memorial": true,
      "memorialDate": "2026-11-04",
      "memorialNote": "† 4. November 2026",
      "localImage": true
    },
    {
      "name": "Manfred Petry",
      "role": "Stv. Bundesvorsitzender; vorläufige Führung nach Aiwangers Tod",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/manfred-petry/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Manfred_Petry_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Gregor Voht",
      "role": "Generalsekretär",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/gregor-voht/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Gregor_Voht_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Engin Eroglu",
      "role": "Stv. Bundesvorsitzender; Mitglied des Europäischen Parlaments",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/engin-eroglu-mdep/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Engin_Eroglu_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Kerstin Haimerl-Kunze",
      "role": "Stv. Bundesvorsitzende",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/kerstin-haimerl-kunze/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Kerstin_Haimerl-Kunze_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Dr. Joachim Streit",
      "role": "Stv. Bundesvorsitzender; Mitglied des Europäischen Parlaments",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/dr-joachim-streit-mdep/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Joachim_Streit_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Christine Singer",
      "role": "Vertreterin der FW-Abgeordneten im Europäischen Parlament",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/christine-singer/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Christine_Singer_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Christa Hudyma",
      "role": "Bundesschatzmeisterin",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/christa-hudyma/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Christa_Hudyma_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Lisa-Marie Jeckel",
      "role": "Bundesvorstandsmitglied (laut Bundesvereinigung); Landesvorsitzende FREIE WÄHLER Rheinland-Pfalz",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/lisa-marie-jeckel-mdl/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Lisa-Marie_Jeckel_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Arnold Hansen",
      "role": "Bundesgeschäftsführer",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/"
    },
    {
      "name": "Michaela Beier",
      "role": "Stv. Bundesgeschäftsführerin",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/"
    },
    {
      "name": "Eike Jan Brandau",
      "role": "Bundespressesprecher",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/"
    }
  ],
  "land": [
    {
      "name": "Hubert Aiwanger",
      "role": "Landesvorsitzender der FREIEN WÄHLER Bayern",
      "group": "land",
      "url": "https://www.stmwi.bayern.de/ministerium/trauer-um-hubert-aiwanger/",
      "image": "./assets/hubert-aiwanger-portrait.webp",
      "imageSource": "Porträt aus vorhandenem Gedenkbild",
      "memorial": true,
      "memorialDate": "2026-11-04",
      "memorialNote": "† 4. November 2026",
      "localImage": true
    },
    {
      "name": "Hans Martin Grötsch",
      "role": "Generalsekretär",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/hans-martin-groetsch",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/1/4/csm_Hans_Martin_Gr%C3%B6tsch__Generalsekret%C3%A4r_FREIE_W%C3%84HLER_Bayern__Bildquelle__FREIE_W%C3%84HLER_Bayern_1c09ed6199.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Armin Kroder",
      "role": "Stv. Landesvorsitzender",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/armin-kroder",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/4/5/csm_Landrat_Armin_Kroder_636d4c1407.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Sabrina Neckov",
      "role": "Stv. Landesvorsitzende",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/sabrina-neckov",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/c/9/csm_Neckov__neu_Januar_2026_bb479a9f6c.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Dr. Fabian Mehring",
      "role": "Stv. Landesvorsitzender",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/dr-fabian-mehring",
      "image": "https://fw-landtag.de/fileadmin/_processed_/8/a/csm_Mehring_57aa67bbab.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Prof. Dr. Michael Piazolo",
      "role": "Stv. Landesvorsitzender",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/michael-piazolo",
      "image": "https://fw-landtag.de/fileadmin/_processed_/9/d/csm_Piazolo_a2731e2f51.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Susann Enders",
      "role": "Stv. Landesvorsitzende",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/susann-enders",
      "image": "https://fw-landtag.de/fileadmin/_processed_/5/c/csm_Enders_d4c8208f7e.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Anton Haunsberger",
      "role": "Schatzmeister",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/anton-haunsberger",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/3/5/csm_Anton_Haunsberger_kleiner_7e769f4574.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Maria Horn Hörtrich",
      "role": "Vorsitzende Junge FREIE WÄHLER Bayern",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/maria-horn-hoertrich",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/9/9/csm_Maria_Horn_H%C3%B6rtrich_891e6911c2.jpeg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Bernhard Schmidt",
      "role": "Beisitzer (Oberpfalz)",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/bernhard-schmidt",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/5/0/csm_11_Schmidt_Bernhard_c598ecfa48.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Marina Jakob",
      "role": "Beisitzerin",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/marina-jakob",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/5/csm_Jakob_9cce55618e.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Dr. Georg Meiski",
      "role": "Beisitzer (Niederbayern)",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/georg-meiski"
    },
    {
      "name": "Frank Helmerich",
      "role": "Beisitzer",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/frank-helmerich",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/b/e/csm_Helmerich_Frank__e2cce06249.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Felix Stahl",
      "role": "Beisitzer",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/felix-stahl",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/0/5/csm_stahl_aef95a10f7.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Manfred Hümmer",
      "role": "Beisitzer",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/manfred-huemmer"
    },
    {
      "name": "Martina Purkhardt",
      "role": "Beisitzerin",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/martina-purkhardt"
    },
    {
      "name": "Felix Locke",
      "role": "Beisitzer",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/felix-locke",
      "image": "https://fw-landtag.de/fileadmin/_processed_/1/a/csm_Locke_6915689f71.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Florian Weber",
      "role": "Beisitzer (Schwaben, Landesverband)",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/florian-weber",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/c/e/csm_Florian_Weber_-_Lindenberg_im_Allg%C3%A4u_Foto_1_214dc72021.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Thorsten Glauber",
      "role": "Beisitzer (Oberfranken, Landesverband)",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/thorsten-glauber",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/e/csm_Glauber_cd5df9774a.jpg",
      "imageSource": "FW-Landtagsfraktion"
    }
  ],
  "minister": [
    {
      "name": "Hubert Aiwanger",
      "role": "Bayerischer Staatsminister für Wirtschaft, Landesentwicklung und Energie und stellvertretender Ministerpräsident",
      "group": "minister",
      "url": "https://www.stmwi.bayern.de/ministerium/trauer-um-hubert-aiwanger/",
      "image": "./assets/hubert-aiwanger-portrait.webp",
      "imageSource": "Porträt aus vorhandenem Gedenkbild",
      "memorial": true,
      "memorialDate": "2026-11-04",
      "memorialNote": "† 4. November 2026",
      "localImage": true
    },
    {
      "name": "Anna Stolz",
      "role": "Bayerische Staatsministerin für Unterricht und Kultus",
      "group": "minister",
      "url": "https://fw-landtag.de/fraktion/mdl/anna-stolz",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/6/csm_Stolz_cd913e33b6.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Thorsten Glauber",
      "role": "Bayerischer Staatsminister für Umwelt und Verbraucherschutz",
      "group": "minister",
      "url": "https://fw-landtag.de/fraktion/mdl/thorsten-glauber",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/e/csm_Glauber_cd5df9774a.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Dr. Fabian Mehring",
      "role": "Bayerischer Staatsminister für Digitales",
      "group": "minister",
      "url": "https://fw-landtag.de/fraktion/mdl/fabian-mehring",
      "image": "https://fw-landtag.de/fileadmin/_processed_/8/a/csm_Mehring_57aa67bbab.jpg",
      "imageSource": "FW-Landtagsfraktion"
    }
  ],
  "staatssekretaere": [
    {
      "name": "Tobias Gotthardt",
      "role": "Bayerischer Staatssekretär im Staatsministerium für Wirtschaft, Landesentwicklung und Energie; führt dort vorläufig die Amtsgeschäfte",
      "group": "staatssekretaere",
      "url": "https://www.stmwi.bayern.de/ministerium/staatssekretaer/",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/3/csm_Gotthardt_8b40767110.jpg",
      "imageSource": "FW-Landtagsfraktion"
    }
  ],
  "euabgeordnete": [
    {
      "name": "Christine Singer",
      "role": "Mitglied des Europäischen Parlaments · Renew Europe",
      "group": "euabgeordnete",
      "url": "https://www.europarl.europa.eu/meps/de/256946/CHRISTINE_SINGER/home",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Christine_Singer_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Engin Eroglu",
      "role": "Mitglied des Europäischen Parlaments · Renew Europe",
      "group": "euabgeordnete",
      "url": "https://www.europarl.europa.eu/meps/de/197430/ENGIN_EROGLU/home",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Engin_Eroglu_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Dr. Joachim Streit",
      "role": "Mitglied des Europäischen Parlaments · Renew Europe",
      "group": "euabgeordnete",
      "url": "https://www.europarl.europa.eu/meps/de/256962/JOACHIM_STREIT/home",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Joachim_Streit_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    }
  ],
  "jfwbund": [
    {
      "name": "Georg Probst",
      "role": "Bundesvorsitzender",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Georg.jpeg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "David Gutzeit",
      "role": "Stellvertretender Bundesvorsitzender",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/David-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Marius Ackermann",
      "role": "Stellvertretender Bundesvorsitzender",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Marius-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Leonie Rother",
      "role": "Stellvertretende Bundesvorsitzende",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Leonie-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Pascal Georg",
      "role": "Stellvertretender Bundesvorsitzender",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Pascal-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Zuher Al-Korishy",
      "role": "Bundesgeschäftsführer",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/zuher_new.jpeg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Chris Daiser",
      "role": "Schriftführer",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Chris-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Michael Golling",
      "role": "Schatzmeister",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/michael_new.jpeg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Maximilian Eitner",
      "role": "Pressesprecher",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Max-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Marvin Klein",
      "role": "Medienreferent",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Marvin-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Lisa-Marie Jeckel",
      "role": "Justiziariat",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2025/01/IMG-20250128-WA0027.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Eva Maria Mack",
      "role": "Beisitzerin",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Eva-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "René Reiße",
      "role": "Beisitzer",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Rene.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Marcel Holzmann",
      "role": "Beisitzer",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Marcel-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Noah Schmitt",
      "role": "Beisitzer",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/"
    }
  ],
  "jfwland": [
    {
      "name": "Maria Horn-Hörtrich",
      "role": "Landesvorsitzende",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/maria-horn-hoertrich-landesvorsitzende",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/d/2/csm_portrait_maria-horn-hoertrich_2026_466edacd4d.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Eva Maria Mack",
      "role": "Stellvertretende Landesvorsitzende",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/eva-maria-mack-stellv-landesvorsitzende",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/c/c/csm_portrait_eva-maria-mack_2026_31a06763bf.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Florian Mies",
      "role": "Stellvertretender Landesvorsitzender",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/florian-mies-stellv-landesvorsitzender",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/e/7/csm_portrait_florian-mies_2026_0abd936d3c.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Jacob Buys",
      "role": "Stellvertretender Landesvorsitzender",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/jacob-buys-stellv-landesvorsitzender",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/b/3/csm_portrait_jacob-buys_2026_55bfc95cd2.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Fabian Schmid",
      "role": "Stellvertretender Landesvorsitzender",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/fabian-schmid-stellv-landesvorsitzender",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/2/f/csm_portrait_fabian-schmid_2026_2ac4bbf356.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Julian Preidl",
      "role": "Generalsekretär",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/julian-preidl-generalsekretaer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/2/9/csm_portrait_julian-preidl_2026_4617b0d051.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Alexander Krauß",
      "role": "Schatzmeister",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/alexander-krauss-schatzmeister",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/5/3/csm_portrait_alexander-krauss_2026_bb698cc90d.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Milena Heisinger",
      "role": "Schriftführerin",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/milena-heisinger-schriftfuehrerin",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/7/0/csm_portrait_milena-heisinger_2026_2ec2d4b505.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Andreas Düthorn",
      "role": "Landesgeschäftsführer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/andreas-duethorn-landesgeschaeftsfuehrer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/d/4/csm_portrait_andreas-duethorn_2026_2ea038404c.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Thomas Gärtner",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/thomas-gaertner-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/b/8/csm_portrait_thomas-gaertner_2026_512858c835.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Manuel Spar",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/manuel-spar-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/f/0/csm_portrait_manuel-spar_2026_2eb024d295.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Elias Braun",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/elias-braun-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/8/f/csm_portrait_elias-braun_2026_420d6a6cb6.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Lorenz Höfler",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/lorenz-hoefler-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/7/f/csm_portrait_lorenz-hoefler_2026_008deb28e2.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Felix von Zobel",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/felix-von-zobel-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/5/e/csm_portrait_felix-von-zobel_2026_f5580f7bdf.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Michael Golling",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/michael-golling-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/8/0/csm_portrait_michael-golling_2026_aa526f4363.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Johannes Puschek",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/johannes-puschek-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/5/8/csm_portrait_johannes-puschek_2026_v2_411e472b51.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Mikka Ion Steinert",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/mikka-ion-steinert-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/b/0/csm_portrait_mikka-ion-steinert_2026_a648cbf83b.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Max Vogl",
      "role": "Referent für neue Medien",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/max-vogl-referent-fuer-neue-medien",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/f/d/csm_portrait_max-vogl_2026_5291e88c1d.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Matthias Murr",
      "role": "Pressereferent",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/matthias-murr-pressereferent",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/4/3/csm_portrait_matthias-murr_2026_b59a64527e.jpg",
      "imageSource": "JFW Bayern"
    }
  ],
  "jfwbezirk": [
    {
      "name": "Florian Lichtenstern",
      "role": "Bezirksvorsitzender Oberbayern",
      "group": "jfwbezirk",
      "url": "https://www.jfw-bayern.de/bezirksvorsitzende/florian-lichtenstern-oberbayern",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/d/5/csm_Portrait_Florian_Lichtenstern_2024_v2_96971d3752.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Maria Horn-Hörtrich",
      "role": "Stellvertretende Bezirksvorsitzende Oberbayern",
      "group": "jfwbezirk",
      "url": "https://www.jfw-bayern.de/vorstand/maria-horn-hoertrich-landesvorsitzende",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/d/2/csm_portrait_maria-horn-hoertrich_2026_466edacd4d.jpg",
      "imageSource": "JFW Bayern"
    }
  ],
  "jfwkreis": [],
  "landraete": [
    {
      "name": "Ludwig Schmid",
      "role": "Landrat · Landkreis Bad Tölz-Wolfratshausen",
      "group": "landraete",
      "description": "Oberbayern · Bad Tölz-Wolfratshausen",
      "region": "Oberbayern",
      "county": "Bad Tölz-Wolfratshausen",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/bad-toelz-wolfratshausen-ludwig-schmid",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/8/2/csm_Ludwig__Schmid__Landrat_26_5d38fdac80.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Michael Koller",
      "role": "Landrat · Landkreis Berchtesgadener Land",
      "group": "landraete",
      "description": "Oberbayern · Berchtesgadener Land",
      "region": "Oberbayern",
      "county": "Berchtesgadener Land",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/berchtesgadener-land-michael-koller",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/9/c/csm_Michael_Koller_Landrat_8dc832b60a.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Anton Speer",
      "role": "Landrat · Landkreis Garmisch-Partenkirchen",
      "group": "landraete",
      "description": "Oberbayern · Garmisch-Partenkirchen",
      "region": "Oberbayern",
      "county": "Garmisch-Partenkirchen",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/garmisch-patenkirchen-anton-speer",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/f/2/csm_Anton_Speer_Landrat_26_70b2648630.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Jens Zangenfeind",
      "role": "Landrat · Landkreis Miesbach",
      "group": "landraete",
      "description": "Oberbayern · Miesbach",
      "region": "Oberbayern",
      "county": "Miesbach",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/miesbach-jens-zangenfeind",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/f/8/csm_Jens_Zangenfeind_Landrat_26_4fd6270784.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Albert Gürtner",
      "role": "Landrat · Landkreis Pfaffenhofen a.d. Ilm",
      "group": "landraete",
      "description": "Oberbayern · Pfaffenhofen a.d. Ilm",
      "region": "Oberbayern",
      "county": "Pfaffenhofen a.d. Ilm",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/pfaffenhofen-albert-guertner",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/0/3/csm_Guertner_a32139a34a.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Andreas Danzer",
      "role": "Landrat · Landkreis Traunstein",
      "group": "landraete",
      "description": "Oberbayern · Traunstein",
      "region": "Oberbayern",
      "county": "Traunstein",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/traunstein-andreas-danzer",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/3/d/csm_Andreas_Danzer_24_abe68f4c33.png",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Christian Nerb",
      "role": "Landrat · Landkreis Kelheim",
      "group": "landraete",
      "description": "Niederbayern · Kelheim",
      "region": "Niederbayern",
      "county": "Kelheim",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/kelheim-christian-nerb",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/3/2/csm_Christian_Nerb__Landrat_2026__neu_bad46f4bd3.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Alfred Holzner",
      "role": "Landrat · Landkreis Landshut",
      "group": "landraete",
      "description": "Niederbayern · Landshut",
      "region": "Niederbayern",
      "county": "Landshut",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/landshut-alfred-holzner",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/b/0/csm_Alfred_Holzner_Landrat_26_6738452f14.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Martin Koppmann",
      "role": "Landrat · Landkreis Rottal-Inn",
      "group": "landraete",
      "description": "Niederbayern · Rottal-Inn",
      "region": "Niederbayern",
      "county": "Rottal-Inn",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/rottal-inn-martin-koppmann",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/e/b/csm_Martin_Koppmann_Landrat_26_e905ce131b.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Tobias Beck",
      "role": "Landrat · Landkreis Straubing-Bogen",
      "group": "landraete",
      "description": "Niederbayern · Straubing-Bogen",
      "region": "Niederbayern",
      "county": "Straubing-Bogen",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/straubing-bogen-tobias-beck",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/8/7/csm_Tobias_Beck_Landrat_26_f8e667bf74.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Christian Schindler",
      "role": "Landrat · Landkreis Cham",
      "group": "landraete",
      "description": "Oberpfalz · Cham",
      "region": "Oberpfalz",
      "county": "Cham",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/cham-christian-schindler",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/f/8/csm_Christian_Schindler__Landrat__2026_080ea12229.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Martin Meier",
      "role": "Landrat · Landkreis Neumarkt i.d. OPf.",
      "group": "landraete",
      "description": "Oberpfalz · Neumarkt i.d. OPf.",
      "region": "Oberpfalz",
      "county": "Neumarkt i.d. OPf.",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/neumarkt-id-opf-martin-meier",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/5/d/csm_Martin_Meier_Landrat_26_1fed8dcff8.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Tanja Schweiger",
      "role": "Landrätin · Landkreis Regensburg",
      "group": "landraete",
      "description": "Oberpfalz · Regensburg",
      "region": "Oberpfalz",
      "county": "Regensburg",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/regensburg-tanja-schweiger/",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/d/1/csm_Tanja_Schweiger__Wahl__neu_Juni_2026_8074c3f4b6.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Hubert Schicker",
      "role": "Landrat · Landkreis Tirschenreuth",
      "group": "landraete",
      "description": "Oberpfalz · Tirschenreuth",
      "region": "Oberpfalz",
      "county": "Tirschenreuth",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/tirschenreuth-hubert-schicker",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/3/c/csm_Hubert_Schicker_Landrat_26_f0df2ac16a.png",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Florian Wiedemann",
      "role": "Landrat · Landkreis Bayreuth",
      "group": "landraete",
      "description": "Oberfranken · Bayreuth",
      "region": "Oberfranken",
      "county": "Bayreuth",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/bayreuth-land-florian-wiedemann",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/d/7/csm_Florian_Wiedemann_Landrat__26_4818b532ff.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Hanngörg Zimmermann",
      "role": "Landrat · Landkreis Forchheim",
      "group": "landraete",
      "description": "Oberfranken · Forchheim",
      "region": "Oberfranken",
      "county": "Forchheim",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/forchheim-hanngoerg-zimmermann",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/9/7/csm_1_DSC07904_R_870d73dc62.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Marco Meier",
      "role": "Landrat · Landkreis Ansbach",
      "group": "landraete",
      "description": "Mittelfranken · Ansbach",
      "region": "Mittelfranken",
      "county": "Ansbach",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/ansbach-marco-meier",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/d/9/csm_Marco_Meier_Landrat_26_e2bf90d40a.png",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Armin Kroder",
      "role": "Landrat · Landkreis Nürnberger Land",
      "group": "landraete",
      "description": "Mittelfranken · Nürnberger Land",
      "region": "Mittelfranken",
      "county": "Nürnberger Land",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/nuernberger-land-armin-kroder",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/b/8/csm_AK__Juni_2026_72787788c3.png",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Markus Gläser",
      "role": "Landrat · Landkreis Weißenburg-Gunzenhausen",
      "group": "landraete",
      "description": "Mittelfranken · Weißenburg-Gunzenhausen",
      "region": "Mittelfranken",
      "county": "Weißenburg-Gunzenhausen",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/weissenburg-gunzenhausen-markus-glaeser",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/0/9/csm_markus_glaeser__Landrat__2026_6b9efc878d.jpeg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Tamara Bischof",
      "role": "Landrätin · Landkreis Kitzingen",
      "group": "landraete",
      "description": "Unterfranken · Kitzingen",
      "region": "Unterfranken",
      "county": "Kitzingen",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/kitzingen-tamara-bischof",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/c/b/csm_Tamara-Bischof_01a299b8ba.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Christoph Vogel",
      "role": "Landrat · Landkreis Main-Spessart",
      "group": "landraete",
      "description": "Unterfranken · Main-Spessart",
      "region": "Unterfranken",
      "county": "Main-Spessart",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/main-spessart-christoph-vogel",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/8/8/csm_Christoph_Vogel_Landrat_26_cea73ac956.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Sonja Rahm",
      "role": "Landrätin · Landkreis Rhön-Grabfeld",
      "group": "landraete",
      "description": "Unterfranken · Rhön-Grabfeld",
      "region": "Unterfranken",
      "county": "Rhön-Grabfeld",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/rhoen-grabfeld-sonja-rahm",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/4/f/csm_Sonja_Rahm_Landrat_26_bdab5bb1d3.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Dr. Marc Sturm",
      "role": "Landrat · Landkreis Aichach-Friedberg",
      "group": "landraete",
      "description": "Schwaben · Aichach-Friedberg",
      "region": "Schwaben",
      "county": "Aichach-Friedberg",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/aichach-friedberg-dr-marc-sturm",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/d/2/csm_Dr_Marc_Sturm__Landrat__2026_a433f5d5a7.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Markus Müller",
      "role": "Landrat · Landkreis Dillingen a.d. Donau",
      "group": "landraete",
      "description": "Schwaben · Dillingen a.d. Donau",
      "region": "Schwaben",
      "county": "Dillingen a.d. Donau",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/dillingen-markus-mueller",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/c/7/csm_220222-Markus-Mueller_0bf5d1c669.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Michael Dinkelmeier",
      "role": "Landrat · Landkreis Donau-Ries",
      "group": "landraete",
      "description": "Schwaben · Donau-Ries",
      "region": "Schwaben",
      "county": "Donau-Ries",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/donau-ries-michael-dinkelmeier",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/b/9/csm_Landrat_Michael_Dinkelmeier_085_2684d77a51.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Christian Wilhelm",
      "role": "Landrat · Landkreis Oberallgäu",
      "group": "landraete",
      "description": "Schwaben · Oberallgäu",
      "region": "Schwaben",
      "county": "Oberallgäu",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/oberallgaeu-christian-wilhelm",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/7/3/csm_Christian_Wilhelm__Oberallg%C3%A4u_Landrats-Kandidat_33b8e5f952.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Bernd Stapfner",
      "role": "Landrat · Landkreis Ostallgäu",
      "group": "landraete",
      "description": "Schwaben · Ostallgäu",
      "region": "Schwaben",
      "county": "Ostallgäu",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/ostallgaeu-bernd-stapfner",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/9/2/csm_Bernd_Stapfner_Landrat_26_9b8d92ba68.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Alex Eder",
      "role": "Landrat · Landkreis Unterallgäu",
      "group": "landraete",
      "description": "Schwaben · Unterallgäu",
      "region": "Schwaben",
      "county": "Unterallgäu",
      "url": "https://www.fw-bayern.de/landesverband-vereinigung/landraete/unterallgaeu-alex-eder",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/a/5/csm_Alex_Eder__Landrat__26_9ee375cc25.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    }
  ]
};
