/* Öffentliche Funktionsangaben – Stand 08.11.2026; Hubert Aiwanger († 04.11.2026) als historisch gekennzeichneter Gedenkeintrag. Externe Fotos nur nach Einwilligung. */
export default {
  "updated": "2026-11-08",
  "sources": {
    "landtag": "https://fw-landtag.de/fraktion/",
    "bund": "https://www.freiewaehler.eu/bund/vorstand/",
    "land": "https://www.fw-bayern.de/unser-landesverband/landesvorstand",
    "minister": "https://www.bayern.de/staatsregierung/kabinett/",
    "staatssekretaere": "https://www.bayern.de/staatsregierung/kabinett/",
    "euabgeordnete": "https://www.europarl.europa.eu/meps/de/search/advanced?countryCode=DE",
    "jfw": "https://www.junge-freie-waehler.de/",
    "jfwbund": "https://www.junge-freie-waehler.de/",
    "jfwland": "https://www.jfw-bayern.de/",
    "jfwbezirk": "https://www.jfw-bayern.de/bezirksvorsitzende/florian-lichtenstern-oberbayern",
    "jfwkreis": "https://www.fw-landkreis-erding.de/kontakt",
    "memorial": "https://www.stmwi.bayern.de/ministerium/trauer-um-hubert-aiwanger/"
  },
  "landtag": [
    {
      "name": "Martin Behringer",
      "role": "Wohnen, Bauen und Verkehr; Landesentwicklung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/martin-behringer",
      "image": "https://fw-landtag.de/fileadmin/_processed_/0/6/csm_Behringer_f58c20a851.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Dr. Martin Brunnhuber",
      "role": "Stv. Fraktionsvorsitzender; Bildung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/martin-brunnhuber",
      "image": "https://fw-landtag.de/fileadmin/_processed_/d/e/csm_Brunnhuber_3be9a2d8e2.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Susann Enders",
      "role": "Gesundheitspolitische Sprecherin",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/susann-enders",
      "image": "https://fw-landtag.de/fileadmin/_processed_/5/c/csm_Enders_d4c8208f7e.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Stefan Frühbeißer",
      "role": "Finanzpolitischer Sprecher",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/stefan-fruehbeisser",
      "image": "https://fw-landtag.de/fileadmin/_processed_/c/7/csm_Fruehbeisser_4139e02a52.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Thorsten Glauber",
      "role": "Staatsminister für Umwelt und Verbraucherschutz",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/thorsten-glauber",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/e/csm_Glauber_cd5df9774a.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Tobias Gotthardt",
      "role": "Staatssekretär für Wirtschaft; führt das Wirtschaftsministerium vorläufig",
      "group": "landtag",
      "url": "https://www.bayern.landtag.de/abgeordnete/abgeordnete-von-a-z/profil/tobias-gotthardt/",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/3/csm_Gotthardt_8b40767110.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Johann Groß",
      "role": "Tourismuspolitischer Sprecher",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/johann-gross",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/e/csm_Gross_693723b000.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Wolfgang Hauber",
      "role": "Innenpolitischer Sprecher",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/wolfgang-hauber",
      "image": "https://fw-landtag.de/fileadmin/_processed_/c/9/csm_Hauber_b10a4c10ab.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Bernhard Heinisch",
      "role": "Stv. Fraktionsvorsitzender; Sport",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/bernhard-heinisch",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/9/csm_Heinisch_b9d63d6802.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Alexander Hold",
      "role": "2. Vizepräsident des Bayerischen Landtags",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/alexander-hold",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/1/csm_Hold_b6574f41a1.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Marina Jakob",
      "role": "Umwelt und Verbraucherschutz",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/marina-jakob",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/5/csm_Jakob_9cce55618e.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Nikolaus Kraus",
      "role": "Landwirtschaft und Ernährung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/nikolaus-kraus",
      "image": "https://fw-landtag.de/fileadmin/_processed_/0/1/csm_Kraus_8efd9c7d1c.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Josef Lausch",
      "role": "Energiepolitischer Sprecher",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/josef-lausch",
      "image": "https://fw-landtag.de/fileadmin/_processed_/f/2/csm_Lausch_e56a403670.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Christian Lindinger",
      "role": "Jagd und öffentlicher Dienst",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/christian-lindinger",
      "image": "https://fw-landtag.de/fileadmin/_processed_/b/e/csm_Lindinger_a5c3141991.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Felix Locke",
      "role": "Parlamentarischer Geschäftsführer",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/felix-locke",
      "image": "https://fw-landtag.de/fileadmin/_processed_/1/a/csm_Locke_6915689f71.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Rainer Ludwig",
      "role": "Medienpolitischer Sprecher",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/rainer-ludwig",
      "image": "https://fw-landtag.de/fileadmin/_processed_/9/a/csm_Ludwig_799b6962d5.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Dr. Fabian Mehring",
      "role": "Staatsminister für Digitales",
      "group": "landtag",
      "url": "https://www.bayern.landtag.de/abgeordnete/abgeordnete-von-a-z/profil/fabian-mehring",
      "image": "https://fw-landtag.de/fileadmin/_processed_/8/a/csm_Mehring_57aa67bbab.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Ulrike Müller",
      "role": "Bund, Europa und Internationales",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/ulrike-mueller",
      "image": "https://fw-landtag.de/fileadmin/_processed_/1/7/csm_Mueller_18160dc15f.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Prof. Dr. Michael Piazolo",
      "role": "Wissenschaft und Hochschule",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/michael-piazolo",
      "image": "https://fw-landtag.de/fileadmin/_processed_/9/d/csm_Piazolo_a2731e2f51.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Bernhard Pohl",
      "role": "1. stv. Fraktionsvorsitzender; Haushalt",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/bernhard-pohl",
      "image": "https://fw-landtag.de/fileadmin/_processed_/0/3/csm_Pohl_cc7fc9b6f6.png",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Julian Preidl",
      "role": "Kultur und Generationen",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/julian-preidl",
      "image": "https://fw-landtag.de/fileadmin/_processed_/a/1/csm_Preidl_cb5aec44f5.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Anton Rittel",
      "role": "Arbeit, Soziales und Handwerk",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/anton-rittel",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/f/csm_Rittel_9f7254f456.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Martin Rosenberger",
      "role": "Tourismus und Erwachsenenbildung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/martin-rosenberger",
      "image": "https://fw-landtag.de/fileadmin/_processed_/5/e/csm_Rosenberger-quadratisch_120x120px_e02f2da588.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Markus Saller",
      "role": "Wirtschaft und Digitalisierung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/markus-saller",
      "image": "https://fw-landtag.de/fileadmin/_processed_/c/5/csm_Saller_3e8b7109aa.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Martin Scharf",
      "role": "Recht und Entwicklungspolitik",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/martin-scharf",
      "image": "https://fw-landtag.de/fileadmin/_processed_/9/b/csm_Scharf_245e52ede9.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Werner Schießl",
      "role": "Verbraucherschutz",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/werner-schiessl",
      "image": "https://fw-landtag.de/fileadmin/_processed_/e/8/csm_Schiessl_bdc1f0d7d4.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Gabi Schmidt",
      "role": "Ehrenamtsbeauftragte; Ehrenamt",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/gabi-schmidt",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/f/csm_Schmidt_a2d800c10b.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Johanna Schramm",
      "role": "Berufliche Bildung",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/johanna-schramm",
      "image": "https://fw-landtag.de/fileadmin/_processed_/d/a/csm_Schramm-quadratisch_120x120px_d551b30859.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Anna Stolz",
      "role": "Staatsministerin für Unterricht und Kultus",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/anna-stolz",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/6/csm_Stolz_cd913e33b6.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Florian Streibl",
      "role": "Fraktionsvorsitzender",
      "group": "landtag",
      "url": "https://www.bayern.landtag.de/abgeordnete/abgeordnete-von-a-z/profil/florian-streibl/",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/6/csm_Streibl_a099409bc1.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Roswitha Toso",
      "role": "Inklusion, Frauen, Gleichstellung und Denkmalschutz",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/roswitha-toso",
      "image": "https://fw-landtag.de/fileadmin/_processed_/a/4/csm_Toso_c9eca3b951.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Roland Weigert",
      "role": "Kommunalpolitik, Wald und Forsten",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/roland-weigert",
      "image": "https://fw-landtag.de/fileadmin/_processed_/e/2/csm_Weigert_90529f9dcc.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Jutta Widmann",
      "role": "Gastronomie",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/jutta-widmann",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/5/csm_Widmann_c81d10dee4.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Benno Zierer",
      "role": "Klima",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/benno-zierer",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/e/csm_Zierer_d11edb710b.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Felix von Zobel",
      "role": "Stv. Fraktionsvorsitzender; Steuern",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/felix-von-zobel",
      "image": "https://fw-landtag.de/fileadmin/_processed_/4/3/csm_vonZobel_08c124401c.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Thomas Zöller",
      "role": "Pflegebeauftragter; Pflegepolitik",
      "group": "landtag",
      "url": "https://fw-landtag.de/fraktion/mdl/thomas-zoeller",
      "image": "https://fw-landtag.de/fileadmin/_processed_/b/0/csm_Zoeller_1e2fed3d72.jpg",
      "imageSource": "FW-Landtagsfraktion"
    }
  ],
  "bund": [
    {
      "name": "Hubert Aiwanger",
      "role": "Bundesvorsitzender der FREIEN WÄHLER (2010–2026)",
      "group": "bund",
      "url": "https://www.stmwi.bayern.de/ministerium/trauer-um-hubert-aiwanger/",
      "image": "https://www.stmwi.bayern.de/fileadmin/_processed_/0/9/csm_Ministerium_StM_Aiwanger_1000x1000px_640c3cfa2c.png",
      "imageSource": "Bayerisches Wirtschaftsministerium (StMWi)",
      "memorial": true,
      "memorialDate": "2026-11-04",
      "memorialNote": "† 4. November 2026 · Dieser Eintrag bewahrt seine bisherige Funktion in Erinnerung, nicht als amtierendes Mandat."
    },
    {
      "name": "Manfred Petry",
      "role": "Stv. Bundesvorsitzender; vorläufige Führung nach Aiwangers Tod",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/manfred-petry/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Manfred_Petry_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Gregor Voht",
      "role": "Generalsekretär",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/gregor-voht/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Gregor_Voht_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Engin Eroglu",
      "role": "Stv. Bundesvorsitzender; Mitglied des Europäischen Parlaments",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/engin-eroglu-mdep/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Engin_Eroglu_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Kerstin Haimerl-Kunze",
      "role": "Stv. Bundesvorsitzende",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/kerstin-haimerl-kunze/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Kerstin_Haimerl-Kunze_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Dr. Joachim Streit",
      "role": "Stv. Bundesvorsitzender; Mitglied des Europäischen Parlaments",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/dr-joachim-streit-mdep/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Joachim_Streit_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Christine Singer",
      "role": "Vertreterin der FW-Abgeordneten im Europäischen Parlament",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/christine-singer/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Christine_Singer_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Christa Hudyma",
      "role": "Bundesschatzmeisterin",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/christa-hudyma/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Christa_Hudyma_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Lisa-Marie Jeckel",
      "role": "Bundesvorstandsmitglied (laut Bundesvereinigung); Landesvorsitzende FREIE WÄHLER Rheinland-Pfalz",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/lisa-marie-jeckel-mdl/",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Lisa-Marie_Jeckel_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Arnold Hansen",
      "role": "Bundesgeschäftsführer",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/"
    },
    {
      "name": "Michaela Beier",
      "role": "Stv. Bundesgeschäftsführerin",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/"
    },
    {
      "name": "Eike Jan Brandau",
      "role": "Bundespressesprecher",
      "group": "bund",
      "url": "https://www.freiewaehler.eu/bund/vorstand/"
    }
  ],
  "land": [
    {
      "name": "Hubert Aiwanger",
      "role": "Landesvorsitzender der FREIEN WÄHLER Bayern (2006–2026)",
      "group": "land",
      "url": "https://www.stmwi.bayern.de/ministerium/trauer-um-hubert-aiwanger/",
      "image": "https://www.stmwi.bayern.de/fileadmin/_processed_/0/9/csm_Ministerium_StM_Aiwanger_1000x1000px_640c3cfa2c.png",
      "imageSource": "Bayerisches Wirtschaftsministerium (StMWi)",
      "memorial": true,
      "memorialDate": "2026-11-04",
      "memorialNote": "† 4. November 2026 · Dieser Eintrag bewahrt seine bisherige Funktion in Erinnerung, nicht als amtierendes Mandat."
    },
    {
      "name": "Hans Martin Grötsch",
      "role": "Generalsekretär",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/hans-martin-groetsch",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/1/4/csm_Hans_Martin_Gr%C3%B6tsch__Generalsekret%C3%A4r_FREIE_W%C3%84HLER_Bayern__Bildquelle__FREIE_W%C3%84HLER_Bayern_1c09ed6199.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Armin Kroder",
      "role": "Stv. Landesvorsitzender",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/armin-kroder",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/4/5/csm_Landrat_Armin_Kroder_636d4c1407.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Sabrina Neckov",
      "role": "Stv. Landesvorsitzende",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/sabrina-neckov",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/c/9/csm_Neckov__neu_Januar_2026_bb479a9f6c.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Dr. Fabian Mehring",
      "role": "Stv. Landesvorsitzender",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/dr-fabian-mehring",
      "image": "https://fw-landtag.de/fileadmin/_processed_/8/a/csm_Mehring_57aa67bbab.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Prof. Dr. Michael Piazolo",
      "role": "Stv. Landesvorsitzender",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/michael-piazolo",
      "image": "https://fw-landtag.de/fileadmin/_processed_/9/d/csm_Piazolo_a2731e2f51.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Susann Enders",
      "role": "Stv. Landesvorsitzende",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/susann-enders",
      "image": "https://fw-landtag.de/fileadmin/_processed_/5/c/csm_Enders_d4c8208f7e.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Anton Haunsberger",
      "role": "Schatzmeister",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/anton-haunsberger",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/3/5/csm_Anton_Haunsberger_kleiner_7e769f4574.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Maria Horn Hörtrich",
      "role": "Vorsitzende Junge FREIE WÄHLER Bayern",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/maria-horn-hoertrich",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/9/9/csm_Maria_Horn_H%C3%B6rtrich_891e6911c2.jpeg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Bernhard Schmidt",
      "role": "Beisitzer (Oberpfalz)",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/bernhard-schmidt",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/5/0/csm_11_Schmidt_Bernhard_c598ecfa48.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Marina Jakob",
      "role": "Beisitzerin",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/marina-jakob",
      "image": "https://fw-landtag.de/fileadmin/_processed_/3/5/csm_Jakob_9cce55618e.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Dr. Georg Meiski",
      "role": "Beisitzer (Niederbayern)",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/georg-meiski"
    },
    {
      "name": "Frank Helmerich",
      "role": "Beisitzer",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/frank-helmerich",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/b/e/csm_Helmerich_Frank__e2cce06249.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Felix Stahl",
      "role": "Beisitzer",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/felix-stahl",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/0/5/csm_stahl_aef95a10f7.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Manfred Hümmer",
      "role": "Beisitzer",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/manfred-huemmer"
    },
    {
      "name": "Martina Purkhardt",
      "role": "Beisitzerin",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/martina-purkhardt"
    },
    {
      "name": "Felix Locke",
      "role": "Beisitzer",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/felix-locke",
      "image": "https://fw-landtag.de/fileadmin/_processed_/1/a/csm_Locke_6915689f71.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Florian Weber",
      "role": "Beisitzer (Schwaben, Landesverband)",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/florian-weber",
      "image": "https://www.fw-bayern.de/fileadmin/_processed_/c/e/csm_Florian_Weber_-_Lindenberg_im_Allg%C3%A4u_Foto_1_214dc72021.jpg",
      "imageSource": "FREIE WÄHLER Bayern"
    },
    {
      "name": "Thorsten Glauber",
      "role": "Beisitzer (Oberfranken, Landesverband)",
      "group": "land",
      "url": "https://www.fw-bayern.de/unser-landesverband/landesvorstand/thorsten-glauber",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/e/csm_Glauber_cd5df9774a.jpg",
      "imageSource": "FW-Landtagsfraktion"
    }
  ],
  "minister": [
    {
      "name": "Hubert Aiwanger",
      "role": "Bayerischer Staatsminister für Wirtschaft, Landesentwicklung und Energie und stellvertretender Ministerpräsident (2018–2026)",
      "group": "minister",
      "url": "https://www.stmwi.bayern.de/ministerium/trauer-um-hubert-aiwanger/",
      "image": "https://www.stmwi.bayern.de/fileadmin/_processed_/0/9/csm_Ministerium_StM_Aiwanger_1000x1000px_640c3cfa2c.png",
      "imageSource": "Bayerisches Wirtschaftsministerium (StMWi)",
      "memorial": true,
      "memorialDate": "2026-11-04",
      "memorialNote": "† 4. November 2026 · Dieser Eintrag bewahrt seine bisherige Funktion in Erinnerung, nicht als amtierendes Mandat."
    },
    {
      "name": "Anna Stolz",
      "role": "Bayerische Staatsministerin für Unterricht und Kultus",
      "group": "minister",
      "url": "https://fw-landtag.de/fraktion/mdl/anna-stolz",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/6/csm_Stolz_cd913e33b6.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Thorsten Glauber",
      "role": "Bayerischer Staatsminister für Umwelt und Verbraucherschutz",
      "group": "minister",
      "url": "https://fw-landtag.de/fraktion/mdl/thorsten-glauber",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/e/csm_Glauber_cd5df9774a.jpg",
      "imageSource": "FW-Landtagsfraktion"
    },
    {
      "name": "Dr. Fabian Mehring",
      "role": "Bayerischer Staatsminister für Digitales",
      "group": "minister",
      "url": "https://fw-landtag.de/fraktion/mdl/fabian-mehring",
      "image": "https://fw-landtag.de/fileadmin/_processed_/8/a/csm_Mehring_57aa67bbab.jpg",
      "imageSource": "FW-Landtagsfraktion"
    }
  ],
  "staatssekretaere": [
    {
      "name": "Tobias Gotthardt",
      "role": "Bayerischer Staatssekretär im Staatsministerium für Wirtschaft, Landesentwicklung und Energie; führt dort vorläufig die Amtsgeschäfte",
      "group": "staatssekretaere",
      "url": "https://www.stmwi.bayern.de/ministerium/staatssekretaer/",
      "image": "https://fw-landtag.de/fileadmin/_processed_/2/3/csm_Gotthardt_8b40767110.jpg",
      "imageSource": "FW-Landtagsfraktion"
    }
  ],
  "euabgeordnete": [
    {
      "name": "Christine Singer",
      "role": "Mitglied des Europäischen Parlaments · Renew Europe",
      "group": "euabgeordnete",
      "url": "https://www.europarl.europa.eu/meps/de/256946/CHRISTINE_SINGER/home",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Christine_Singer_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Engin Eroglu",
      "role": "Mitglied des Europäischen Parlaments · Renew Europe",
      "group": "euabgeordnete",
      "url": "https://www.europarl.europa.eu/meps/de/197430/ENGIN_EROGLU/home",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Engin_Eroglu_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    },
    {
      "name": "Dr. Joachim Streit",
      "role": "Mitglied des Europäischen Parlaments · Renew Europe",
      "group": "euabgeordnete",
      "url": "https://www.europarl.europa.eu/meps/de/256962/JOACHIM_STREIT/home",
      "image": "https://wp.freiewaehler.eu/wp-content/uploads/2025/08/Joachim_Streit_Kassel2025_QF.webp",
      "imageSource": "FREIE WÄHLER Bundesvereinigung"
    }
  ],
  "jfwbund": [
    {
      "name": "Georg Probst",
      "role": "Bundesvorsitzender",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Georg.jpeg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "David Gutzeit",
      "role": "Stellvertretender Bundesvorsitzender",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/David-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Marius Ackermann",
      "role": "Stellvertretender Bundesvorsitzender",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Marius-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Leonie Rother",
      "role": "Stellvertretende Bundesvorsitzende",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Leonie-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Pascal Georg",
      "role": "Stellvertretender Bundesvorsitzender",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Pascal-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Zuher Al-Korishy",
      "role": "Bundesgeschäftsführer",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/zuher_new.jpeg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Chris Daiser",
      "role": "Schriftführer",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Chris-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Michael Golling",
      "role": "Schatzmeister",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/michael_new.jpeg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Maximilian Eitner",
      "role": "Pressesprecher",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Max-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Marvin Klein",
      "role": "Medienreferent",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Marvin-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Lisa-Marie Jeckel",
      "role": "Justiziariat",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2025/01/IMG-20250128-WA0027.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Eva Maria Mack",
      "role": "Beisitzerin",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Eva-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "René Reiße",
      "role": "Beisitzer",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Rene.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Marcel Holzmann",
      "role": "Beisitzer",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/",
      "image": "https://www.junge-freie-waehler.de/wp-content/uploads/2026/10/Marcel-scaled.jpg",
      "imageSource": "JFW Deutschland"
    },
    {
      "name": "Noah Schmitt",
      "role": "Beisitzer",
      "group": "jfwbund",
      "url": "https://www.junge-freie-waehler.de/"
    }
  ],
  "jfwland": [
    {
      "name": "Maria Horn-Hörtrich",
      "role": "Landesvorsitzende",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/maria-horn-hoertrich-landesvorsitzende",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/d/2/csm_portrait_maria-horn-hoertrich_2026_466edacd4d.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Eva Maria Mack",
      "role": "Stellvertretende Landesvorsitzende",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/eva-maria-mack-stellv-landesvorsitzende",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/c/c/csm_portrait_eva-maria-mack_2026_31a06763bf.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Florian Mies",
      "role": "Stellvertretender Landesvorsitzender",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/florian-mies-stellv-landesvorsitzender",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/e/7/csm_portrait_florian-mies_2026_0abd936d3c.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Jacob Buys",
      "role": "Stellvertretender Landesvorsitzender",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/jacob-buys-stellv-landesvorsitzender",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/b/3/csm_portrait_jacob-buys_2026_55bfc95cd2.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Fabian Schmid",
      "role": "Stellvertretender Landesvorsitzender",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/fabian-schmid-stellv-landesvorsitzender",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/2/f/csm_portrait_fabian-schmid_2026_2ac4bbf356.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Julian Preidl",
      "role": "Generalsekretär",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/julian-preidl-generalsekretaer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/2/9/csm_portrait_julian-preidl_2026_4617b0d051.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Alexander Krauß",
      "role": "Schatzmeister",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/alexander-krauss-schatzmeister",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/5/3/csm_portrait_alexander-krauss_2026_bb698cc90d.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Milena Heisinger",
      "role": "Schriftführerin",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/milena-heisinger-schriftfuehrerin",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/7/0/csm_portrait_milena-heisinger_2026_2ec2d4b505.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Andreas Düthorn",
      "role": "Landesgeschäftsführer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/andreas-duethorn-landesgeschaeftsfuehrer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/d/4/csm_portrait_andreas-duethorn_2026_2ea038404c.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Thomas Gärtner",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/thomas-gaertner-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/b/8/csm_portrait_thomas-gaertner_2026_512858c835.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Manuel Spar",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/manuel-spar-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/f/0/csm_portrait_manuel-spar_2026_2eb024d295.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Elias Braun",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/elias-braun-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/8/f/csm_portrait_elias-braun_2026_420d6a6cb6.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Lorenz Höfler",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/lorenz-hoefler-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/7/f/csm_portrait_lorenz-hoefler_2026_008deb28e2.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Felix von Zobel",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/felix-von-zobel-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/5/e/csm_portrait_felix-von-zobel_2026_f5580f7bdf.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Michael Golling",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/michael-golling-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/8/0/csm_portrait_michael-golling_2026_aa526f4363.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Johannes Puschek",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/johannes-puschek-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/5/8/csm_portrait_johannes-puschek_2026_v2_411e472b51.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Mikka Ion Steinert",
      "role": "Beisitzer",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/mikka-ion-steinert-beisitzer",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/b/0/csm_portrait_mikka-ion-steinert_2026_a648cbf83b.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Max Vogl",
      "role": "Referent für neue Medien",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/max-vogl-referent-fuer-neue-medien",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/f/d/csm_portrait_max-vogl_2026_5291e88c1d.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Matthias Murr",
      "role": "Pressereferent",
      "group": "jfwland",
      "url": "https://www.jfw-bayern.de/vorstand/matthias-murr-pressereferent",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/4/3/csm_portrait_matthias-murr_2026_b59a64527e.jpg",
      "imageSource": "JFW Bayern"
    }
  ],
  "jfwbezirk": [
    {
      "name": "Florian Lichtenstern",
      "role": "Bezirksvorsitzender Oberbayern",
      "group": "jfwbezirk",
      "url": "https://www.jfw-bayern.de/bezirksvorsitzende/florian-lichtenstern-oberbayern",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/d/5/csm_Portrait_Florian_Lichtenstern_2024_v2_96971d3752.jpg",
      "imageSource": "JFW Bayern"
    },
    {
      "name": "Maria Horn-Hörtrich",
      "role": "Stellvertretende Bezirksvorsitzende Oberbayern",
      "group": "jfwbezirk",
      "url": "https://www.jfw-bayern.de/vorstand/maria-horn-hoertrich-landesvorsitzende",
      "image": "https://www.jfw-bayern.de/fileadmin/_processed_/d/2/csm_portrait_maria-horn-hoertrich_2026_466edacd4d.jpg",
      "imageSource": "JFW Bayern"
    }
  ],
  "jfwkreis": []
};
