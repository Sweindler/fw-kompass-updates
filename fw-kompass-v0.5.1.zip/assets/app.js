/** FW Kompass Pilot: Vanilla JS, no third-party analytics, no external libraries. */
const APP_VERSION='0.5.1';
const RELEASE_DATE='07.11.2026';
const ROUTES = [
  {id:'start',label:'Start',icon:'⌂',sub:'Dein Überblick'},
  {id:'wegweiser',label:'Wegweiser',icon:'◇',sub:'Wohin mit meiner Frage?'},
  {id:'news',label:'Aktuelles',icon:'▤',sub:'Bund, Bayern, Erding'},
  {id:'kontakte',label:'Ansprechpartner',icon:'♧',sub:'Finde die richtige Stelle'},
  {id:'termine',label:'Termine',icon:'▦',sub:'Veranstaltungen & Kalender'},
  {id:'wissen',label:'Wissen',icon:'▣',sub:'Organisation & Links'},
  {id:'einstieg',label:'Mein Einstieg',icon:'✓',sub:'Checkliste für Mitglieder'},
  {id:'info',label:'Über den Piloten',icon:'ⓘ',sub:'Hinweise & Quellen'}
];
const SOURCE_LINKS=[
  {label:'Bundesvereinigung',url:'https://www.freiewaehler.eu/bund/pressemitteilungen/'},
  {label:'Bayern',url:'https://www.fw-bayern.de/aktuelles/mitteilungen'},
  {label:'Landkreis Erding',url:'https://www.fw-landkreis-erding.de/aktuelles'}
];
const INTRO_STEPS = [
  ['Aufbau kennenlernen','Bundesvereinigung, Landesvereinigung und Kreisstrukturen unterscheiden.'],
  ['Meine lokale Anlaufstelle finden','Kontakt der Kreisvereinigung beziehungsweise örtlichen Gruppierung ansehen.'],
  ['Mitgliedschaft klären','Partei und kommunale Wählergemeinschaft nicht verwechseln.'],
  ['Aktuelle Informationsquellen öffnen','Regionale, bayerische und bundesweite Meldungen finden.'],
  ['Passenden Arbeitsbereich entdecken','Über ein Fachgremium oder ehrenamtliches Projekt informieren.'],
  ['Ersten Kontakt aufnehmen','Die zuständige Geschäftsstelle oder Ansprechperson kontaktieren.']
];
const PURPOSES={
  mitgliedschaft:{title:'Mitgliedschaft und Aufnahme',text:'Ob Du Mitglied der politischen Partei oder einer kommunalen Wählergemeinschaft werden möchtest, entscheidet, welche Organisation zuständig ist. Beginne im Landkreis bei der Kreisvereinigung beziehungsweise dem jeweiligen Ortsverein.',topics:['mitgliedschaft'],level:'erding'},
  ortsverband:{title:'Politik in meiner Gemeinde',text:'Die öffentlichen Websites der örtlichen Gruppen sind ein guter Einstieg. Nicht jede Ortsgruppe ist identisch mit einer Parteigliederung – bitte die Mitgliedsform erfragen.',topics:['ortsverband'],level:'erding'},
  gremien:{title:'In Fachgremien mitarbeiten',text:'Thematische Mitarbeit lässt sich auf der Landes- oder Bundesebene anfragen. Die Geschäftsstellen vermitteln zur aktuell zuständigen Leitung und klären Zugang und Mitwirkungsmöglichkeiten.',topics:['gremien'],level:'bayern'},
  presse:{title:'Presse und Öffentlichkeitsarbeit',text:'Für veröffentlichungsreife politische Statements ist die zuständige Presse-/Geschäftsstelle auf der entsprechenden Organisationsebene der richtige Startpunkt.',topics:['presse'],level:'bayern'},
  veranstaltung:{title:'Veranstaltung oder Sitzung organisieren',text:'Für lokale Veranstaltungen zuerst die Kreisgeschäftsstelle ansprechen. Überregionale Termine mit der betreffenden Landes- oder Bundesgeschäftsstelle abstimmen.',topics:['veranstaltung','termin'],level:'erding'},
  verwaltung:{title:'Satzungen und Verwaltung',text:'Formulare, Satzungen und Zuständigkeiten solltest Du immer über die aktuelle offizielle Geschäftsstelle oder die dort verlinkten Downloads prüfen.',topics:['verwaltung'],level:'erding'}
};
const LEVELS={all:'Alle Ebenen',erding:'Landkreis Erding',bayern:'Bayern',bund:'Bund'};
const LOCAL_KEY='fw-kompass-pilot-steps-v1';
const state={newsRefreshing:false,route:'start',newsLevel:'all',contactLevel:'all',contactQuery:'',guideTopic:'mitgliedschaft',guideLevel:'erding',guideTown:'',resourceQuery:'',newsQuery:'',data:{news:{metadata:{},articles:[]},contacts:[],regions:{towns:[]},resources:[]},loadError:false};
const $=s=>document.querySelector(s);
const esc=(value)=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const safeUrl=(url)=>{try{const value=new URL(String(url));return value.protocol==='https:'?value.href:'#';}catch{return '#';}};
const date=(d)=>{const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(d||'');return m?`${m[3]}.${m[2]}.${m[1]}`:esc(d||'');};
const external=(url,label,cl='text-link')=>`<a class="${cl}" href="${esc(safeUrl(url))}" target="_blank" rel="noopener noreferrer">${esc(label)} <span aria-hidden="true">↗</span></a>`;
const head=(kicker,title,subtitle)=>`<section class="section-intro"><div class="eyebrow">${esc(kicker)}</div><h1>${esc(title)}</h1><p>${esc(subtitle)}</p></section>`;
const sectionLine=(title,meta='')=>`<div class="section-line"><h2>${esc(title)}</h2>${meta?`<small>${esc(meta)}</small>`:''}</div>`;
const newArticle=a=>{if(!a.date)return false;const published=new Date(`${a.date}T12:00:00`);const age=Date.now()-published.getTime();return Number.isFinite(age)&&age>=0&&age<7*24*3600*1000;};
const newsCard=(a)=>`<article class="news-card"><div class="card-head"><span class="badgel ${esc(a.level)}">${esc(LEVELS[a.level]||a.level)}</span><div class="news-date">${newArticle(a)?'<span class="new-marker">NEU</span>':''}<time datetime="${esc(a.date)}" class="date">${date(a.date)}</time></div></div><h3>${esc(a.title)}</h3><p>${esc(a.excerpt||'')}</p>${external(a.url,'Zur offiziellen Quelle')}</article>`;
const contactCard=(c)=>`<article class="contact-card"><span class="badgel ${esc(c.level)}">${esc(LEVELS[c.level]||c.level)}</span><h3>${esc(c.name)}</h3><div class="contact-role">${esc(c.role)}</div><p style="margin-top:9px">${esc(c.organization)}</p><div class="actions">${external(c.url,'Kontaktseite','btn small')}${c.email?`<a href="mailto:${esc(c.email)}" class="btn small quiet">✉ E-Mail</a>`:''}</div>${c.note?`<div class="meta-line"><span>${esc(c.note)}</span></div>`:''}</article>`;
function introStatus(){let saved={};try{saved=JSON.parse(localStorage.getItem(LOCAL_KEY)||'{}')}catch{};return saved;}
function introCount(){return INTRO_STEPS.filter((_,i)=>introStatus()[i]).length;}
function nav(){
 const desktop=$('#side-nav'),mobile=$('#bottom-nav');
 desktop.innerHTML=ROUTES.map(r=>`<a class="nav-item ${state.route===r.id?'active':''}" href="#${r.id}" ${state.route===r.id?'aria-current="page"':''}><span class="nav-icon" aria-hidden="true">${r.icon}</span><span>${r.label}</span></a>`).join('');
 mobile.innerHTML=ROUTES.filter(r=>['start','wegweiser','news','kontakte','wissen'].includes(r.id)).map(r=>`<a class="nav-item ${state.route===r.id?'active':''}" href="#${r.id}" ${state.route===r.id?'aria-current="page"':''}><span class="nav-icon" aria-hidden="true">${r.icon}</span><span>${r.label}</span></a>`).join('');
 $('#crumb').textContent=ROUTES.find(r=>r.id===state.route)?.label||'Übersicht';
}
function start(){
 const articles=[...state.data.news.articles].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,2);
 const count=introCount();
 const tiles=ROUTES.filter(r=>['wegweiser','news','kontakte','termine','wissen','einstieg'].includes(r.id));
 return `<section class="hero"><div class="eyebrow">DEIN DIGITALER WEGWEISER</div><h1>Gut informiert.<br>Von Anfang an dabei.</h1><p>Wo finde ich Informationen? Wer hilft mir weiter? Wie kann ich mitmachen? Dein Einstieg bei den FREIEN WÄHLERN im Landkreis Erding – verständlich und an einem Ort.</p><div class="hero-actions"><a class="btn primary" href="#wegweiser">Wegweiser starten →</a><a class="btn" href="#einstieg">Meine ersten Schritte ✓</a></div></section>
 <div class="release-line"><span class="release-pill">FW Kompass · Version ${APP_VERSION}</span><span>Stand ${RELEASE_DATE} · Pilot Landkreis Erding</span></div>
 <div class="pwa-actions"><div class="pwa-card"><div class="pwa-card-title"><span class="pwa-emoji" aria-hidden="true">▣</span><div><h2>FW Kompass als App</h2><p>Auf dem Smartphone installieren und direkt vom Startbildschirm öffnen.</p></div></div><button class="btn primary full" type="button" id="install-app-btn">App installieren</button><p id="install-app-state" class="tiny" aria-live="polite">Installation über Chrome oder den Browser möglich.</p><div id="install-app-help" class="install-help" hidden><strong>So klappt die Installation:</strong><p><b>Android:</b> Öffne diese Seite direkt in Google Chrome (nicht im ChatGPT-internen Browser), tippe oben rechts auf ⋮ und wähle „App installieren“ oder „Zum Startbildschirm hinzufügen“.</p><p><b>iPhone:</b> In Safari auf Teilen und danach „Zum Home-Bildschirm“ tippen.</p><p>Wenn die Schaltfläche fehlt, prüfe die HTTPS-Adresse und versuche es direkt in Chrome. Je nach Gerät ist nur eine Startbildschirm-Verknüpfung möglich.</p></div></div>
 <div class="pwa-card"><div class="pwa-card-title"><span class="pwa-emoji" aria-hidden="true">↻</span><div><h2>Update-Service</h2><p>Prüft, ob auf dem Server eine neue Version bereitsteht.</p></div></div><div class="update-version">Installierte Webversion: <strong>v${APP_VERSION}</strong></div><p id="update-check-state" class="tiny" role="status">Update-Prüfung wird vorbereitet …</p><button class="btn full" type="button" id="check-app-updates">Jetzt nach Updates suchen</button><button class="btn full dark" type="button" id="apply-app-update" hidden>Neue Version installieren</button><p class="tiny">Browser-Updates werden automatisch erkannt. Neue Server-Versionen können im geschützten Verwaltungsbereich installiert werden.</p></div></div>
 <p class="admin-hint"><a href="./admin/updater.php" target="_blank" rel="noopener noreferrer">⚙ Verwaltung und Server-Updates (nur Betreiber) ↗</a></p>
 ${sectionLine('Was möchtest Du entdecken?','6 Bereiche')}
 <div class="tiles">${tiles.map(t=>`<a class="tile" href="#${t.id}"><span class="tile-icon">${t.icon}</span><strong>${esc(t.label)}</strong><small>${esc(t.sub)}</small></a>`).join('')}</div>
 ${sectionLine('Dein FW Kompass auf einen Blick')}
 <div class="split"><div class="panel"><div class="spread"><h2>Dein Einstieg</h2><span class="tag">${count} von ${INTRO_STEPS.length} Schritten</span></div><p>Mit unserer Checkliste behältst Du alles im Blick. Dein Fortschritt bleibt nur auf diesem Gerät gespeichert.</p><div class="progress-line"><div class="progress-fill" style="width:${count/INTRO_STEPS.length*100}%"></div></div><a href="#einstieg" class="text-link">Checkliste öffnen →</a></div>
 <div class="panel"><h2>Offizielle Nachrichtenquellen</h2><p>Aktuelles aus dem Landkreis, der Landes- und der Bundesvereinigung an einer Stelle finden.</p><div class="source-strip">${SOURCE_LINKS.map(s=>external(s.url,s.label,'btn small')).join('')}</div></div></div>
 ${sectionLine('Ausgewählte Meldungen',state.data.news.metadata?.mode==='rss-plus-curated'?'RSS und Redaktion':'Redaktioneller Demo-Bestand')}
 <div class="cards">${articles.map(newsCard).join('')||'<div class="empty">Noch keine Meldungen hinterlegt.</div>'}</div><div style="margin-top:14px"><a href="#news" class="text-link">Alle ausgewählten Meldungen ansehen →</a></div>`;
}
function guide(){
 const towns=state.data.regions.towns||[];
 return `${head('Dein Ansprechpartner-Finder','Wohin mit Deiner Frage?','Wähle Dein Anliegen und die zuständige Ebene. Der Kompass zeigt Dir den nächsten sinnvollen Schritt und offizielle Kontaktwege.')}
 <section class="panel"><div class="form-grid"><div class="field"><label for="guide-topic">Was möchtest Du tun?</label><select id="guide-topic">${Object.entries(PURPOSES).map(([key,v])=>`<option value="${key}" ${state.guideTopic===key?'selected':''}>${esc(v.title)}</option>`).join('')}</select></div><div class="field"><label for="guide-level">Auf welcher Ebene?</label><select id="guide-level">${Object.entries(LEVELS).filter(([key])=>key!=='all').map(([key,v])=>`<option value="${key}" ${state.guideLevel===key?'selected':''}>${esc(v)}</option>`).join('')}</select></div><div class="field"><label for="guide-town">Mein Ort (optional)</label><select id="guide-town"><option value="">Keine Ortsauswahl</option>${towns.map(t=>`<option value="${esc(t.name)}" ${state.guideTown===t.name?'selected':''}>${esc(t.name)}</option>`).join('')}</select></div></div><p class="tiny">Hinweis: Vorschläge dienen der Orientierung und ersetzen keine bestätigte Zuständigkeitsauskunft der Organisation.</p></section>
 <div id="guide-result">${guideResult()}</div>`;
}
function guideResult(){
 const p=PURPOSES[state.guideTopic]||PURPOSES.mitgliedschaft;
 const level=state.guideLevel;
 const contacts=state.data.contacts.filter(c=>c.level===level&&(c.topics||[]).some(x=>p.topics.includes(x)));
 const fallback=state.data.contacts.filter(c=>c.level===level).slice(0,2);
 const matches=contacts.length?contacts:fallback;
 const town=state.data.regions.towns.find(x=>x.name===state.guideTown);
 let townLine='';
 if(town){townLine=town.website?`<p><strong>Dein Ort:</strong> ${esc(town.name)} – ${external(town.website,'örtliche Website öffnen')}.</p>`:`<p><strong>Dein Ort:</strong> ${esc(town.name)} – im Demo-Datenbestand ist noch keine bestätigte Ortswebsite eingetragen. Bitte direkt beim Kreisverband nachfragen.</p>`;}
 return `<section class="result"><div class="eyebrow">DEINE ORIENTIERUNG</div><h2>${esc(p.title)}</h2><p>${esc(p.text)}</p>${townLine}<div class="meta-line"><span>Gewählte Ebene: ${esc(LEVELS[level])}</span><span>Zuletzt geprüfte Links: November 2026</span></div></section>
 ${sectionLine('Passende Anlaufstellen')}
 <div class="cards">${matches.length?matches.map(contactCard).join(''):'<div class="empty">Für dieses Anliegen ist noch kein einzelner Ansprechpartner bestätigt. Nutze bitte die zentrale Geschäftsstelle der gewählten Ebene.</div>'}</div>
 ${sectionLine('Noch nicht sicher?')}<div class="padded-note">Für eine rein kommunale Wählergemeinschaft ist nicht automatisch die Parteikreisvereinigung zuständig. Kläre zuerst, welcher Organisation Deine Mitgliedschaft oder Dein Vorhaben zugeordnet ist.</div>`;
}
function sortedNews(){return [...(state.data.news.articles||[])].filter(a=>(state.newsLevel==='all'||a.level===state.newsLevel)&&(`${a.title||''} ${a.excerpt||''} ${a.source||''}`.toLocaleLowerCase('de-DE').includes(state.newsQuery.trim().toLocaleLowerCase('de-DE')))).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||(a.title||'').localeCompare(b.title||''));}
function newsStatus(){
 const meta=state.data.news.metadata||{};
 const mode=meta.mode||'curated-demo';
 const live=(mode==='rss-plus-curated'||mode==='rss-active');
 const count=meta.feedCount||0;
 if(live)return `<div class="alert news-status" role="status"><strong><span class="status-dot" style="background:#338d64"></span>${count} geprüfte Nachrichtenquelle${count===1?'':'n'} automatisch eingebunden</strong><p>Letzter erfolgreicher Abruf: ${esc(meta.lastSuccessfulAt||'nicht bekannt')} · Zusätzlich können redaktionelle Meldungen enthalten sein. ${meta.failedFeeds?'Einige Quellen konnten nicht aktualisiert werden.':''}</p></div>`;
 return `<div class="alert orange news-status" role="status"><strong><span class="status-dot"></span>Redaktionell gepflegte Demo · Stand ${date(meta.updatedAt)}</strong><p>Keine automatische Synchronisation aktiv. Aktuelle Meldungen bitte über die offiziellen Quellen öffnen.</p></div>`;
}
function news(){
 const articles=sortedNews();
 return `${head('Informiert bleiben','Aktuelles aus drei Ebenen','Bundesweite, bayerische und regionale Nachrichten – mit direktem Link zum Original.')}
 ${newsStatus()}
 <div class="news-tools"><div class="filters" id="news-filters" role="group" aria-label="Nachrichtenebene">${Object.entries(LEVELS).map(([key,v])=>`<button type="button" data-news-level="${key}" class="chip ${state.newsLevel===key?'active':''}" aria-pressed="${state.newsLevel===key}">${esc(v)}</button>`).join('')}</div>
 <label class="news-search-label" for="news-search">Meldungen durchsuchen</label><div class="news-search-row"><div class="news-search-wrap"><span aria-hidden="true">⌕</span><input id="news-search" aria-label="Nachrichten durchsuchen" type="search" placeholder="Suchbegriff eingeben …" value="${esc(state.newsQuery)}" autocomplete="off"></div><button type="button" class="btn news-refresh" id="news-reload" ${state.newsRefreshing?'disabled':''}>↻ ${state.newsRefreshing?'Lädt …':'Aktualisieren'}</button></div></div>
 <div class="news-list-meta" id="news-result-count" role="status">${articles.length} ${articles.length===1?'Meldung':'Meldungen'} · Neueste zuerst</div>
 <div class="cards" id="news-list">${articles.length?articles.map(newsCard).join(''):'<div class="empty">Keine Meldungen gefunden. Filter oder Suchbegriff ändern.</div>'}</div>
 ${sectionLine('Aktuelle Veröffentlichungen direkt lesen')}
 <p class="tiny source-help">Diese Links führen zu den offiziellen Websites. Dort findest Du immer die aktuell veröffentlichten Meldungen – unabhängig vom Demo-Bestand im FW Kompass.</p>
 <div class="source-strip news-sources">${SOURCE_LINKS.map(s=>external(s.url,s.label,'btn')).join('')}</div>`;
}
function contacts(){
 const filtered=state.data.contacts.filter(c=>(state.contactLevel==='all'||c.level===state.contactLevel)&&(`${c.name} ${c.role} ${c.organization}`.toLowerCase().includes(state.contactQuery.toLowerCase())));
 return `${head('Menschen & Stellen','Ansprechpartner finden','Hier stehen nur öffentlich belegte Kontakte beziehungsweise offizielle Geschäftsstellen. Bitte Änderungen vor der Veröffentlichung mit den jeweiligen Organisationen abgleichen.')}
 <div class="spread" style="margin-bottom:17px"><div class="filters" id="contact-filters">${Object.entries(LEVELS).map(([key,v])=>`<button type="button" data-contact-level="${key}" class="chip ${state.contactLevel===key?'active':''}" aria-pressed="${state.contactLevel===key}">${esc(v)}</button>`).join('')}</div><div class="searchbox"><input type="search" id="contact-search" placeholder="Name oder Funktion suchen …" aria-label="Kontakte durchsuchen" value="${esc(state.contactQuery)}"></div></div>
 <div class="cards" id="contact-list">${filtered.length?filtered.map(contactCard).join(''):'<div class="empty">Keine Kontakte gefunden.</div>'}</div>`;
}
function events(){
 return `${head('Termine & Begegnungen','Dabei sein und mitmachen','Für lokale Termine verlinken wir die offizielle Kreisübersicht. In der ersten Pilotversion veröffentlichen wir keine unbestätigten Veranstaltungen.')}
 <div class="panel"><div class="eyebrow">TERMINKALENDER</div><h2 style="font-size:21px;margin-top:10px">Veranstaltungen aus offiziellen Quellen</h2><p>Auf den unten verlinkten Kalenderseiten kannst Du die jeweils aktuellen Termine prüfen. Später können hier freigegebene Kalender automatisch zusammengestellt werden.</p><div class="source-strip">${external('https://www.fw-landkreis-erding.de/veranstaltungen','Landkreis Erding','btn')}${external('https://www.fw-bayern.de','Bayern','btn')}${external('https://www.freiewaehler.eu/','Bundesvereinigung','btn')}</div></div>
 ${sectionLine('So soll die Terminverwaltung später funktionieren')}
 <div class="steps"><div class="step"><b>1</b><span>Lokale Veranstaltung durch die Kreisredaktion eintragen oder freigegebenen Veranstaltungskalender anbinden.</span></div><div class="step"><b>2</b><span>Termine erhalten Region, Veranstalter, Datum, Zeit, Ort und Teilnahmehinweise.</span></div><div class="step"><b>3</b><span>Im Kompass erscheinen sie passend zum gewählten Landkreis und auf Wunsch im persönlichen Kalender.</span></div></div>`;
}
function knowledge(){
 const r=state.data.resources.filter(x=>`${x.title} ${x.description} ${x.category}`.toLowerCase().includes(state.resourceQuery.toLowerCase()));
 return `${head('Die Organisation verstehen','Wissen & wichtige Links','Die wichtigsten Fragen zum Start, dazu geprüfte Einstiegspunkte zu offiziellen Dokumenten und Arbeitsbereichen.')}
 <div class="stack">
 <details class="accordion" open><summary>Was ist der Unterschied zwischen Partei und kommunaler Wählergemeinschaft?</summary><div><p>Die <strong>FREIEN WÄHLER als Partei</strong> sind in einer politischen Organisation von der Bundes- bis zur lokalen Ebene strukturiert. <strong>Kommunale Wählergemeinschaften und Vereine</strong> treten besonders in Gemeinden und Landkreisen auf; sie können organisatorisch eigenständig sein. Ein Vereinsbeitritt ist daher nicht automatisch ein Parteibeitritt. Im Landkreis Erding führt die Website Kreisvereinigung und Freie Wählerschaft ausdrücklich getrennt.</p></div></details>
 <details class="accordion"><summary>Wie ist der Weg von meinem Ort bis zur Bundesebene?</summary><div><p>Die Orientierung läuft über örtliche Gruppierungen oder Parteigliederungen, Kreisorganisation, Bezirks- und Landesebene bis zur Bundesvereinigung. Zuständigkeiten und Mitgliedsrechte richten sich nach der konkreten Organisation und ihren aktuellen Satzungen.</p></div></details>
 <details class="accordion"><summary>Wie kann ich mich in einem Fachgremium engagieren?</summary><div><p>Suche zunächst Deinen Themenbereich, zum Beispiel Soziales, Gesundheit, Wirtschaft oder Bildung. Nimm über die zuständige Landes- beziehungsweise Bundesgeschäftsstelle Kontakt auf und frage nach der aktuellen Struktur und Teilnahmevoraussetzungen.</p></div></details>
 <details class="accordion"><summary>Wer pflegt Inhalte und Kontakte im Kompass?</summary><div><p>Im Pilot werden Inhalte über JSON-Dateien redaktionell gepflegt. Für einen offiziellen Ausbau empfehlen sich Rollen für Kreis-, Landes- und Bundesredaktion mit Freigabeprozess und Änderungsprotokoll.</p></div></details>
 </div>
 ${sectionLine('Offizielle Dokumente & Websites')}
 <div class="searchbox" style="max-width:100%;margin-bottom:16px"><input id="resource-search" aria-label="Wissensbereich durchsuchen" placeholder="Links und Themen suchen …" type="search" value="${esc(state.resourceQuery)}"></div>
 <div class="cards" id="resource-list">${r.length?r.map(x=>`<article class="resource-card"><span class="badgel">${esc(x.category)}</span><h3>${esc(x.title)}</h3><p>${esc(x.description)}</p>${external(x.url,'Offizielle Website öffnen')}</article>`).join(''):'<div class="empty">Keine Links gefunden.</div>'}</div>
 ${sectionLine('Lokale Gruppierungen im Landkreis Erding')}
 <p class="muted" style="font-size:13px">Öffentlich gelistete Websites; nicht jede Gruppierung muss ein Parteiorgan sein.</p>
 <div class="source-strip">${state.data.regions.towns.map(t=>t.website?external(t.website,t.name,'btn small'):`<span class="btn small quiet" title="Keine verifizierte Ortswebsite hinterlegt">${esc(t.name)} · Kreis kontaktieren</span>`).join('')}</div>`;
}
function onboarding(){
 const saved=introStatus(),count=introCount();
 return `${head('Für neue Mitglieder','Deine ersten Schritte','Hake ab, was Du bereits erledigt hast. Die Angaben bleiben ausschließlich in Deinem Browser auf diesem Gerät.')}
 <div class="panel" style="margin-bottom:15px"><div class="spread"><div><h2>Dein persönlicher Start</h2><span class="tiny">${count} von ${INTRO_STEPS.length} erledigt</span></div><span class="tag">${Math.round(count/INTRO_STEPS.length*100)} %</span></div><div class="progress-line"><div class="progress-fill" style="width:${count/INTRO_STEPS.length*100}%"></div></div></div>
 <div class="checklist">${INTRO_STEPS.map(([title,desc],i)=>`<label class="check-item"><input type="checkbox" data-step="${i}" ${saved[i]?'checked':''}><span><strong>${esc(title)}</strong><small>${esc(desc)}</small></span></label>`).join('')}</div>
 <div class="actions" style="margin-top:16px"><button id="clear-steps" class="btn quiet" type="button">Checkliste zurücksetzen</button><a href="#wegweiser" class="btn primary">Passenden Kontakt suchen →</a></div>`;
}
function info(){
 return `${head('Transparenz','Über den FW Kompass','Die erste umsetzbare Projektversion für den Landkreis Erding. Technisch bundesweit erweiterbar, derzeit eine nicht offizielle Demo.')}
 <div class="stack"><div class="panel"><h2>Was funktioniert bereits?</h2><ul class="bullets"><li>Responsives Design mit Navigation für Smartphone, Tablet und PC</li><li>Interaktiver Anliegen-Wegweiser mit Ebenen- und Ortsauswahl</li><li>Filterbare Kontaktübersicht, mit Links und E-Mail-Aktionen</li><li>Nachrichten mit Bundes-, Landes- und Landkreisfilter sowie Volltextsuche über den Demo-Bestand</li><li>Wissensbereich, öffentliche Ortslinks und lokale Einführung-Checkliste</li><li>Installationshilfe für Android und iPhone, Versionsanzeige und Update-Prüfung über den eigenen Server</li><li>Offline-Grundfunktionen nach erfolgter Installation und erstem Laden über HTTPS</li></ul></div>
 <div class="panel"><h2>Was ist noch nicht aktiv?</h2><p><strong>Automatischer News-Import:</strong> Noch keine bestätigte und freigegebene RSS-/API-Schnittstelle. Aktuell stehen ausgewählte, auf offiziellen Websites nachgelesene Meldungen in <code>data/news.json</code>. Der Server-Endpunkt <code>api/news.php</code> kann nach Konfiguration und Freigabe einen RSS-Feed einlesen. Termine werden derzeit nur verlinkt, nicht automatisiert.</p><p><strong>Mitglieder-Login:</strong> Bewusst nicht Bestandteil der Demo. Keine Mitgliederlisten, Nutzerkonten oder Tracking-Dienste.</p></div>
 <div class="panel"><h2>Offizielle Ausgangsquellen</h2><div class="source-strip">${SOURCE_LINKS.map(s=>external(s.url,s.label,'btn')).join('')}${external('https://www.fw-landkreis-erding.de/kontakt','Kontakt Erding','btn')}${external('https://www.freiewaehler.eu/services/kontakt/','Kontakt Bund','btn')}</div></div>
 <div class="padded-note">Für den späteren Einsatz durch die Organisation: offizielle Freigabe der Bezeichnung und Markenverwendung, Redaktion und Verantwortung klären, Datenschutz/Impressum ergänzen, Kontaktangaben regelmäßig prüfen und Übernahmen externer Inhalte rechtlich sowie technisch abstimmen.</div></div>`;
}
function draw(){
 const hash=location.hash.slice(1).toLowerCase();state.route=ROUTES.some(r=>r.id===hash)?hash:'start';nav();
 const views={start,wegweiser:guide,news,kontakte:contacts,termine:events,wissen:knowledge,einstieg:onboarding,info};
 $('#view').innerHTML=(state.loadError?'<div class="alert orange">Einige lokale Datendateien konnten nicht geladen werden. Bitte die App über HTTPS oder einen lokalen Webserver öffnen – nicht direkt mit file://.</div>':'')+views[state.route]();
 wire();
}
function wire(){
 if(state.route==='start'){
  const install=$('#install-app-btn'); if(install)install.addEventListener('click',installApp);
  $('#check-app-updates')?.addEventListener('click',()=>checkForUpdate(true));
  $('#apply-app-update')?.addEventListener('click',applyUpdate);
  updateUi();
 }
 if(state.route==='news'){
  document.querySelectorAll('[data-news-level]').forEach(btn=>btn.addEventListener('click',()=>{state.newsLevel=btn.dataset.newsLevel;draw();}));
  $('#news-search').addEventListener('input',event=>{state.newsQuery=event.target.value;updateNewsList();});
  $('#news-reload').addEventListener('click',async()=>{
   if(state.newsRefreshing)return;state.newsRefreshing=true;$('#news-reload').disabled=true;$('#news-reload').textContent='↻ Lädt …';
   try{const response=await fetch('./api/news.php?client_reload='+Date.now(),{cache:'no-store'});if(!response.ok)throw new Error('HTTP '+response.status);const fresh=await response.json();if(!fresh||!Array.isArray(fresh.articles))throw new Error('Keine gültigen Nachrichten');state.data.news=fresh;}
   catch(e){try{const response=await fetch('./data/news.json?client_reload='+Date.now(),{cache:'no-store'});if(!response.ok)throw new Error('HTTP '+response.status);const fallback=await response.json();if(!fallback||!Array.isArray(fallback.articles))throw new Error();state.data.news=fallback;}catch(err){console.warn('Keine neue Nachrichtenliste verfügbar',e,err);}}
   finally{state.newsRefreshing=false;draw();}
  });
 }
 if(state.route==='kontakte'){
  document.querySelectorAll('[data-contact-level]').forEach(btn=>btn.addEventListener('click',()=>{state.contactLevel=btn.dataset.contactLevel;draw();}));
  $('#contact-search').addEventListener('input',event=>{state.contactQuery=event.target.value;updateContactList();});
 }
 if(state.route==='wissen'){$('#resource-search').addEventListener('input',event=>{state.resourceQuery=event.target.value;updateResourceList();});}
 if(state.route==='wegweiser'){
  ['topic','level','town'].forEach(key=>$('#guide-'+key).addEventListener('change',e=>{state['guide'+key[0].toUpperCase()+key.slice(1)]=e.target.value;$('#guide-result').innerHTML=guideResult();}));
 }
 if(state.route==='einstieg'){
  document.querySelectorAll('[data-step]').forEach(input=>input.addEventListener('change',e=>{const values=introStatus();values[e.target.dataset.step]=e.target.checked;try{localStorage.setItem(LOCAL_KEY,JSON.stringify(values));}catch{}draw();}));
  $('#clear-steps').addEventListener('click',()=>{if(confirm('Deine Checkliste wirklich zurücksetzen?')){try{localStorage.removeItem(LOCAL_KEY);}catch{}draw();}});
 }
}
function updateNewsList(){const articles=sortedNews();$('#news-list').innerHTML=articles.length?articles.map(newsCard).join(''):'<div class="empty">Keine Meldungen gefunden.</div>';$('#news-result-count').textContent=`${articles.length} ${articles.length===1?'Meldung':'Meldungen'} · Neueste zuerst`; }
function updateContactList(){const contacts=state.data.contacts.filter(c=>(state.contactLevel==='all'||c.level===state.contactLevel)&&(`${c.name} ${c.role} ${c.organization}`.toLowerCase().includes(state.contactQuery.toLowerCase())));$('#contact-list').innerHTML=contacts.length?contacts.map(contactCard).join(''):'<div class="empty">Keine Kontakte gefunden.</div>';}
function updateResourceList(){const r=state.data.resources.filter(x=>`${x.title} ${x.description} ${x.category}`.toLowerCase().includes(state.resourceQuery.toLowerCase()));$('#resource-list').innerHTML=r.length?r.map(x=>`<article class="resource-card"><span class="badgel">${esc(x.category)}</span><h3>${esc(x.title)}</h3><p>${esc(x.description)}</p>${external(x.url,'Offizielle Website öffnen')}</article>`).join(''):'<div class="empty">Keine Links gefunden.</div>';}
async function dataFetch(path,fallBack){try{const res=await fetch(path,{cache:'no-cache'});if(!res.ok)throw new Error(`HTTP ${res.status}`);return await res.json()}catch(e){state.loadError=true;console.warn('FW Kompass Daten konnten nicht geladen werden',path,e);return fallBack;}}
// --- PWA-Installation und selbst gehosteter Update-Service v0.3 ---
// Es gibt keine Mitglieder-Accounts und keine Push-Überwachung. Die Prüfung erfolgt nur,
// wenn die App läuft (beim Start, Wiederöffnen, Onlinegehen und alle 15 Minuten).
let installPrompt=null;
let installedMode=window.matchMedia('(display-mode: standalone)').matches || navigator.standalone===true;
let registration=null;
let availableUpdate=null;
let checking=false;
let lastChecked='Noch nicht geprüft';
let updateMessage='';
let dismissForVersion=null;
const UPDATE_PERIOD_MS=15*60*1000;
const sameVersion=(a,b)=>String(a||'').trim()===String(b||'').trim();
function newerVersion(latest,current){
 const parse=s=>/^\d+\.\d+\.\d+$/.test(s)?s.split('.').map(Number):null;
 const a=parse(latest),b=parse(current);if(!a||!b)return false;
 for(let i=0;i<3;i++){if(a[i]>b[i])return true;if(a[i]<b[i])return false;}return false;
}
function updateUi(){
 const installButton=$('#install-app-btn');
 if(installButton){installButton.disabled=installedMode;installButton.textContent=installedMode?'Bereits installiert':'App installieren';}
 const install=$('#install-app-state');
 if(install)install.textContent=installedMode?'Die App läuft bereits im installierten Modus.':installPrompt?'Dein Browser bietet die direkte Installation an.':'Keine direkte Installationsabfrage verfügbar? Der Knopf zeigt Dir die manuellen Schritte.';
 const checker=$('#update-check-state');
 if(checker)checker.textContent=checking?'Suche nach Updates …':availableUpdate?(availableUpdate.version==='neu'?'Ein Browser-Update ist verfügbar.':`Version v${availableUpdate.version} ist verfügbar. ${availableUpdate.notes||''}`):updateMessage||`Installierte Webversion v${APP_VERSION} · ${lastChecked}`;
 const apply=$('#apply-app-update');
 if(apply)apply.hidden=!availableUpdate;
 const banner=$('#update-banner');
 if(banner){
  banner.hidden=!availableUpdate||dismissForVersion===availableUpdate.version;
  if(!banner.hidden)$('#update-banner-text').textContent=availableUpdate.version==='neu'?'Eine neue Browser-Version der App ist bereit.':`Version v${availableUpdate.version} ist bereit. Du kannst jetzt aktualisieren.`;
 }
}
function showInstallHelp(){
 const help=$('#install-app-help');
 if(help){help.hidden=false;help.scrollIntoView({block:'nearest',behavior:'smooth'});}
}
async function installApp(){
 if(installedMode){showInstallHelp();return;}
 if(!installPrompt){showInstallHelp();return;}
 const prompt=installPrompt;installPrompt=null;
 try{await prompt.prompt();await prompt.userChoice;}catch(e){console.warn('Installationsdialog nicht verfügbar',e);showInstallHelp();}
 updateUi();
}
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installPrompt=event;updateUi();});
window.addEventListener('appinstalled',()=>{installedMode=true;installPrompt=null;updateUi();});
function watchRegistration(reg){
 registration=reg;
 const inspect=()=>{
  if(reg.waiting && navigator.serviceWorker.controller){
   if(!availableUpdate)availableUpdate={version:'neu',notes:'Eine App-Aktualisierung wurde vom Browser geladen.'};
   updateUi();
  }
 };
 inspect();
 reg.addEventListener('updatefound',()=>{
  const worker=reg.installing;if(!worker)return;
  worker.addEventListener('statechange',()=>{if(worker.state==='installed')inspect();});
 });
}
let waitingForControlledUpdate=false;
if('serviceWorker' in navigator){
 navigator.serviceWorker.addEventListener('controllerchange',()=>{
  if(waitingForControlledUpdate){waitingForControlledUpdate=false;window.location.reload();}
 });
}
async function retrieveRelease(){
 for(const source of ['./api/version.php','./release.json']){
  try{
   const url=source+'?t='+Date.now();
   const response=await fetch(url,{cache:'no-store',headers:{'Accept':'application/json'}});
   if(!response.ok)continue;
   const obj=await response.json();
   if(/^\d+\.\d+\.\d+$/.test(String(obj.version||'')))return obj;
  }catch(e){/* PHP may be unavailable; static JSON still works. */}
 }
 throw new Error('Versionsdatei nicht erreichbar');
}
async function checkForUpdate(manual=false){
 if(checking)return;
 checking=true;if(manual)updateMessage='';updateUi();
 try{
  const release=await retrieveRelease();
  lastChecked=`Zuletzt geprüft: ${new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})}`;
  if(newerVersion(release.version,APP_VERSION)){
   availableUpdate={version:release.version,notes:typeof release.notes==='string'?release.notes.slice(0,180):''};
   updateMessage='Neue Version bereit';
   if(registration)await registration.update().catch(()=>{});
  } else {
   if(!availableUpdate||availableUpdate.version!=='neu')availableUpdate=null;
   updateMessage=`Du nutzt Version v${APP_VERSION}. Alles aktuell. ${lastChecked}`;
  }
 }catch(e){updateMessage=`Update-Prüfung nicht möglich (offline oder Versionsdatei nicht erreichbar). ${lastChecked}`;}
 finally{checking=false;updateUi();}
}
async function applyUpdate(){
 if(!availableUpdate)return;
 updateMessage='Update wird vorbereitet …';updateUi();
 try{
  if(registration){
   await registration.update();
   if(registration.waiting){
    waitingForControlledUpdate=true;
    registration.waiting.postMessage({type:'SKIP_WAITING'});
    // controllerchange triggers reload; avoid forced refresh before the worker is active.
    return;
   }
  }
  // Without a waiting worker the browser may need another start after the upload.
  // This reload uses a cache-busted URL so HTML is retrieved afresh.
  window.location.href='./index.html?updated='+Date.now()+window.location.hash;
 }catch(e){updateMessage='Aktualisierung fehlgeschlagen. Bitte erneut prüfen oder die Seite in Chrome neu laden.';updateUi();}
}
$('#update-banner-go')?.addEventListener('click',applyUpdate);
$('#update-banner-later')?.addEventListener('click',()=>{dismissForVersion=availableUpdate?.version||null;updateUi();});
function setupPwa(){
 if('serviceWorker' in navigator && location.protocol==='https:'){
  navigator.serviceWorker.register('./sw.js',{scope:'./',updateViaCache:'none'})
   .then(watchRegistration).catch(error=>console.warn('Service Worker konnte nicht registriert werden',error));
 }
 checkForUpdate();
 setInterval(()=>{if(!document.hidden)checkForUpdate();},UPDATE_PERIOD_MS);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)checkForUpdate();});
 window.addEventListener('online',()=>checkForUpdate());
}

async function init(){
 if(window.__FW_DATA__){state.data=window.__FW_DATA__;window.addEventListener('hashchange',()=>{draw();window.scrollTo(0,0);});draw();setupPwa();return;}
 const [news,contacts,regions,resources]=await Promise.all([
  dataFetch('./api/news.php',{metadata:{},articles:[]}),
  dataFetch('./data/contacts.json',[]),dataFetch('./data/regions.json',{towns:[]}),dataFetch('./data/resources.json',[])
 ]);
 // Static hosts without PHP should use news.json. A PHP host returns JSON from api/news.php.
 let result=news;
 if(state.loadError||!Array.isArray(news.articles)){state.loadError=false;result=await dataFetch('./data/news.json',{metadata:{},articles:[]});}
 state.data={news:result,contacts,regions,resources};
 window.addEventListener('hashchange',()=>{draw();window.scrollTo({top:0,behavior:'instant'});});
 draw();
 setupPwa();
}
init();

/* FW Kompass v0.4 – zeigt das unveränderte Original-Logo nur, wenn es unter assets/fw-logo-offiziell.png abgelegt ist. */
for(const logo of document.querySelectorAll('.fw-official-logo')){
 const show=()=>logo.parentElement?.classList.add('logo-ready');
 const hide=()=>logo.parentElement?.classList.remove('logo-ready');
 logo.addEventListener('load',show);logo.addEventListener('error',hide);
 if(logo.complete && logo.naturalWidth>0)show();
}
