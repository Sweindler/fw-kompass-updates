/* FW Kompass – v1.2.1: consent-based app updates, network-first HTML and live content */
const CACHE='fw-kompass-pilot-v1.2.1';
const CORE=['./index.html','./assets/style.css?v=1.2.1','./assets/app.js?v=1.2.1','./assets/push.js?v=1.2.1',
 './manifest.json?v=1.2.1','./icons/icon-192.png','./icons/icon-512.png','./icons/maskable-512.png',
 './assets/fw-logo-offiziell.png?v=1.2.1','./assets/who.js?v=1.2.1','./assets/gremien.js?v=1.2.1','./assets/ortsvereine.js?v=1.2.1','./data/news.json','./data/contacts.json','./data/regions.json','./data/resources.json'];
self.addEventListener('install', event=>event.waitUntil((async()=>{
 const cache=await caches.open(CACHE);
 await cache.addAll(CORE);
 if(!self.registration.active)await self.skipWaiting(); // first installation only
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 const keys=await caches.keys();
 await Promise.all(keys.filter(k=>k.startsWith('fw-kompass-pilot-')&&k!==CACHE).map(k=>caches.delete(k)));
 await self.clients.claim();
})()));
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING')self.skipWaiting();});
self.addEventListener('fetch',event=>{
 const request=event.request;if(request.method!=='GET')return;
 const url=new URL(request.url);
 if(url.origin!==self.location.origin||!url.pathname.startsWith(new URL(self.registration.scope).pathname))return;
 // Do not intercept admin pages or private paths: the updater must always reach PHP directly.
 if(/\/admin\//.test(url.pathname)||/\/\.fw-private\//.test(url.pathname))return;
 // Do not cache the version endpoints: otherwise the update checker can get false 'latest' values.
 if(/\/api\/version\.php$/.test(url.pathname)||/\/release\.json$/.test(url.pathname)){
  event.respondWith(fetch(request,{cache:'no-store'}));return;
 }
 if(request.mode==='navigate'){
  event.respondWith((async()=>{
   try {const response=await fetch(request,{cache:'no-store'});return response;}
   catch {return (await caches.match('./index.html'))||Response.error();}
  })());return;
 }
 if(/\/api\/news\.php$/.test(url.pathname)||/\/data\/.*\.json$/.test(url.pathname)){
  event.respondWith((async()=>{
   try {const response=await fetch(request,{cache:'no-store'});return response;}
   catch {return (await caches.match(request,{ignoreSearch:true}))||(await caches.match('./data/news.json'))||Response.error();}
  })());return;
 }
 event.respondWith((async()=>{
  const cached=await caches.match(request);if(cached)return cached;
  const fresh=await fetch(request);if(fresh.ok){const c=await caches.open(CACHE);c.put(request,fresh.clone());}
  return fresh;
 })());
});

/* Version 1.1: show decrypted Web Push notifications (never silent data pushes). */
self.addEventListener('push',event=>{
 event.waitUntil((async()=>{
  let payload={};try{if(event.data)payload=event.data.json();}catch{payload={};}
  const title=String(payload.title||'FW Kompass').slice(0,90);
  const body=String(payload.body||'Neue Mitteilung verfügbar.').slice(0,240);
  const link=/^#[a-z-]{2,32}$/.test(String(payload.link||''))?payload.link:'#mitteilungen';
  await self.registration.showNotification(title,{body,icon:'./icons/icon-192.png',badge:'./icons/icon-192.png',tag:'fw-kompass-'+String(payload.category||'hinweis'),data:{link}});
 })());
});
self.addEventListener('notificationclick',event=>{
 event.notification.close();
 event.waitUntil((async()=>{
  const link=String(event.notification.data?.link||'#mitteilungen');
  const target=new URL('./'+(/^#[a-z-]{2,32}$/.test(link)?link:'#mitteilungen'),self.registration.scope).href;
  const windows=await self.clients.matchAll({type:'window',includeUncontrolled:true});
  for(const windowClient of windows){
   if(new URL(windowClient.url).origin===self.location.origin){await windowClient.navigate(target);return windowClient.focus();}
  }
  return self.clients.openWindow(target);
 })());
});
