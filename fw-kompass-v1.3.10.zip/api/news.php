<?php
/** FW Kompass v1.3.10 – stabile geschuetzte Admin-Anmeldung und quellenspezifische Pruefung beim Wechsel der Nachrichtenfilter.
 * Keine offenen Proxy-URLs, keine Besucherkennungen, keine Volltext-/Bildkopien.
 */
declare(strict_types=1);
$FW_ROOT = dirname(__DIR__);
$FW_PRIVATE = $FW_ROOT.'/.fw-private';
$FW_CONFIG = $FW_PRIVATE.'/sync-config.json';
$FW_CACHE = $FW_PRIVATE.'/news-sync-cache.json';
$FW_LOCK = $FW_PRIVATE.'/news-sync.lock';
const FW_SOURCES = [
 'bund'=>['label'=>'Bundesvereinigung','url'=>'https://www.freiewaehler.eu/bund/pressemitteilungen/','host'=>'www.freiewaehler.eu'],
 'bayern'=>['label'=>'Bayern','url'=>'https://www.fw-bayern.de/aktuelles/mitteilungen','host'=>'www.fw-bayern.de'],
 'erding'=>['label'=>'Landkreis Erding','url'=>'https://www.fw-landkreis-erding.de/aktuelles','host'=>'www.fw-landkreis-erding.de']
];
function fwRead(string $path):array {$v=is_file($path)?json_decode((string)@file_get_contents($path),true):null;return is_array($v)?$v:[];}
function fwJson(array $a,int $status=200):never {http_response_code($status);header('Content-Type: application/json; charset=utf-8');echo json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
function fwClean(string $s,int $max=200):string {
 $s=html_entity_decode(strip_tags($s),ENT_QUOTES|ENT_HTML5,'UTF-8');
 $s=trim((string)preg_replace('/\s+/u',' ',$s));
 return function_exists('mb_substr')?mb_substr($s,0,$max,'UTF-8'):substr($s,0,$max);
}
function fwDefaultConfig():array {return ['enabled'=>['bund'=>true,'bayern'=>true,'erding'=>true],'hours'=>6];}
function fwConfig():array {
 global $FW_CONFIG; $stored=fwRead($FW_CONFIG);$defaults=fwDefaultConfig();
 $hours=(int)($stored['hours']??6);if(!in_array($hours,[3,6,12,24],true))$hours=6;
 $enabled=[];foreach(FW_SOURCES as $id=>$source)$enabled[$id]=array_key_exists($id,$stored['enabled']??[])?($stored['enabled'][$id]===true):true;
 return ['enabled'=>$enabled,'hours'=>$hours];
}
function fwPrivateReady():bool {
 global $FW_PRIVATE;
 if(!is_dir($FW_PRIVATE)||!is_file($FW_PRIVATE.'/.htaccess'))return false;
 return is_writable($FW_PRIVATE);
}
function fwAtomic(string $path,array $data):bool {
 $dir=dirname($path);if(!is_dir($dir)||!is_writable($dir))return false;
 $temp=@tempnam($dir,'.fwnews-');if($temp===false)return false;
 $bytes=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
 if($bytes===false||file_put_contents($temp,$bytes,LOCK_EX)!==strlen($bytes)){@unlink($temp);return false;}
 @chmod($temp,0600);if(!@rename($temp,$path)){@unlink($temp);return false;}return true;
}
function fwAllowedUrl(string $url,string $host):bool {
 if(!filter_var($url,FILTER_VALIDATE_URL))return false;
 $parts=parse_url($url);return is_array($parts)&&strtolower((string)($parts['scheme']??''))==='https'
  &&strtolower((string)($parts['host']??''))===$host&&!isset($parts['user'])&&!isset($parts['pass'])
  &&(!isset($parts['port'])||(int)$parts['port']===443);
}
function fwResolveUrl(string $href,string $origin):string {
 $href=html_entity_decode(trim($href),ENT_QUOTES|ENT_HTML5,'UTF-8');
 if($href===''||str_starts_with($href,'#')||str_starts_with($href,'javascript:'))return '';
 if(str_starts_with($href,'//'))return 'https:'.$href;
 if(preg_match('~^https?://~i',$href))return $href;
 $parts=parse_url($origin);if(!is_array($parts))return '';
 $base='https://'.$parts['host'];
 if(str_starts_with($href,'/'))return $base.$href;
 $path=(string)($parts['path']??'/');return $base.rtrim(dirname($path),'/').'/'.$href;
}
function fwSafeDate(int $d,int $m,int $y):?string {
 if($y<2020||$y>2100||!checkdate($m,$d,$y))return null;
 $stamp=sprintf('%04d-%02d-%02d',$y,$m,$d);
 if($stamp>gmdate('Y-m-d',time()+86400))return null;
 return $stamp;
}
function fwGermanDate(string $s):?string {
 $months=['januar'=>1,'februar'=>2,'märz'=>3,'maerz'=>3,'april'=>4,'mai'=>5,'juni'=>6,'juli'=>7,'august'=>8,'september'=>9,'oktober'=>10,'november'=>11,'dezember'=>12];
 if(preg_match('/\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b/u',$s,$m))return fwSafeDate((int)$m[1],(int)$m[2],(int)$m[3]);
 if(preg_match('/\b(\d{1,2})\.\s*(Januar|Februar|März|Maerz|April|Mai|Juni|Juli|August|September|Oktober|November|Dezember)\s+(20\d{2})\b/iu',$s,$m)){
  $k=function_exists('mb_strtolower')?mb_strtolower($m[2],'UTF-8'):strtolower($m[2]);return fwSafeDate((int)$m[1],$months[$k]??0,(int)$m[3]);
 }
 return null;
}
function fwAnchors(string $html):array {
 $out=[];
 if(!preg_match_all('~<a\b([^>]*?)>(.*?)</a\s*>~isu',$html,$matches,PREG_SET_ORDER))return [];
 foreach($matches as $m){
  if(!preg_match('~\bhref\s*=\s*["\']([^"\']+)["\']~i',$m[1],$a))continue;
  $text=fwClean($m[2],450);if($text==='')continue;
  // Die Bundesseite trennt Rubrik, Lesedauer, Titel und Vorschautext per HTML-Tags.
  // strip_tags() alleine verklebt diese Teile (z.B. 'BundWirtschaft3 minMinijob...').
  $headline='';
  if(preg_match_all('~<h([1-6])\b[^>]*>(.*?)</h\1\s*>~isu',$m[2],$headings,PREG_SET_ORDER)){
   foreach($headings as $h){
    $candidate=fwClean((string)preg_replace('~<[^>]+>~u',' ',$h[2]),220);
    if(mbSafeLen($candidate)>=12&&!preg_match('/^Bund\s*[\p{L}\/\s&-]*\d{1,2}\s*min/u',$candidate)){
     $headline=$candidate;break;
    }
   }
  }
  $out[]=['url'=>$a[1],'text'=>$text,'headline'=>$headline];
 }
 return $out;
}
/** Entfernt ausschließlich Bund-Rubrik und Lesedauer am Artikelanfang.
 * Akzeptiert sowohl getrennte HTML-Textteile als auch den bisherigen zusammengeklebten Cache.
 */
function fwBundCleanTitle(string $title):string {
 $title=fwClean($title,450);
 $clean=(string)preg_replace('/^Bund[\p{L}\/\s&-]{0,75}?\d{1,2}\s*min\s*/u','',$title,1);
 return trim($clean);
}
function fwNormalizeArticle(string $level,string $title,string $date,string $url):array {
 return ['id'=>'sync-'.substr(hash('sha256',$url),0,20),'level'=>$level,'date'=>$date,'title'=>fwClean($title,200),
  'excerpt'=>'Überschrift von der offiziellen Website; vollständigen Beitrag im Original lesen.',
  'url'=>$url,'source'=>FW_SOURCES[$level]['label']];
}
/** Extract only links and clear publication dates. No article bodies or images. */
function fwExtract(string $html,string $level):array {
 $source=FW_SOURCES[$level];$found=[];$seen=[];
 foreach(fwAnchors($html) as $anchor){
  $url=fwResolveUrl($anchor['url'],$source['url']);
  if(!fwAllowedUrl($url,$source['host'])||isset($seen[$url]))continue;
  $title=$anchor['text'];$date=null;
  if($level==='bayern'){
   if(!preg_match('/^(\d{1,2}\.\d{1,2}\.20\d{2})\s+(.+)$/u',$title,$p))continue;
   $date=fwGermanDate($p[1]);$title=$p[2];
   if($url===$source['url'])continue;
  }elseif($level==='bund'){
   if(!preg_match('/\b(\d{1,2}\.\s*(?:Januar|Februar|März|Maerz|April|Mai|Juni|Juli|August|September|Oktober|November|Dezember)\s+20\d{2})\s*$/iu',$title,$p))continue;
   $date=fwGermanDate($p[1]);
   $title=trim(substr($title,0,strlen($title)-strlen($p[0])));
   // Bevorzuge die semantische Ueberschrift aus H2-H6; Vorschautexte bleiben draussen.
   // Fallback: technische Labels vor der eigentlichen Ueberschrift entfernen.
   $heading=trim((string)($anchor['headline']??''));
   $title=fwBundCleanTitle($heading!==''?$heading:$title);
   if($url===$source['url'])continue;
  }elseif($level==='erding'){
   // Erding lacks dates on some news blocks. Never use an event date as a publication date.
   // Only explicit date-prefixed article links are accepted.
   if(!preg_match('/^(\d{1,2}\.\d{1,2}\.20\d{2})\s+(.+)$/u',$title,$p))continue;
   $date=fwGermanDate($p[1]);$title=$p[2];
  }
  if($date===null||mbSafeLen($title)<12||mbSafeLen($title)>360)continue;
  $seen[$url]=true;$found[]=fwNormalizeArticle($level,$title,$date,$url);
  if(count($found)>=25)break;
 }
 return $found;
}
function mbSafeLen(string $s):int{return function_exists('mb_strlen')?mb_strlen($s,'UTF-8'):strlen($s);}
function fwFetch(string $url,string $host):array {
 if(!fwAllowedUrl($url,$host))return ['error'=>'URL nicht erlaubt'];
 // Einige offizielle Nachrichtenseiten sind deutlich groesser als 1 MB.
 // Das vorherige Limit brach einen Abruf mit HTTP 200 und cURL-Fehler 23 ab.
 // 8 MB Obergrenze und Zeitlimit verhindern ungebremsten Speicher-/Netzverbrauch.
 $maxBytes=8*1024*1024;
 if(function_exists('curl_init')){
  $body='';$tooLarge=false;$ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>false,CURLOPT_FOLLOWLOCATION=>false,
   CURLOPT_CONNECTTIMEOUT=>6,CURLOPT_TIMEOUT=>20,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,
   CURLOPT_USERAGENT=>'FWKompass-News/1.3.10 (+https://weindler.net/fw-kompass/)',
   CURLOPT_HTTPHEADER=>['Accept: text/html,application/xhtml+xml'],
   CURLOPT_ENCODING=>'',
   CURLOPT_WRITEFUNCTION=>static function($curl,string $chunk)use(&$body,&$tooLarge,$maxBytes):int {
    if(strlen($body)+strlen($chunk)>$maxBytes){$tooLarge=true;return 0;}
    $body.=$chunk;return strlen($chunk);
   }]);
  if(defined('CURLOPT_PROTOCOLS_STR') )curl_setopt($ch,CURLOPT_PROTOCOLS_STR,'https');
  elseif(defined('CURLOPT_PROTOCOLS')&&defined('CURLPROTO_HTTPS'))curl_setopt($ch,CURLOPT_PROTOCOLS,CURLPROTO_HTTPS);
  $ok=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$errno=curl_errno($ch);curl_close($ch);
  if($tooLarge)return ['error'=>'Quellseite groesser als 8 MB; Import aus Sicherheitsgruenden abgebrochen.'];
  if($ok===false){
   $label=match($errno){28=>'Zeitueberschreitung',60=>'TLS-Zertifikatspruefung fehlgeschlagen',
    6=>'DNS-Aufloesung fehlgeschlagen',7=>'Verbindung fehlgeschlagen',
    23=>'Abbruch bei der Datenuebertragung',default=>'cURL-Fehler '.$errno};
   return ['error'=>$label.' (HTTP '.$status.')'];
  }
  if($status!==200)return ['error'=>'Quellserver antwortet mit HTTP '.$status];
  if($body==='')return ['error'=>'Quellserver lieferte eine leere HTML-Antwort'];
  return ['body'=>$body];
 }
 if(!filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))return ['error'=>'HTTPS-Abruf auf Server nicht verfuegbar'];
 $context=stream_context_create(['http'=>['method'=>'GET','timeout'=>20,'follow_location'=>0,'ignore_errors'=>false,
  'header'=>"Accept: text/html\r\nUser-Agent: FWKompass-News/1.3.10\r\n"],
  'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
 $handle=@fopen($url,'rb',false,$context);if($handle===false)return ['error'=>'HTTPS-Abruf fehlgeschlagen'];
 $status=implode(' ',(array)(stream_get_meta_data($handle)['wrapper_data']??[]));
 $body=stream_get_contents($handle,$maxBytes+1);fclose($handle);
 if(strlen((string)$body)>$maxBytes)return ['error'=>'Quellseite groesser als 8 MB'];
 if(!str_contains($status,' 200 ')||!is_string($body))return ['error'=>'Keine gueltige Antwort der Quelle'];
 return ['body'=>$body];
}
/**
 * Synchronisiert nur die gewählte Ebene; bei "all" alle drei Quellen.
 * Pro Quelle eigene Prüfungshäufigkeit: ein Tabwechsel löst keinen ungehemmten
 * Abruf der fremden Website aus. Alte erfolgreiche Ergebnisse bleiben bei Fehlern erhalten.
 */
function fwRunSync(bool $force=false, ?string $onlySource=null):array {
 global $FW_CACHE,$FW_LOCK;
 if($onlySource!==null&&!array_key_exists($onlySource,FW_SOURCES))return ['error'=>'Unbekannte Nachrichtenebene'];
 if(!fwPrivateReady())return ['error'=>'Geschützter Speicher nicht verfügbar – Updateverwaltung prüfen'];
 $lock=@fopen($FW_LOCK,'c+');if(!$lock)return ['error'=>'Sperrdatei nicht verfügbar'];
 if(!flock($lock,LOCK_EX|LOCK_NB)){fclose($lock);return ['busy'=>true];}
 try {
  $cfg=fwConfig();$cache=fwRead($FW_CACHE);
  $articles=is_array($cache['articles']??null)?$cache['articles']:[];
  $status=is_array($cache['sources']??null)?$cache['sources']:[];
  $times=is_array($cache['sourceAttemptUnix']??null)?$cache['sourceAttemptUnix']:[];
  $keys=$onlySource!==null?[$onlySource]:array_keys(FW_SOURCES);
  $processed=0;$successful=0;$skipped=0;
  foreach($keys as $key){
   $source=FW_SOURCES[$key];
   if(!$cfg['enabled'][$key]){
    $status[$key]=['state'=>'disabled','count'=>0,'label'=>$source['label'],'lastCheckedAt'=>$status[$key]['lastCheckedAt']??null];
    continue;
   }
   $last=(int)($times[$key]??0);
   if(!$force&&$last>0&&time()-$last<$cfg['hours']*3600){$skipped++;continue;}
   $times[$key]=time();$cache['sourceAttemptUnix']=$times;
   $cache['attemptUnix']=time();$cache['lastCheckedAt']=gmdate('c');
   // Vor dem Netzwerkabruf sichern, damit parallele Browser die Quellseite nicht überlasten.
   if(!fwAtomic($FW_CACHE,$cache))return ['error'=>'Prüfzeit konnte nicht gespeichert werden'];
   $processed++;
   $old=$status[$key]??[];
   $result=fwFetch($source['url'],$source['host']);
   $oldCount=count(array_filter($articles,static fn($a)=>($a['level']??'')===$key));
   if(!isset($result['body'])){
    $status[$key]=['state'=>'error','count'=>$oldCount,'label'=>$source['label'],
     'error'=>$result['error']??'Unbekannter Abruffehler','lastCheckedAt'=>gmdate('c'),'lastSuccess'=>$old['lastSuccess']??null];
   }else {
    $found=fwExtract($result['body'],$key);
    if(count($found)===0){
     $status[$key]=['state'=>'no-dated-articles','count'=>$oldCount,'label'=>$source['label'],
      'lastCheckedAt'=>gmdate('c'),'lastSuccess'=>$old['lastSuccess']??null,
      'note'=>'Quelle erreichbar, aber keine eindeutig datierten Beitragslinks erkannt.'];
    }else {
     $articles=array_values(array_filter($articles,static fn($a)=>($a['level']??'')!==$key));
     $articles=array_merge($articles,$found);$successful++;
     $status[$key]=['state'=>'ok','count'=>count($found),'label'=>$source['label'],
      'lastCheckedAt'=>gmdate('c'),'lastSuccess'=>gmdate('c')];
     $cache['lastSuccessfulAt']=gmdate('c');
    }
   }
   // Nach jeder Quelle speichern, auch wenn eine andere ausfällt.
   $cache['sources']=$status;
   $cache['articles']=$articles;
   if(!fwAtomic($FW_CACHE,$cache))return ['error'=>'Ergebnisse konnten nicht gespeichert werden'];
  }
  $dedup=[];$out=[];
  foreach($articles as $a){
   if(!is_array($a)||!in_array($a['level']??'',['bund','bayern','erding'],true))continue;
   $key=$a['level'];$url=(string)($a['url']??'');
   if(!fwAllowedUrl($url,FW_SOURCES[$key]['host'])||isset($dedup[$url]))continue;
   $dedup[$url]=true;$out[]=$a;
  }
  usort($out,static fn($a,$b)=>strcmp($b['date'],$a['date']));
  $cache['articles']=array_slice($out,0,100);
  $cache['sources']=$status;
  $cache['sourceAttemptUnix']=$times;
  if(!fwAtomic($FW_CACHE,$cache))return ['error'=>'Ergebnisse konnten nicht gespeichert werden'];
  return ['ok'=>true,'sources'=>$status,'newCount'=>count($cache['articles']),
   'checkedSources'=>$processed,'skippedSources'=>$skipped,'successfulSources'=>$successful];
 }finally {flock($lock,LOCK_UN);fclose($lock);}
}
function fwArticleValid(array $a):?array {
 $level=(string)($a['level']??'');if(!in_array($level,['bund','bayern','erding'],true))return null;
 $url=(string)($a['url']??'');if(!filter_var($url,FILTER_VALIDATE_URL)||parse_url($url,PHP_URL_SCHEME)!=='https')return null;
 $d=(string)($a['date']??'');if(!preg_match('/^20\d{2}-\d{2}-\d{2}$/D',$d))return null;
 $title=fwClean((string)($a['title']??''),200);
 // Bereits zwischengespeicherte Bundesmeldungen gleich in der Anzeige bereinigen.
 if($level==='bund')$title=fwBundCleanTitle($title);
 return ['id'=>fwClean((string)($a['id']??sha1($url)),100),'level'=>$level,'date'=>$d,
  'title'=>fwClean($title,200),'excerpt'=>fwClean((string)($a['excerpt']??''),230),
  'url'=>$url,'source'=>fwClean((string)($a['source']??''),100),'demo'=>($a['demo']??false)===true];
}
function fwPublicNews(?string $requestedLevel=null):array {
 global $FW_CACHE,$FW_ROOT;
 $cfg=fwConfig();$cache=fwRead($FW_CACHE);
 // Eine gezielte Anfrage prüft die gewählte Ebene nur bei abgelaufenem Intervall.
 // "all" prüft alle drei Quellen; normale App-Starts liefern sofort den bisherigen Cache.
 if($requestedLevel!==null&&fwPrivateReady()&&array_filter($cfg['enabled'])){
  fwRunSync(false,$requestedLevel==='all'?null:$requestedLevel);
  $cache=fwRead($FW_CACHE);
 }
 $local=fwRead($FW_ROOT.'/data/local-news.json');
 $synced=is_array($cache['articles']??null)?$cache['articles']:[];
 $curated=array_merge($local,$synced);$out=[];$seen=[];
 foreach($curated as $raw){if(!is_array($raw))continue;$a=fwArticleValid($raw);if($a===null||$a['title']==='')continue;
  if(isset($seen[$a['url'].'|'.$a['title']]))continue;$seen[$a['url'].'|'.$a['title']]=true;$out[]=$a;
 }
 $hasLive=count($synced)>0;
 // Ausschließlich eindeutig zugeordnete Originalmeldungen oder lokal freigegebene Artikel.
 // Keine Demo-Meldungen in die öffentliche Antwort aufnehmen.
 usort($out,static fn($a,$b)=>strcmp($b['date'],$a['date']));
 $status=[];$successCount=0;
 foreach(FW_SOURCES as $key=>$source){$s=$cache['sources'][$key]??['state'=>'not-checked','count'=>0];
  $status[$key]=['state'=>(string)($s['state']??'not-checked'),'count'=>(int)($s['count']??0),
   'label'=>$source['label'],'lastCheckedAt'=>(string)($s['lastCheckedAt']??''),
   'lastSuccess'=>(string)($s['lastSuccess']??''),
   'error'=>fwClean((string)($s['error']??$s['note']??''),160)];
  if($status[$key]['state']==='ok')$successCount++;
 }
 $meta=['mode'=>$hasLive?'source-sync':'curated-local','feedCount'=>$successCount,'sources'=>$status,'intervalHours'=>$cfg['hours'],
  'updatedAt'=>(string)($cache['lastCheckedAt']??''),'lastSuccessfulAt'=>(string)($cache['lastSuccessfulAt']??''),'demoLevels'=>[],
  'description'=>$hasLive?'Überschriften und Datumsangaben von offiziellen Quellseiten; keine Volltexte/Bilder.':'Noch kein erfolgreicher Quellenimport; nur bestätigte lokale Meldungen.'];
 return ['metadata'=>$meta,'articles'=>array_slice($out,0,140)];
}
function fwH(string $value):string{return htmlspecialchars($value,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
/**
 * Die geschuetzte Administration verwendet einen sitzungsgebundenen, zufaelligen
 * CSRF-Token fuer ALLE Formular-POSTs sowie HTTPS, sichere Strict-Session-Cookies,
 * Passwort-Hash und Login-Limit. Auf den Origin-Header wird nicht zusaetzlich
 * vertraut: er kann je nach Browser/Webview/Proxy fehlen oder anders formatiert
 * sein. Fremde Webseiten koennen den Token wegen Same-Origin-Policy nicht lesen.
 */
function fwAdminPage():never {
 global $FW_PRIVATE,$FW_CONFIG,$FW_CACHE;
 $https=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off')||(int)($_SERVER['SERVER_PORT']??0)===443;
 if(!$https){http_response_code(403);exit('Admin-Bereich benötigt HTTPS.');}
 header('Content-Type: text/html; charset=utf-8');header('Cache-Control: no-store, private');header('X-Content-Type-Options: nosniff');
 header('X-Frame-Options: DENY');header('Referrer-Policy: no-referrer');
 header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
 ini_set('session.use_strict_mode','1');session_name('FWKOMPASS_NEWS_ADMIN');
 session_set_cookie_params(['lifetime'=>0,'path'=>'/fw-kompass/api/','secure'=>true,'httponly'=>true,'samesite'=>'Strict']);session_start();
 if(!isset($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(20));
 $msg='';$err='';$cfg=fwConfig();
 if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!hash_equals((string)$_SESSION['csrf'],(string)($_POST['csrf']??'')))$err='Sicherheitsprüfung fehlgeschlagen. Bitte Seite neu öffnen.';
  else{
   $action=(string)($_POST['action']??'');
   if($action==='login'){
    $attemptPath=$FW_PRIVATE.'/sync-login-'.hash('sha256',(string)($_SERVER['REMOTE_ADDR']??'unbekannt')).'.json';
    $attempt=fwRead($attemptPath);
    if((int)($attempt['time']??0)>time()-900&&(int)($attempt['count']??0)>=6)$err='Zu viele Anmeldeversuche. Bitte nach 15 Minuten erneut versuchen.';
    elseif(!is_file($FW_PRIVATE.'/config.php'))$err='Zuerst die Updateverwaltung einrichten.';
    else {if(!defined('FW_ADMIN'))define('FW_ADMIN',true);$a=require $FW_PRIVATE.'/config.php';
     if(!is_array($a)||!isset($a['password_hash']))$err='Admin-Konfiguration fehlt.';
     elseif(password_verify((string)($_POST['password']??''),(string)$a['password_hash'])){
      session_regenerate_id(true);$_SESSION['authenticated']=true;@unlink($attemptPath);$msg='Anmeldung erfolgreich.';
     }else{
      $newCount=((int)($attempt['time']??0)>time()-900)?(int)($attempt['count']??0)+1:1;
      fwAtomic($attemptPath,['time'=>time(),'count'=>$newCount]);$err='Passwort falsch.';
     }
    }
   }elseif(!empty($_SESSION['authenticated'])){
    if($action==='logout'){$_SESSION=[];session_destroy();header('Location: news.php?admin=1');exit;}
    if($action==='run'){$result=fwRunSync(true);$msg=isset($result['ok'])?'Quellenprüfung abgeschlossen.':($result['busy']??false?'Synchronisation läuft bereits.':'Abruf nicht möglich.');$err=(string)($result['error']??'');}
    if($action==='settings'){
     $hours=(int)($_POST['hours']??6);
     if(!in_array($hours,[3,6,12,24],true))$err='Ungültiges Intervall.';
     else{$en=[];foreach(FW_SOURCES as $k=>$s)$en[$k]=isset($_POST['source_'.$k]);
      if(fwAtomic($FW_CONFIG,['enabled'=>$en,'hours'=>$hours])){$msg='Einstellungen gespeichert.';$cfg=fwConfig();}else$err='Speichern fehlgeschlagen.';
     }
    }
   }else $err='Bitte zuerst anmelden.';
  }
 }
 $cache=fwRead($FW_CACHE);$login=!empty($_SESSION['authenticated']);
 echo '<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FW Kompass – Nachrichtensynchronisation</title><style>';
 echo 'body{margin:0;background:#fffaf2;color:#202020;font:16px system-ui,Arial,sans-serif}header{background:#f29400;padding:20px}main{max-width:770px;margin:auto;padding:20px}section{background:#fff;border:1px solid #ddd;border-radius:12px;padding:20px;margin:16px 0}input,select,button{font:inherit;padding:11px}input[type=password]{width:min(92%,460px)}button{background:#eb8200;border:0;border-radius:8px;color:#fff;font-weight:700}button:hover{background:#d36d00}.note{background:#fff2d9;padding:12px;border-radius:8px}.row{display:flex;align-items:center;gap:12px;margin:13px 0}.muted{color:#636363;font-size:14px}.err{color:#ad1616}strong{font-weight:700}a{color:#004b91}code{font-size:12px;overflow-wrap:anywhere}</style></head><body><header><strong>☀ FREIE WÄHLER · FW Kompass</strong><div>Synchronisation · Version 1.3.10</div></header><main><p><a href="../index.html#news">← Zurück zum FW Kompass</a></p>';
 if($msg!=='')echo '<p class="note">'.fwH($msg).'</p>';if($err!=='')echo '<p class="err">'.fwH($err).'</p>';
 if(!$login)echo '<section><h1>Geschützte Synchronisation</h1><p>Mit dem bestehenden Administratorpasswort anmelden.</p><form method="post"><input type="hidden" name="csrf" value="'.fwH($_SESSION['csrf']).'"><input type="hidden" name="action" value="login"><label>Passwort<br><input type="password" name="password" autocomplete="current-password" required></label><p><button>Anmelden</button></p></form></section>';
 else{
  echo '<section><h1>Offizielle Nachrichtenquellen</h1><p class="muted">Automatische Prüfung bedeutet nicht, dass eine Quelle schon verlässlich ausgelesen wurde. Das Ergebnis steht je Quelle darunter.</p>';
  foreach(FW_SOURCES as $k=>$s){$r=$cache['sources'][$k]??[];$state=(string)($r['state']??'not-checked');
   $names=['ok'=>'Erfolgreich ausgelesen','error'=>'Abruf fehlgeschlagen','disabled'=>'Deaktiviert','no-dated-articles'=>'Keine datierten Artikel erkannt','not-checked'=>'Noch nicht geprüft'];
   echo '<p><strong>'.fwH($s['label']).'</strong> · '.fwH($names[$state]??$state).' · '.(int)($r['count']??0).' Meldungen<br><span class="muted">'.fwH((string)($r['note']??$r['error']??'')).'</span><br><a rel="noopener noreferrer" href="'.fwH($s['url']).'" target="_blank">Originalquelle öffnen</a></p>';
  }
  echo '<p class="muted">Letzte Prüfung: '.fwH((string)($cache['lastCheckedAt']??'Noch nicht geprüft')).' · Letzter erfolgreicher Import: '.fwH((string)($cache['lastSuccessfulAt']??'Noch keiner')).'</p>';
  echo '<form method="post"><input type="hidden" name="csrf" value="'.fwH($_SESSION['csrf']).'"><input type="hidden" name="action" value="run"><button>Jetzt Quellen prüfen &amp; aktualisieren</button></form></section>';
  echo '<section><h2>Automatik einstellen</h2><form method="post"><input type="hidden" name="csrf" value="'.fwH($_SESSION['csrf']).'"><input type="hidden" name="action" value="settings">';
  foreach(FW_SOURCES as $k=>$s)echo '<label class="row"><input type="checkbox" name="source_'.fwH($k).'" value="1" '.($cfg['enabled'][$k]?'checked':'').'> '.fwH($s['label']).'</label>';
  echo '<label>Prüfrhythmus <select name="hours">';foreach([3,6,12,24] as $h)echo '<option value="'.$h.'" '.($cfg['hours']===$h?'selected':'').'>Alle '.$h.' Stunden</option>';
  echo '</select></label><p><button>Einstellungen speichern</button></p></form></section>';
  echo '<section class="note"><h2>Wie läuft die Automatik?</h2><p>Bitte starte zunächst oben einmal die Quellenprüfung. Beim Öffnen der Nachrichten und Wechseln zwischen Bund, Bayern und Erding fragt die App automatisch beim Server nach. Der Server greift je Quelle höchstens einmal pro eingestelltem Intervall auf die Originalseite zu. Für regelmäßige Prüfungen auch ohne Besucher kann bei goneo zusätzlich ein Cronjob eingerichtet werden (PHP-CLI-Aufruf dieser Datei mit <code>--sync</code>).</p><p>Es werden ausschließlich Überschriften, das eindeutig erkennbare Veröffentlichungsdatum und Links übernommen. Kein Volltext, keine Bilder. Bei unklaren Datumsangaben wird die Meldung nicht automatisch veröffentlicht. Nicht erfolgreich bestätigte Quellmeldungen werden nicht als aktuelle Meldungen ausgegeben.</p></section>';
  echo '<section><form method="post"><input type="hidden" name="csrf" value="'.fwH($_SESSION['csrf']).'"><input type="hidden" name="action" value="logout"><button>Abmelden</button></form></section>';
 }
 echo '</main></body></html>';exit;
}
if(defined('FWK_NEWS_LIBRARY_ONLY'))return;
if(PHP_SAPI==='cli'){
 if(in_array('--sync',$argv??[],true)){echo json_encode(fwRunSync(true),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";exit;}
 echo "FW Kompass Synchronisation: php api/news.php --sync\n";exit;
}
header('X-Content-Type-Options: nosniff');header('Cache-Control: no-store');
if(($_GET['admin']??'')==='1')fwAdminPage();
$requested=(string)($_GET['level']??'');
if($requested!==''&&!in_array($requested,['all','bund','bayern','erding'],true))fwJson(['error'=>'Ungültige Nachrichtenebene'],400);
fwJson(fwPublicNews($requested===''?null:$requested));
